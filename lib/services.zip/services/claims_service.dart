import 'dart:convert';

import 'package:community_charts_flutter/community_charts_flutter.dart'
    as charts;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:mi_insights/services/longPrint.dart';

import '../constants/Constants.dart';
import '../models/ClaimsSectionGridModel.dart';
import '../models/OrdinalSales.dart';
import '../screens/Reports/ClaimsReport.dart';

Future<void> getClaimsReport(String date_from, String date_to,
    int selectedButton1, BuildContext context) async {
  https: //uat.miinsightsapps.net/fieldV6/getLeadss?empId=3&searchKey=6&status=all&cec_client_id=1&type=field&startDate=2023-08-01&endDate=2023-08-31
  String baseUrl = "https://miinsightsapps.net/files/get_claims_data/";

  try {
    Map<String, String>? payload = {
      "client_id": "1",
      // "client_id": Constants.cec_client_id.toString(),
      "start_date": date_from,
      "end_date": date_to
    };
    if (kDebugMode) {
      //print("baseUrl $baseUrl");
    }
    List<Map<String, dynamic>> sales = [];
    Map<String, List<Map<String, dynamic>>> groupedSales1a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales2a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2a = {};

    await http
        .post(
      Uri.parse(
        baseUrl,
      ),
      body: payload,
    )
        .then((value) {
      http.Response response = value;
      if (kDebugMode) {
        if (kDebugMode) {
          /* print("ghjgjgg " + response.body);
          print("ghjgjgg " + response.body.runtimeType.toString());*/
        }
        //print(response.bodyBytes);
        //print(response.statusCode);
        //print(response.body);
        //print(response.body);
      }
      if (response.statusCode != 200) {
      } else {
        int id_y = 1;

        Constants.claims_barData = [];
        Constants.claims_pieData = [];

        Constants.claims_bottomTitles2a = [];
        Map<int, int> dailySalesCount = {};
        Map<int, int> dailySalesCount1b = {};
        Map<int, int> dailySalesCount1c = {};
        Map<int, int> monthlySalesCount2a = {};
        Map<int, int> monthlySalesCount2b = {};
        Map<int, int> monthlySalesCount2c = {};
        int monthlyTotal = 0;

        if (selectedButton1 == 1) {
          Constants.claims_salesbyagent1a = [];
          Constants.claims_bottomTitles1a = [];
          Constants.claims_maxY5a = 0;
        } else if (selectedButton1 == 2) {
          Constants.claims_salesbyagent2a = [];
          Constants.claims_bottomTitles2a = [];
          Constants.claims_maxY5b = 0;
        } else if (selectedButton1 == 3 && days_difference < 31) {
          Constants.claims_salesbyagent3a = [];
          Constants.claims_bottomTitles3a = [];
          Constants.claims_maxY5c = 0;
        } else {
          Constants.claims_salesbyagent3b = [];
          Constants.claims_bottomTitles3b = [];
          Constants.claims_maxY5d = 0;
        }
        Constants.claims_salesbyagent1b = [];

        var jsonResponse = jsonDecode(response.body);
        /*   if (selectedButton1 == 1) {
          jsonResponse = jsonDecode(Sample_Jsons.claims_mtd_data1a);
        } else {
          jsonResponse = jsonDecode(Sample_Jsons.claims_ytd_data2a);
        }*/
        // Process jsonResponse

        //var jsonResponse = jsonDecode(response.body);
        DateTime startDateTime = DateFormat('yyyy-MM-dd').parse(date_from);
        DateTime endDateTime = DateFormat('yyyy-MM-dd').parse(date_to);
        /* print("date_from $date_from");
        print("date_to $date_to");*/

        int days_difference1 = endDateTime.difference(startDateTime).inDays;
        int totalClaims = 0;
        //print("fgjgghhgghgh $jsonResponse");

        Constants.claims_by_category1 = jsonResponse;

        if (jsonResponse["claims_percentages"].toString().isNotEmpty) {
          Map m1 = jsonResponse["claims_percentages"];
          Map m2 = jsonResponse["claims_amounts"];

          if (selectedButton1 == 1) {
            DateTime thisMonth = DateTime.now();
            String formattedDate =
                "${thisMonth.year}-${thisMonth.month.toString().padLeft(2, '0')}-01";

            double claims_ratio =
                jsonResponse["claims_ratio_dict"][formattedDate] ?? 0;

            Constants.claims_ratio1a = 65;
            //Constants.claims_ratio1a = claims_ratio;

            Constants.claims_maxY5a = 0;
            // Constants.claims_paid_claims_amount1a = double.parse((jsonResponse["sum_paid"] ?? "0").toString());
            Constants.claims_paid_claims_amount1a =
                double.parse(("55000").toString());

            Constants.claims_outstanding_claims_amount1a = double.parse(
                (jsonResponse["sum_outstanding"] ?? "0").toString());

            Constants.claims_repudiated_claims_amount1a =
                double.parse((jsonResponse["sum_declined"] ?? "0").toString());
            /* Constants.claims_sectionsList1a = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m2["complete"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m2["complete"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 24 Hours",
                  (m2["complete"]?["Within 24 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 2 Days",
                  (m2["complete"]?["Within 48 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 5 Days",
                  (m2["complete"]?["After 48 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("After 5 Days",
                  (m2["complete"]?["After 5 Days"] ?? "0").toString()),
            ];*/

            Constants.claims_sectionsList1a_1 = [
              claims_sections_gridmodel("Within 5 Hours", ("20000").toString()),
              claims_sections_gridmodel(
                  "Within 12 Hours", ("10000").toString()),
              claims_sections_gridmodel(
                  "Within 24 Hours", ("10000").toString()),
              claims_sections_gridmodel("Within 2 Days", ("5000").toString()),
              claims_sections_gridmodel("Within 5 Days", ("5000").toString()),
              claims_sections_gridmodel("After 5 Days", ("5000").toString()),
            ];
            Constants.claims_sectionsList1a = [
              claims_sections_gridmodel(
                  "Within 5 Hours", ("36.37%").toString()),
              claims_sections_gridmodel(
                  "Within 12 Hours", ("18.18%").toString()),
              claims_sections_gridmodel(
                  "Within 24 Hours", ("18.18%").toString()),
              claims_sections_gridmodel("Within 2 Days", ("9.01%").toString()),
              claims_sections_gridmodel("Within 5 Days", ("9.01%").toString()),
              claims_sections_gridmodel("After 5 Days", ("9.01%").toString()),
            ];
            Constants.claims_sectionsList1b = [
              claims_sections_gridmodel("Within 5 Hours", ("0%").toString()),
              claims_sections_gridmodel("Within 12 Hours", ("0%").toString()),
              claims_sections_gridmodel("Within 24 Hours", ("0%").toString()),
            ];

            /*Constants.claims_sectionsList1b = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m1["ongoing"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m1["ongoing"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 24 Hours",
                  (m1["ongoing"]?["Within 24 Hours"] ?? "0").toString()),
            ];*/

            /*Constants.claims_sectionsList1b_1 = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m2["ongoing"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m2["ongoing"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 24 Hours",
                  (m2["ongoing"]?["Within 24 Hours"] ?? "0").toString()),
            ];*/
            Constants.claims_sectionsList1b_1 = [
              claims_sections_gridmodel("Within 5 Hours", ("0").toString()),
              claims_sections_gridmodel("Within 12 Hours", ("0").toString()),
              claims_sections_gridmodel("After 12 Hours", ("0").toString()),
            ];

            Constants.claims_sectionsList1c = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m1["declined"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m1["declined"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("After 12 Hours", ("0").toString()),
            ];

            Constants.claims_sectionsList1c_1 = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m2["declined"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m2["declined"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("After 12 Hours", ("0").toString()),
            ];

            print(
                "Constants.claims_sectionsList1a ${Constants.claims_sectionsList1a}");
            Constants.claims_ordinary_sales1a
                .add(OrdinalSales("All", totalClaims));
            Constants.claims_ordinary_sales1a.add(OrdinalSales(
                "Logged", jsonResponse["claims_by_category"]["Logged"] ?? 0));
            Constants.claims_ordinary_sales1a.add(OrdinalSales("Processed",
                jsonResponse["claims_by_category"]["Processed"] ?? 0));
            Constants.claims_ordinary_sales1a.add(OrdinalSales("Finalised",
                jsonResponse["claims_by_category"]["deceased Finalised"] ?? 0));

            Constants.claims_bardata5a.add(charts.Series<OrdinalSales, String>(
              id: 'BranchSales',
              domainFn: (OrdinalSales sale, _) => sale.branch,
              measureFn: (OrdinalSales sale, _) => sale.sales,
              data: Constants.claims_ordinary_sales1a,
              labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}',
            ));
          } else if (selectedButton1 == 2) {
            Constants.jsonMonthlyClaimsData1 = jsonResponse;
            Map m1 = Constants.jsonMonthlyClaimsData1["claims_ratio_dict"];
            print("gffgfddf ${m1}");
            double claims_ratio_count = 0;
            double claims_ratio_sum = 0;

            m1.forEach((key, value) {
              print("ekey ${key}");
              print("eggghvalue ${value}");

              double new_value = double.parse(value.toString());
              if (new_value != null) {
                claims_ratio_count++;
                claims_ratio_sum += value;
              }
            });
            if (claims_ratio_count == 0) {
              print("fdgf $claims_ratio_sum");
              Constants.claims_ratio2a = 53.5;
            } else {
              Constants.claims_ratio2a = 53.5;
              //Constants.claims_ratio2a = claims_ratio_sum / claims_ratio_count;
              print("fdgf1 $claims_ratio_count");
            }
            print("dfdfdggf $claims_ratio_sum $claims_ratio_count");
            logLongString("ggfgg3 ${date_from} ${date_to}");
            logLongString("ggfgg3a ${jsonResponse["claims_ratio_dict"]}");

            Constants.claims_maxY5a = 0;
            /* Constants.claims_paid_claims_amount2a =
                double.parse((jsonResponse["sum_paid"] ?? "0").toString());*/
            Constants.claims_paid_claims_amount2a = 100000;

            Constants.claims_outstanding_claims_amount1b = double.parse(
                (jsonResponse["sum_outstanding"] ?? "0").toString());

            Constants.claims_repudiated_claims_amount1b =
                double.parse((jsonResponse["sum_declined"] ?? "0").toString());

            Constants.claims_sectionsList2a_1 = [
              claims_sections_gridmodel("Within 5 Hours", ("50000").toString()),
              claims_sections_gridmodel(
                  "Within 12 Hours", ("20000").toString()),
              claims_sections_gridmodel(
                  "Within 24 Hours", ("10000").toString()),
              claims_sections_gridmodel("Within 2 Days", ("15000").toString()),
              claims_sections_gridmodel("Within 5 Days", ("5000").toString()),
              claims_sections_gridmodel("After 5 Days", ("0").toString()),
            ];
            Constants.claims_sectionsList2a = [
              claims_sections_gridmodel(
                  "Within 5 Hours", ("50.00%").toString()),
              claims_sections_gridmodel(
                  "Within 12 Hours", ("20.00%").toString()),
              claims_sections_gridmodel(
                  "Within 24 Hours", ("10.00%").toString()),
              claims_sections_gridmodel("Within 2 Days", ("15.00%").toString()),
              claims_sections_gridmodel("Within 5 Days", ("5.00%").toString()),
              claims_sections_gridmodel("After 5 Days", ("0.00%").toString()),
            ];
            Constants.claims_sectionsList2b = [
              claims_sections_gridmodel("Within 5 Hours", ("0%").toString()),
              claims_sections_gridmodel("Within 12 Hours", ("0%").toString()),
              claims_sections_gridmodel("Within 24 Hours", ("0%").toString()),
            ];

            /*Constants.claims_sectionsList1b = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m1["ongoing"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m1["ongoing"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 24 Hours",
                  (m1["ongoing"]?["Within 24 Hours"] ?? "0").toString()),
            ];*/

            /*Constants.claims_sectionsList1b_1 = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m2["ongoing"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m2["ongoing"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 24 Hours",
                  (m2["ongoing"]?["Within 24 Hours"] ?? "0").toString()),
            ];*/
            Constants.claims_sectionsList2b_1 = [
              claims_sections_gridmodel("Within 5 Hours", ("0").toString()),
              claims_sections_gridmodel("Within 12 Hours", ("0").toString()),
              claims_sections_gridmodel("After 12 Hours", ("0").toString()),
            ];

            Constants.claims_sectionsList2c = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m1["declined"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m1["declined"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("After 12 Hours", ("0").toString()),
            ];

            Constants.claims_sectionsList2c_1 = [
              claims_sections_gridmodel("Within 5 Hours",
                  (m2["declined"]?["Within 5 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("Within 12 Hours",
                  (m2["declined"]?["Within 12 Hours"] ?? "0").toString()),
              claims_sections_gridmodel("After 12 Hours", ("0").toString()),
            ];

            if (kDebugMode) {
              print(
                  "Constants.claims_sectionsList1a ${Constants.claims_sectionsList2a}");
            }

            Constants.claims_ordinary_sales2a
                .add(OrdinalSales("All", totalClaims));
            Constants.claims_ordinary_sales2a.add(OrdinalSales("Logged",
                jsonResponse["claims_by_category"]["intimation"] ?? 0));
            Constants.claims_ordinary_sales2a.add(OrdinalSales("Processed",
                jsonResponse["claims_by_category"]["complete"] ?? 0));
            Constants.claims_ordinary_sales2a.add(OrdinalSales(
                "Finalised",
                jsonResponse["claims_by_category"]["deceased collection"] ??
                    0));

            Constants.claims_bardata5b.add(charts.Series<OrdinalSales, String>(
              id: 'BranchSales',
              domainFn: (OrdinalSales sale, _) => sale.branch,
              measureFn: (OrdinalSales sale, _) => sale.sales,
              data: Constants.claims_ordinary_sales2a,
              labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}',
            ));
          } else if (selectedButton1 == 3 && days_difference1 <= 31) {
            Constants.claims_sectionsList3a = [
              claims_sections_gridmodel(
                  "Within 1 Day", (m2["complete"]["Within 1 Day"]).toString()),
              claims_sections_gridmodel("Within 2 Days",
                  (m2["complete"]["Within 2 Days"]).toString()),
              claims_sections_gridmodel("Within 3 Days",
                  (m2["complete"]["Within 3 Days"]).toString()),
              claims_sections_gridmodel("Within 4 Days",
                  (m2["complete"]["Within 4 Days"]).toString()),
              claims_sections_gridmodel("Within 5 Days",
                  (m2["complete"]["Within 5 Days"]).toString()),
              claims_sections_gridmodel(
                  "After 5 Days", (m2["complete"]["After 5 Days"]).toString()),
            ];
            Constants.claims_sectionsList3a_1 = [
              claims_sections_gridmodel(
                  "Within 1 Day", (m2["complete"]["Within 1 Day"]).toString()),
              claims_sections_gridmodel("Within 2 Days",
                  (m2["complete"]["Within 2 Days"]).toString()),
              claims_sections_gridmodel("Within 3 Days",
                  (m2["complete"]["Within 3 Days"]).toString()),
              claims_sections_gridmodel("Within 4 Days",
                  (m2["complete"]["Within 4 Days"]).toString()),
              claims_sections_gridmodel("Within 5 Days",
                  (m2["complete"]["Within 5 Days"]).toString()),
              claims_sections_gridmodel(
                  "After 5 Days", (m2["complete"]["After 5 Days"]).toString()),
            ];
          } else {
            Constants.claims_maxY5d = 0;

            Constants.claims_ordinary_sales3b
                .add(OrdinalSales("All", totalClaims));
            Constants.claims_ordinary_sales3b.add(OrdinalSales("Logged",
                jsonResponse["claims_by_category"]["intimation"] ?? 0));
            Constants.claims_ordinary_sales3b.add(OrdinalSales("Processed",
                jsonResponse["claims_by_category"]["complete"] ?? 0));
            Constants.claims_ordinary_sales3b.add(OrdinalSales(
                "Finalised",
                jsonResponse["claims_by_category"]["deceased collection"] ??
                    0));
            Constants.claims_bardata5d.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.claims_ordinary_sales3b,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
          }
          if (kDebugMode) {
            //print("got here ghhgjjhh ${selectedButton1}");
          }
          //print("days_difference1_claims $days_difference1");
          isLoading = false;
          claimsValue.value++;
        }
      }
    });
  } on Exception catch (_, exception) {
    //Exception exc = exception as Exception;
    print(exception);
  }
}

String getEmployeeById(
  int cec_employeeid,
) {
  String result = "";
  for (var employee in Constants.cec_employees) {
    if (employee['cec_employeeid'].toString() == cec_employeeid.toString()) {
      result = employee["employee_name"] + " " + employee["employee_surname"];
      //print("fgfghg $result");
      return result;
    }
  }
  if (result.isEmpty) {
    return "";
  } else
    return result;
}

String getBranchById(
  int branch_id,
) {
  String result = "";
  for (var branch in Constants.all_branches) {
    if (branch['cec_organo_branches_id'].toString() == branch_id.toString()) {
      result = branch["branch_name"];
      //print("fgfghg $result");
      return result;
    }
  }
  if (result.isEmpty) {
    return "";
  } else
    return result;
}
