import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../constants/Constants.dart';
import '../models/PaymentHistoryItem.dart';
import '../models/reprintitem.dart';

List<ReprintItem> reprintList2C = [];
List<PaymentHistoryItem> paymentList = [];
bool showOptions = false;
bool isReprintListLoading = false;
List<Map<String, dynamic>> paymentHistoryList = [];
List<Map<String, dynamic>> policyDetailsList = [];
getReprintHistory() async {
  if (kDebugMode) {
    print(Constants.user_reference);
    print(Constants.cec_client_id);
  }
  String baseUrl = "https://uat.miinsightsapps.net/files";
  String urlPath = "/get_requests_awaiting_action/";
  String apiUrl = baseUrl + urlPath;
  DateTime now = DateTime.now();

  // Construct the request body
  Map<String, dynamic> requestBody = {
    "policy_number": "ATH00170",
    "cec_client_id": 1,
    // "cec_client_id": Constants.cec_client_id,
  };
  reprintList2C = [];
  try {
    var response = await http.post(
      Uri.parse(apiUrl),
      body: jsonEncode(requestBody),
      headers: {
        "Content-Type": "application/json",
      },
    );
    print(response.body);
    // Simulating transaction processing with a delay

    // Navigator.of(context).pop();
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      List<dynamic> dataList = data;
      print("dataygfg $data");
      for (var element in dataList) {
        //print("dataz $policy_number $element");

        reprintList2C.add(ReprintItem(
          collection_date: element["timestamp"],
          payment_date: element["transaction_date"],
          policy_number: element["policy_number"],
          pos_transaction_id: element["transaction_id"] ?? "",
          amount: element["collected_amount"].toString() ?? "0",
          status: element["status"] ?? "",
          branch: element["branch"] ?? "",
          is_printed: element["is_printed"] ?? true,
        ));
      }
      return reprintList2C;
      isReprintListLoading = false;

      // print("dataxf ${c.runtimeType}");
    } else {
      isReprintListLoading = false;

      var data = jsonDecode(response.body);
      return [];
      // print("data $data");
      //setState(() {});

      print("Request failed with status: ${response.statusCode}");
    }

    // Perform your transaction logic here

    // Close the dialog
  } catch (error) {
    print("Error: $error");
  }
}
