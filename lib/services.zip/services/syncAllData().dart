import 'package:intl/intl.dart';
import 'package:mi_insights/services/reprints_and_cancellations_service.dart';
import 'package:mi_insights/services/sales_report_service.dart';

import '../constants/Constants.dart';
import 'claims_service.dart';
import 'maintenance_report_service.dart';
import 'moral_index_service.dart';

syncAllData(context) {
  for (int i = 1; i <= 2; i++) {
    print("ggjg ${i}");
    if (i == 1) {
      DateTime? startDate = DateTime.now();
      DateTime? endDate = DateTime.now();
      startDate = DateTime(DateTime.now().year, DateTime.now().month, 1);
      endDate = DateTime.now();

      Constants.sales_formattedStartDate =
          DateFormat('yyyy-MM-dd').format(startDate);
      Constants.sales_formattedEndDate =
          DateFormat('yyyy-MM-dd').format(endDate);

      print("formattedStartDate${i}a ${Constants.sales_formattedStartDate}");

      getSalesReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 1, 1, context);
      getMaintenanceReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 1, context);
      getReprintsData(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 1, context);
      getMoralIndexReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 1, context);
      //getClaimsReport(Constants.sales_formattedStartDate, Constants.sales_formattedEndDate, 1, context);
      getClaimsReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 1, context);
    } else if (i == 2) {
      DateTime? startDate = DateTime.now();
      DateTime? endDate = DateTime.now();
      DateTime now = DateTime.now();
      startDate = DateTime(now.year, now.month - 11, 1);

      endDate = now;

      Constants.sales_formattedStartDate =
          DateFormat('yyyy-MM-dd').format(startDate);
      Constants.sales_formattedEndDate =
          DateFormat('yyyy-MM-dd').format(endDate);

      getSalesReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 2, 1, context);
      getReprintsData(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 2, context);
      getMaintenanceReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 2, context);
      getClaimsReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 2, context);
      getMoralIndexReport(Constants.sales_formattedStartDate,
          Constants.sales_formattedEndDate, 2, context);
    }
  }
}
