import 'dart:convert';
import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:mi_insights/models/SalesByAgent.dart';

import '../constants/Constants.dart';
import '../models/MoraleIndexCategory.dart';
import '../models/salesgridmodel.dart';
import '../screens/Reports/MaintenanceReport.dart';

List<BarChartGroupData> barChartData1 = [];
List<BarChartGroupData> barChartData2 = [];
List<BarChartGroupData> barChartData3 = [];
List<BarChartGroupData> barChartData4 = [];
List<dynamic> moods_list = [];
Future<void> getMoralIndexReport(String date_from, String date_to,
    int selectedButton1, BuildContext context) async {
  https: //uat.miinsightsapps.net/fieldV6/getLeadss?empId=3&searchKey=6&status=all&cec_client_id=1&type=field&startDate=2023-08-01&endDate=2023-08-31
  String baseUrl = "https://miinsightsapps.net/files/count_users_moods/";

  try {
    Map<String, String>? payload = {
      "client_id": Constants.cec_client_id.toString(),
      "start_date": date_from,
      "end_date": date_to
    };
    if (kDebugMode) {
      //print("baseUrl $baseUrl");
      print("payload $payload");
    }
    List<Map<String, dynamic>> sales = [];
    Map<String, List<Map<String, dynamic>>> groupedSales1a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales2a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2a = {};

    await http
        .post(
      Uri.parse(
        baseUrl,
      ),
      body: payload,
    )
        .then((value) {
      http.Response response = value;
      if (kDebugMode) {
        if (kDebugMode) {
          print("ghjgjgg " + response.body);
          print("ghjgjgg " + response.body.runtimeType.toString());
        }
        //print(response.bodyBytes);
        //print(response.statusCode);
        //print(response.body);
        //print(response.body);
      }
      if (response.statusCode != 200) {
      } else {
        int id_y = 1;

        Constants.moral_index_barData = [];

        Constants.moral_index_bottomTitles2a = [];
        Map<int, int> dailySalesCount = {};
        Map<int, int> dailySalesCount1b = {};
        Map<int, int> dailySalesCount1c = {};
        Map<int, int> monthlySalesCount2a = {};
        Map<int, int> monthlySalesCount2b = {};
        Map<int, int> monthlySalesCount2c = {};
        int monthlyTotal = 0;

        if (selectedButton1 == 1) {
          Constants.moral_index_salesbyagent1a = [];
          Constants.moral_index_bottomTitles1a = [];
          Constants.moral_index_maxY5a = 0;
        } else if (selectedButton1 == 2) {
          Constants.moral_index_salesbyagent2a = [];
          Constants.moral_index_bottomTitles2a = [];
          Constants.moral_index_maxY5b = 0;
        } else if (selectedButton1 == 3 && days_difference < 31) {
          Constants.moral_index_salesbyagent3a = [];
          Constants.moral_index_bottomTitles3a = [];
          Constants.moral_index_maxY5c = 0;
        } else {
          Constants.moral_index_salesbyagent3b = [];
          Constants.moral_index_bottomTitles3b = [];
          Constants.moral_index_maxY5d = 0;
        }
        Constants.moral_index_salesbyagent1b = [];

        var jsonResponse = jsonDecode(response.body);
        //var jsonResponse = jsonDecode(Sample_Jsons.morale_index);
        print("fdfgg $jsonResponse");
        DateTime startDateTime = DateFormat('yyyy-MM-dd').parse(date_from);
        DateTime endDateTime = DateFormat('yyyy-MM-dd').parse(date_to);
        print("date_from $date_from");
        print("date_to $date_to");
        print("date_to $date_to");
        moods_list = jsonResponse["moods"];

        int days_difference1 = endDateTime.difference(startDateTime).inDays;

        if (selectedButton1 == 1) {
          Constants.moral_index_sectionsList1a = [
            salesgridmodel("Happy", jsonResponse["counts_by_type"]["3"] ?? 0),
            salesgridmodel("Unsure", jsonResponse["counts_by_type"]["2"] ?? 0),
            salesgridmodel("Sad", jsonResponse["counts_by_type"]["1"] ?? 0),
          ];
          double happy_value =
              (jsonResponse["counts_by_type"]["3"] ?? 0).toDouble();
          double unsure_value =
              (jsonResponse["counts_by_type"]["2"] ?? 0).toDouble();
          double sad_value =
              (jsonResponse["counts_by_type"]["1"] ?? 0).toDouble();
          double sum_of_values = happy_value + unsure_value + sad_value;
          String happy_percentage =
              (happy_value / sum_of_values).toStringAsFixed(2);
          String unsure_percentage =
              (unsure_value / sum_of_values).toStringAsFixed(2);
          String sad_percentage =
              (sad_value / sum_of_values).toStringAsFixed(2);
          print("sum_of_values $sum_of_values");
          print("happy_percentage $happy_percentage");
          print("unsure_percentage $unsure_percentage");
          print("sad_percentage $sad_percentage");
          Constants.moral_index_pieData_1 = [];
          Constants.moral_index_pieData_1.add(PieChartSectionData(
              value: double.parse(happy_percentage),
              title: "${double.parse(happy_percentage) * 100}%",
              titleStyle: TextStyle(color: Colors.white, fontSize: 11),
              color: Colors.blue));
          Constants.moral_index_pieData_1.add(PieChartSectionData(
              value: double.parse(unsure_percentage),
              title: "${double.parse(unsure_percentage) * 100}%",
              titleStyle: TextStyle(color: Colors.white, fontSize: 11),
              color: Colors.green));
          Constants.moral_index_pieData_1.add(PieChartSectionData(
              value: double.parse(sad_percentage),
              title: "${double.parse(sad_percentage) * 100}%",
              titleStyle: TextStyle(color: Colors.white, fontSize: 11),
              color: Colors.purple));
          barChartData1 == [];

          barChartData1 = processDataForCollectionsCountDaily(jsonResponse);
        } else if (selectedButton1 == 2) {
          Constants.moral_index_sectionsList2a = [
            salesgridmodel("Happy", jsonResponse["counts_by_type"]["3"] ?? 0),
            salesgridmodel("Unsure", jsonResponse["counts_by_type"]["2"] ?? 0),
            salesgridmodel("Sad", jsonResponse["counts_by_type"]["1"] ?? 0),
          ];
          double happy_value =
              (jsonResponse["counts_by_type"]["3"] ?? 0).toDouble();
          double unsure_value =
              (jsonResponse["counts_by_type"]["2"] ?? 0).toDouble();
          double sad_value =
              (jsonResponse["counts_by_type"]["1"] ?? 0).toDouble();
          double sum_of_values = happy_value + unsure_value + sad_value;
          String happy_percentage =
              (happy_value / sum_of_values).toStringAsFixed(2);
          String unsure_percentage =
              (unsure_value / sum_of_values).toStringAsFixed(2);
          String sad_percentage =
              (sad_value / sum_of_values).toStringAsFixed(2);
          print("sum_of_values $sum_of_values");
          print("happy_percentage $happy_percentage");
          print("unsure_percentage $unsure_percentage");
          print("sad_percentage $sad_percentage");
          Constants.moral_index_pieData_2 = [];
          Constants.moral_index_pieData_2.add(PieChartSectionData(
              value: double.parse(happy_percentage),
              title: "${double.parse(happy_percentage) * 100}%",
              titleStyle: TextStyle(color: Colors.white, fontSize: 11),
              color: Colors.blue));
          Constants.moral_index_pieData_2.add(PieChartSectionData(
              value: double.parse(unsure_percentage),
              title: "${double.parse(unsure_percentage) * 100}%",
              titleStyle: TextStyle(color: Colors.white, fontSize: 11),
              color: Colors.green));
          Constants.moral_index_pieData_2.add(PieChartSectionData(
              value: double.parse(sad_percentage),
              title: "${double.parse(sad_percentage) * 100}%",
              titleStyle: TextStyle(color: Colors.white, fontSize: 11),
              color: Colors.purple));
          barChartData2 = processDataForCollectionsCountMonthly(
              response.body, date_from, date_to, context);
        } else if (selectedButton1 == 3 && days_difference1 <= 31) {
          Constants.moral_index_sectionsList3a = [
            salesgridmodel("Happy", jsonResponse["counts_by_type"]["3"] ?? 0),
            salesgridmodel("Unsure", jsonResponse["counts_by_type"]["2"] ?? 0),
            salesgridmodel("Sad", jsonResponse["counts_by_type"]["1"] ?? 0),
          ];
        } else {
          Constants.moral_index_sectionsList3b = [
            salesgridmodel("Happy", jsonResponse["counts_by_type"]["3"] ?? 0),
            salesgridmodel("Unsure", jsonResponse["counts_by_type"]["2"] ?? 0),
            salesgridmodel("Sad", jsonResponse["counts_by_type"]["1"] ?? 0),
          ];
        }
        if (kDebugMode) {
          //print("got here ghhgjjhh ${selectedButton1}");
        }

        print("days_difference1 $days_difference1");
        if (selectedButton1 == 1) {
          processDataForMoraleIndexCountDailylineGraph(
              jsonResponse["totals_daily"] ?? {});
          /*     Constants.moral_index_barChartData1 =
              processDataForMaintenanceCountDaily(
                  jsonResponse["totals_daily"] ?? {});*/
          Constants.moral_index_groupedChartData1 =
              processDataForMoraleIndexGroups(
                  jsonResponse["categorized_by_transactor"] ?? {});
          Map maintenanceByAgent =
              jsonResponse["categorized_by_transactor"] ?? {};
          maintenanceByAgent.forEach((key, value) {
            if (key.isNotEmpty) {
              if (int.tryParse(key ?? 0.toString()) != 0) {
                if (key.isNotEmpty) {
                  Constants.moral_index_salesbyagent1a.add(SalesByAgent(
                      getEmployeeById(int.parse(key.toString())), value));
                }
              }
            }
          });

          //print("fghhg ${jsonResponse["totals_daily"].runtimeType}");
        } else if (selectedButton1 == 2) {
          Constants.moral_index_barChartData2 =
              processDataForMoraleIndexCountMonthly(
                  jsonResponse["grouped_data"], context);
          Constants.moral_index_droupedChartData2 =
              processDataForMoraleIndexGroups(
                  jsonResponse["categorized_by_transactor"]);
          Map moraleIndexByAgent = jsonResponse["categorized_by_transactor"];
          moraleIndexByAgent.forEach((key, value) {
            if (key.isNotEmpty) {
              if (int.parse(key.toString()) != 0) {
                Constants.moral_index_salesbyagent2a.add(SalesByAgent(
                    getEmployeeById(int.parse(key.toString())), value));
              }
            }
          });
          processDataForMaintenanceCountMonthlylineGraph(
              jsonResponse["totals_monthly"]);
        } else if (selectedButton1 == 3 && days_difference1 <= 31) {
          print("fghhgghj ");

          Constants.moral_index_barChartData3 =
              processDataForMaintenanceCountDaily(jsonResponse["grouped_data"]);

          Constants.moral_index_droupedChartData3 =
              processDataForMoraleIndexGroups(jsonResponse["moods"]);
          Map maintenanceByAgent = jsonResponse["categorized_by_transactor"];
          maintenanceByAgent.forEach((key, value) {
            if (int.parse(key.toString()) != 0) {
              print("fgff");
              Constants.moral_index_salesbyagent3a.add(SalesByAgent(
                  getEmployeeById(int.parse(key.toString())), value));
            }
          });
          processDataForMaintenanceCountDailylineGraph2(
              jsonResponse["totals_daily"]);
        } else if (selectedButton1 == 3 && days_difference1 > 31) {
          Constants.moral_index_barChartData4 =
              processDataForMoraleIndexCountMonthly(
                  jsonResponse["grouped_data"], context);
          Constants.moral_index_droupedChartData4 =
              processDataForMoraleIndexGroups(jsonResponse["moods"]);
          Map maintenanceByAgent = jsonResponse["categorized_by_transactor"];
          maintenanceByAgent.forEach((key, value) {
            if (int.parse(key.toString()) != 0) {
              Constants.moral_index_salesbyagent3b.add(SalesByAgent(
                  getEmployeeById(int.parse(key.toString())), value));
            }
          });
          processDataForMaintenanceCountMonthlylineGraph2(
              jsonResponse["totals_monthly"]);
        }
        isLoading = false;
        maintenanceValue.value++;
      }
    });
  } on Exception catch (_, exception) {
    //Exception exc = exception as Exception;
    print(exception);
  }
}

List<String> remove_main_memeber_list = [
  "Add Beneficiary",
  "Add Beneficiary",
  "Add Member",
  "Beneficiary Details",
  "Remove Beneficiary",
  "Removed Member",
];
List<String> remove_dependant_list = [
  "Add Beneficiary",
  "Add Beneficiary",
  "Address Details",
  "Banking Details",
  "Beneficiary Details",
  "Cancellation",
  "Collection Date Change",
  "Combine Premium Change",
  "Continuation",
  "Downgrade",
  "Inception Date",
  "Inception_Date",
  "Payment Method Change",
  "Policy Status Change",
  "Premium Reallocation",
  "Product Change",
  "Product Details",
  "Reinstatement",
  "Remove Beneficiary",
  "Restart",
  "Special Collection Date",
  "Upgrade",
  "Edited Beneficiary",
];
List<String> remove_beficiary_list = [
  "Add Member",
  "Address Details",
  "Banking Details",
  "Collection Date Change",
  "Combine Premium Change",
  "Continuation",
  "Downgrade",
  "Inception Date",
  "Inception_Date",
  "Member Cover Amount",
  "Member Details",
  "Member Rate Update",
  "Payment Method Change",
  "Policy Status Change",
  "Premium Adjustment/Change",
  "Premium Reallocation",
  "Product Change",
  "Product Details",
  "Reinstatement",
  "Removed Member",
  "Restart",
  "Special Collection Date",
  "Upgrade",
  "Cancellation",
  "Edited Beneficiary",
];
List<MoraleIndexCategory> processDataForMaintenanceGroups2(
    Map<String, dynamic> data) {
  List<MoraleIndexCategory> categories = [];

  print("fghfh $data");
  data.forEach((categoryName, categoryItems) {
    print("hgjjhjh $categoryItems");
    List<MoraleIndexCategoryItem> items = [];
    categoryItems.forEach((itemTitle, itemCount) {
      if (itemTitle != "Premium Payment" && itemTitle != "Claim") {
        if (categoryName == "Self") {
          if (!remove_main_memeber_list.contains(itemTitle)) {
            items.add(
                MoraleIndexCategoryItem(title: itemTitle, count: itemCount));
          }
        } else if (categoryName == "Dependant") {
          if (!remove_dependant_list.contains(itemTitle)) {
            items.add(
                MoraleIndexCategoryItem(title: itemTitle, count: itemCount));
          }
        } else if (categoryName == "Beneficiary") {
          if (!remove_beficiary_list.contains(itemTitle)) {
            items.add(
                MoraleIndexCategoryItem(title: itemTitle, count: itemCount));
          }
        }
      }
    });

    categories.add(MoraleIndexCategory(name: categoryName, items: items));
  });
  return categories;
}

List<MoraleIndexCategory> processDataForMoraleIndexGroups(Map data) {
  List<MoraleIndexCategory> categories = [];
  data.forEach((transactor, categoryData) {
    List<MoraleIndexCategoryItem> items = [];

    (categoryData as Map).forEach((categoryID, count) {
      if (getMoodById(int.parse(categoryID.toString())).isNotEmpty) {
        items.add(MoraleIndexCategoryItem(
            title: getMoodById(int.parse(categoryID.toString())),
            count: count));
      }
    });

    //items.sort((a, b) => b.count.compareTo(a.count));

    if (getEmployeeByEmail(transactor).isNotEmpty) {
      categories.add(MoraleIndexCategory(
          name: getEmployeeByEmail(transactor), items: items));
    }
  });

/*  categories.sort((a, b) => b.items
      .fold(0, (prev, item) => prev + item.count)
      .compareTo(a.items.fold(0, (prev, item) => prev + item.count)));*/

  return categories;
}

List<BarChartGroupData> processDataForMaintenanceCountDaily(Map jsonString) {
  Map jsonData = jsonString as Map;

  DateTime now = DateTime.now();
  int currentMonth = now.month;
  int currentYear = now.year;
  int daysInCurrentMonth = DateTime(currentYear, currentMonth + 1, 0).day;
  Map<int, Map<String, double>> dailySales = {
    for (var day = 1; day <= daysInCurrentMonth; day++) day: {}
  };

  // Process the jsonData
  jsonData.forEach((key, value) {
    List<String> parts = key.split("-");
    //print("ghhg");
    //print(parts);

    DateTime date = DateTime.parse(
        parts[0] + "-" + parts[1] + "-" + parts[2].split(" ")[0]);
    String collectionType = parts[3];

    if (date.month == currentMonth && date.year == currentYear) {
      int dayOfMonth = date.day;
      double premium = value.toDouble();

      dailySales[dayOfMonth]!.update(
          collectionType, (existingValue) => existingValue + premium,
          ifAbsent: () => premium);
    }
  });

  List<BarChartGroupData> collectionsGroupedData = [];
  dailySales.forEach((dayOfMonth, salesData) {
    double cumulativeAmount = 0.0;
    List<BarChartRodStackItem> rodStackItems = [];

    //Add purple and green

    salesData.forEach((type, amount) {
      Color? color; // Define color based on the type
      switch (type) {
        case 'Premium Payment':
          color = Colors.blue;
          break;
        case 'Banking Details':
          color = Colors.purple;
          break;
        case 'Cancellation':
          color = Colors.orange;
          break;
        case 'Collection Date Change':
          color = Colors.grey;
          break;
        case 'Payment Method Change':
          color = Colors.green;
          break;

        case 'Add Beneficiary':
          color = Colors.yellow;
          break;

        case 'Member Details':
          color = Colors.green;
          break;
        // Add more cases for different collection types
        default:
          //print("rgfggh $type");
          color = Colors.grey; // Default color for unknown types
      }

      rodStackItems.add(BarChartRodStackItem(
          cumulativeAmount, cumulativeAmount + amount, color!));
      cumulativeAmount += amount;
    });

    // Add a bar for each day of the month
    collectionsGroupedData.add(BarChartGroupData(
      x: dayOfMonth,
      barRods: [
        BarChartRodData(
          toY: cumulativeAmount,
          rodStackItems: rodStackItems.isEmpty
              ? [BarChartRodStackItem(0, 0, Colors.transparent)]
              : rodStackItems,
          borderRadius: BorderRadius.zero,
          width: 8,
        ),
      ],
      barsSpace: 4,
    ));
  });

  return collectionsGroupedData;
}

void processDataForMoraleIndexCountDailylineGraph(Map dailySalesCount) {
  Constants.moral_index_spots1a = [];
  Constants.moral_index_spots1b = [];
  Constants.moral_index_spots1c = [];
  Constants.moral_index_chartKey1a = UniqueKey();
  Constants.moral_index_chartKey1b = UniqueKey();
  Constants.moral_index_chartKey1c = UniqueKey();
  print("fghhg0 $dailySalesCount");
  dailySalesCount.forEach((dateString, count) {
    print("fghhgfghjgjdateString $dateString");
    DateTime parsedDate = DateTime.parse(dateString);

    int day = parsedDate.day;
    if (parsedDate.month == DateTime.now().month &&
        parsedDate.year == DateTime.now().year) {
      Constants.moral_index_spots1a
          .add(FlSpot(day.toDouble(), count.toDouble()));
      Constants.moral_index_spots1b
          .add(FlSpot(day.toDouble(), count.toDouble()));
      Constants.moral_index_spots1c
          .add(FlSpot(day.toDouble(), count.toDouble()));
    }
    if (count > Constants.moral_index_maxY) {
      Constants.moral_index_maxY = count;
    }
  });
  /* dailySalesCount.forEach((day, count) {
    if (kDebugMode) {
      print(day);
    }

  });*/
/*  dailySalesCount.forEach((day, count) {
    if (kDebugMode) {
      print(day);
    }

  });*/
  Constants.moral_index_spots1a.sort((a, b) => a.x.compareTo(b.x));
  Constants.moral_index_spots1b.sort((a, b) => a.x.compareTo(b.x));
  Constants.moral_index_spots1c.sort((a, b) => a.x.compareTo(b.x));
}

void processDataForMaintenanceCountDailylineGraph2(
    Map<String, dynamic> dailySalesCount) {
  Constants.moral_index_spots3a = [];
  Constants.moral_index_spots3b = [];
  Constants.moral_index_spots3c = [];
  Constants.moral_index_chartKey3a = UniqueKey();
  Constants.moral_index_chartKey3b = UniqueKey();
  Constants.moral_index_chartKey3c = UniqueKey();

  print("fghhg ${dailySalesCount.length}");

  dailySalesCount.forEach((dateString, count) {
    DateTime parsedDate = DateTime.parse(dateString);
    int day = parsedDate.day;
    double yValue = (count is int) ? count.toDouble() : 0.0;
    print("fgfhhg $dateString ${day.toDouble()} $yValue");

    Constants.moral_index_spots3a.add(FlSpot(day.toDouble(), yValue));
    if (yValue > Constants.moral_index_maxY3) {
      Constants.moral_index_maxY3 = yValue.round();
    }
  });
  Constants.moral_index_spots3a.sort((a, b) => a.x.compareTo(b.x));

  dailySalesCount.forEach((dateString, count) {
    DateTime parsedDate = DateTime.parse(dateString);
    int day = parsedDate.day;
    double yValue = (count is int) ? count.toDouble() : 0.0;

    Constants.moral_index_spots3b.add(FlSpot(day.toDouble(), yValue));
  });

  dailySalesCount.forEach((dateString, count) {
    DateTime parsedDate = DateTime.parse(dateString);
    int day = parsedDate.day;
    double yValue = (count is int) ? count.toDouble() : 0.0;

    Constants.moral_index_spots3c.add(FlSpot(day.toDouble(), yValue));
  });
}

void processDataForMaintenanceCountMonthlylineGraph(Map dailySalesCount) {
  Constants.moral_index_spots2a = [];
  Constants.moral_index_spots2b = [];
  Constants.moral_index_spots2c = [];
  Constants.moral_index_chartKey2a = UniqueKey();
  Constants.moral_index_chartKey2b = UniqueKey();
  Constants.moral_index_chartKey2c = UniqueKey();
  print("yuu $dailySalesCount");
  dailySalesCount.forEach((dateString, count) {
    DateTime parsedDate = DateTime.parse(dateString + "-01");

    int day = parsedDate.month;
    Constants.moral_index_spots2a.add(FlSpot(day.toDouble(), count.toDouble()));
    Constants.moral_index_spots2b.add(FlSpot(day.toDouble(), count.toDouble()));
    Constants.moral_index_spots2c.add(FlSpot(day.toDouble(), count.toDouble()));
    if (count > Constants.moral_index_maxY2) {
      Constants.moral_index_maxY2 = count;
    }
  });
/*  dailySalesCount.forEach((day, count) {
    if (kDebugMode) {
      print(day);
    }

  });
  dailySalesCount.forEach((day, count) {
    if (kDebugMode) {
      print(day);
    }

  });*/
}

void processDataForMaintenanceCountMonthlylineGraph2(
    Map<String, dynamic> dailySalesCount) {
  Constants.moral_index_spots4a = [];
  Constants.moral_index_spots4b = [];
  Constants.moral_index_spots4c = [];
  Constants.moral_index_chartKey3a = UniqueKey();
  Constants.moral_index_chartKey3b = UniqueKey();
  Constants.moral_index_chartKey3c = UniqueKey();
  print("Data: $dailySalesCount");

  dailySalesCount.forEach((dateString, count) {
    DateTime parsedDate = DateTime.parse(dateString + "-01");

    int month = parsedDate.month;
    double yValue = (count is int) ? count.toDouble() : 0.0;

    Constants.moral_index_spots4a.add(FlSpot(month.toDouble(), yValue));
    if (yValue > Constants.moral_index_maxY4) {
      Constants.moral_index_maxY4 = yValue.round();
    }
  });

  dailySalesCount.forEach((dateString, count) {
    DateTime parsedDate = DateTime.parse(dateString + "-01");
    int month = parsedDate.month;
    double yValue = (count is int) ? count.toDouble() : 0.0;

    Constants.moral_index_spots4b.add(FlSpot(month.toDouble(), yValue));
  });

  dailySalesCount.forEach((dateString, count) {
    DateTime parsedDate = DateTime.parse(dateString + "-01");
    int month = parsedDate.month;
    double yValue = (count is int) ? count.toDouble() : 0.0;

    Constants.moral_index_spots4c.add(FlSpot(month.toDouble(), yValue));
  });
}

List<BarChartGroupData> processDataForMoraleIndexCountMonthly(
    Map<String, dynamic> jsonString, BuildContext context) {
  Map jsonData = jsonString;
  print("vnmjhh $jsonString");

  // Initialize data structure for monthly sales for the current year
  Map<int, Map<String, double>> monthlySales = {
    for (var month = 1; month <= 12; month++) month: {}
  };

  // Process the jsonData
  jsonData.forEach((key, value) {
    if (kDebugMode) {
      print(key);
    }

    List<String> parts = key.split("-");

    // Add "-01" to create a valid date string for parsing
    String dateString = "${parts[0]}-${parts[1]}-01";

    if (kDebugMode) {
      // print("Formatted Date String: $dateString");
    }

    // Parse the date
    DateTime date;
    try {
      date = DateTime.parse(dateString);
    } catch (e) {
      print("Error parsing date: $e");
      return; // Skip this iteration if parsing fails
    }

    // Extract collection type - it's the third part of your split string
    String collectionType = parts[2];

    int month = date.month;
    double premium = value.toDouble();

    monthlySales[month]!.update(
        collectionType, (existingValue) => existingValue + premium,
        ifAbsent: () => premium);
  });
  List<BarChartGroupData> collectionsGroupedData = [];
  monthlySales.forEach((month, salesData) {
    double cumulativeAmount = 0.0;
    List<BarChartRodStackItem> rodStackItems = [];

    // Add colors and rodStackItems as in your original code

    salesData.forEach((type, amount) {
      Color? color; // Define color based on the type
      switch (type) {
        case 'Premium Payment':
          color = Colors.blue;
          break;
        case 'Banking Details':
          color = Colors.purple;
          break;
        case 'Cancellation':
          color = Colors.orange;
          break;
        case 'Collection Date Change':
          color = Colors.grey;
          break;
        case 'Payment Method Change':
          color = Colors.green;
          break;

        case 'Add Beneficiary':
          color = Colors.yellow;
          break;

        case 'Member Details':
          color = Colors.green;
          break;
        // Add more cases for different collection types
        default:
          //print("rgfggh $type");
          color = Colors.grey; // Default color for unknown types
      }

      rodStackItems.add(BarChartRodStackItem(
          cumulativeAmount, cumulativeAmount + amount, color!));
      cumulativeAmount += amount;
    });

    // Add a bar for each month
    collectionsGroupedData.add(BarChartGroupData(
      x: month,
      barRods: [
        BarChartRodData(
          toY: cumulativeAmount,
          rodStackItems: rodStackItems.isEmpty
              ? [BarChartRodStackItem(0, 0, Colors.transparent)]
              : rodStackItems,
          borderRadius: BorderRadius.zero,
          width: 23.5,
        ),
      ],
      barsSpace: 5,
    ));
  });

  return collectionsGroupedData;
}

String getEmployeeById(
  int cec_employeeid,
) {
  String result = "";
  for (var employee in Constants.cec_employees) {
    if (employee['cec_employeeid'].toString() == cec_employeeid.toString()) {
      result =
          "${employee["employee_name"]} ${employee["employee_surname"].toString()}";
      if (kDebugMode) {
        //print("fgfghg $result");
      }
      return result;
    }
  }
  if (result.isEmpty) {
    return "";
  } else
    return result;
}

String getEmployeeByEmail(
  String employee_email,
) {
  String result = "";
  print("hfhggj ${Constants.cec_employees}");
  for (var employee in Constants.cec_employees) {
    if (employee['employee_email'].toString() == employee_email.toString()) {
      result = employee["employee_name"] + " " + employee["employee_surname"];
      if (kDebugMode) {
        //print("fgfghg $result");
      }
      return result;
    }
  }
  if (result.isEmpty) {
    return "";
  } else
    return result;
}

String getBranchById(
  int branch_id,
) {
  String result = "";
  for (var branch in Constants.all_branches) {
    if (branch['cec_organo_branches_id'].toString() == branch_id.toString()) {
      result = branch["branch_name"];
      //print("fgfghg $result");
      return result;
    }
  }
  if (result.isEmpty) {
    return "";
  } else
    return result;
}

String getMoodById(int mood_id) {
  //print("dfdfgmoods_list $moods_list");
  for (var mood in moods_list) {
    if (mood['id'] == mood_id) {
      return mood["mood"];
    }
  }
  return ""; // Return an empty string if no match is found
}

List<BarChartGroupData> processDataForCollectionsCountDaily(jsonString) {
  List<dynamic> jsonData = jsonString["user_moods"];

  DateTime now = DateTime.now();
  int currentMonth = now.month;
  int currentYear = now.year;
  int daysInCurrentMonth = DateTime(currentYear, currentMonth + 1, 0).day;

  // Initialize data structure for daily sales for the current month
  Map<int, Map<String, double>> dailySales = {
    for (var day = 1; day <= daysInCurrentMonth; day++) day: {}
  };

  for (var collectionItem in jsonData) {
    for (var item in collectionItem) {
      DateTime date = DateTime.parse(item['datecreated']);

      if (date.month == currentMonth && date.year == currentYear) {
        int dayOfMonth = date.day;

        // Convert mood_id to a string
        String collectionType = item["mood_id"].toString();

        dailySales[dayOfMonth]!
            .update(collectionType, (value) => value + 1, ifAbsent: () => 1);
      }
    }
  }

  List<BarChartGroupData> collectionsGroupedData = [];
  dailySales.forEach((dayOfMonth, moraledataData) {
    double cumulativeAmount = 0.0;
    List<BarChartRodStackItem> rodStackItems = [];

    //Add purple and green

    moraledataData.forEach((type, amount) {
      Color? color; // Define color based on the type
      switch (type) {
        case '1':
          color = Colors.purple;
          break;
        case '2':
          color = Colors.green;
          break;
        case '3':
          color = Colors.blue;
          break;

        // Add more cases for different collection types
        default:
          //print("rgfggh $type");
          color = Colors.grey; // Default color for unknown types
      }

      rodStackItems.add(BarChartRodStackItem(
          cumulativeAmount, cumulativeAmount + amount, color!));
      cumulativeAmount += amount;
    });

    collectionsGroupedData.add(BarChartGroupData(
      x: dayOfMonth,
      barRods: [
        BarChartRodData(
          toY: cumulativeAmount,
          rodStackItems: rodStackItems.isEmpty
              ? [BarChartRodStackItem(0, 0, Colors.transparent)]
              : rodStackItems,
          borderRadius: BorderRadius.zero,
          width: 8,
        ),
      ],
      barsSpace: 4,
    ));
  });

  return collectionsGroupedData;
}

List<BarChartGroupData> processDataForCollectionsCountMonthly(
    String jsonString, String startDate, String endDate, BuildContext context) {
  List<dynamic> jsonData = jsonDecode(jsonString)["user_moods"];

  DateTime start = DateTime.parse(startDate);
  DateTime end = DateTime.parse(endDate);
  int monthsInRange =
      ((end.year - start.year) * 12) + end.month - start.month + 1;

  Map<int, Map<String, double>> monthlySales = {
    for (var i = 0; i < monthsInRange; i++) i: {}
  };

  for (var collectionItem1 in jsonData) {
    for (var collectionItem in collectionItem1) {
      DateTime dateCreated = DateTime.parse(collectionItem['datecreated']);
      if (dateCreated.isAfter(start.subtract(const Duration(days: 1))) &&
          dateCreated.isBefore(end.add(const Duration(days: 1)))) {
        int monthIndex = ((dateCreated.year - start.year) * 12) +
            dateCreated.month -
            start.month;

        // Check and safely handle mood_id type
        int moodId;
        if (collectionItem["mood_id"] is int) {
          moodId = collectionItem["mood_id"];
        } else if (collectionItem["mood_id"] is String) {
          moodId = int.tryParse(collectionItem["mood_id"]) ??
              0; // Fallback to a default value if parsing fails
        } else {
          continue; // Skip this item if mood_id is neither int nor String
        }

        String moodType = getMoodById(moodId);
        double count = 1.0;

        monthlySales[monthIndex]!
            .update(moodType, (value) => value + count, ifAbsent: () => count);
      }
    }
  }

  // Bar width and space calculations
  double chartWidth = MediaQuery.of(context).size.width;
  double maxBarWidth = 38;
  double minBarSpace = 4;
  double barWidth = min(maxBarWidth, (chartWidth / (1.4 * monthsInRange)));
  double barsSpace = max(minBarSpace,
      (chartWidth - (barWidth * monthsInRange)) / (monthsInRange - 1));

  // Process data into BarChartGroupData
  List<BarChartGroupData> collectionsGroupedData = [];
  monthlySales.forEach((monthIndex, moralIndexData) {
    double cumulativeAmount = 0.0;
    List<BarChartRodStackItem> rodStackItems = [];

    moralIndexData.forEach((type, amount) {
      //print("fgfgf $type $amount");
      Color? color; // Define color based on the type
      switch (type) {
        case 'Happy':
          color = Colors.blue;
          break;
        case 'Unsure':
          color = Colors.green;
          break;
        case 'Sad':
          color = Colors.purple;
          break;
        default:
          //print("rgfggh $type");
          color = Colors.grey; // Default color for unknown types
      }

      rodStackItems.add(BarChartRodStackItem(
          cumulativeAmount, cumulativeAmount + amount, color!));
      cumulativeAmount += amount;
    });

    collectionsGroupedData.add(BarChartGroupData(
      x: monthIndex + 1,
      barRods: [
        BarChartRodData(
          toY: cumulativeAmount,
          rodStackItems: rodStackItems,
          borderRadius: BorderRadius.zero,
          width: barWidth,
        ),
      ],
      barsSpace: 6,
    ));
  });

  return collectionsGroupedData;
}

Color getColorForMood(String mood) {
  Color? color; // Define color based on the type
  switch (mood) {
    case '1':
      color = Colors.purple;
      break;
    case '2':
      color = Colors.green;
      break;
    case '3':
      color = Colors.blue;
      break;

    // Add more cases for different collection types
    default:
      //print("rgfggh $type");
      color = Colors.grey; // Default color for unknown types
  }
  return color;
}
