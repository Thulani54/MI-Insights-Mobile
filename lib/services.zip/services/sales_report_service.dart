import 'dart:convert';

import 'package:community_charts_flutter/community_charts_flutter.dart'
    as charts;
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mi_insights/models/Product.dart';
import 'package:mi_insights/screens/Reports/SalesReport.dart';

import '../constants/Constants.dart';
import '../models/OrdinalSales.dart';
import '../models/SalesByAgent.dart';
import '../models/SalesByBranch.dart';
import '../models/salesgridmodel.dart';

Future<void> getSalesReport(String date_from, String date_to,
    int selectedButton1, int days_difference, BuildContext context) async {
  try {
    if (kDebugMode) {
      // print("baseUrl $baseUrl");
    }
    List<Map<String, dynamic>> sales = [];
    Map<String, List<Map<String, dynamic>>> groupedSales1a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales1b = {};
    Map<String, List<Map<String, dynamic>>> groupedSales1c = {};

    Map<String, List<Map<String, dynamic>>> groupedSales2a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales2b = {};
    Map<String, List<Map<String, dynamic>>> groupedSales2c = {};

    Map<String, List<Map<String, dynamic>>> groupedSales3a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales3b = {};
    Map<String, List<Map<String, dynamic>>> groupedSales3c = {};

    Map<String, List<Map<String, dynamic>>> groupedSales4a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales4b = {};
    Map<String, List<Map<String, dynamic>>> groupedSales4c = {};

    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1b = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1c = {};

    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2b = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2c = {};

    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3b = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3c = {};

    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch4a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch4b = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch4c = {};
    String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

    Map<String, String>? payload = {
      "client_id": "${Constants.cec_client_id}",
      "start_date": date_from,
      "end_date": date_to
    };
    await http
        .post(
            Uri.parse(
              baseUrl,
            ),
            body: payload)
        .then((value) {
      http.Response response = value;

      if (response.statusCode != 200) {
      } else {
        Constants.sales_barData = [];
        Constants.sales_pieData = [];

        Constants.sales_bottomTitles2a = [];
        Map<int, int> salesCount1a = {};
        Map<int, int> salesCount1b = {};
        Map<int, int> salesCount1c = {};

        Map<int, int> salesCount2a = {};
        Map<int, int> salesCount2b = {};
        Map<int, int> salesCount2c = {};

        Map<int, int> salesCount3a = {};
        Map<int, int> salesCount3b = {};
        Map<int, int> salesCount3c = {};

        Map<int, int> monthlySalesCount3a = {};
        Map<int, int> monthlySalesCount3b = {};
        Map<int, int> monthlySalesCount3c = {};

        Map<int, int> monthlySalesCount4a = {};
        Map<int, int> monthlySalesCount4b = {};
        Map<int, int> monthlySalesCount4c = {};
        int monthlyTotal = 0;

        var jsonResponse = jsonDecode(response.body)["sales"];
        var jsonResponse2 = jsonDecode(response.body)["grouped_by_product"];
        if (kDebugMode) {
          print("hfggj ${jsonResponse.runtimeType}");
          print("hkjoiuioii ${response.statusCode}");
          print("hkjoiuioii ${response.body}");
        }

        if (selectedButton1 == 1) {
          Constants.jsonMonthlySalesData1 = jsonResponse;
          print("fggfhhg ${jsonResponse2}");
          List? m1 = jsonResponse2 ?? {};
          if (m1!.isNotEmpty) {
            m1.forEach((value) {
              Map m1 = value as Map;
              print(
                  "dgffnjhj ${m1["product"]} ${m1["product_type"]} ${m1["count"]}");
              Constants.salesProductsGrouped1a
                  .add(Product(m1["product"], m1["product_type"], m1["count"]));
            });
          }
        }
        if (selectedButton1 == 2) {
          Constants.jsonMonthlySalesData2 = jsonResponse;
          List? m1 = jsonResponse2 ?? {};
          if (m1!.isNotEmpty) {
            m1.forEach((value) {
              Map m1 = value as Map;
              print(
                  "dgffnjhj ${m1["product"]} ${m1["product_type"]} ${m1["count"]}");
              Constants.salesProductsGrouped2a
                  .add(Product(m1["product"], m1["product_type"], m1["count"]));
            });
          }
        }
        if (selectedButton1 == 3) {
          Constants.jsonMonthlySalesData3 = jsonResponse;
          List? m1 = jsonResponse2 ?? {};
          if (m1!.isNotEmpty) {
            m1.forEach((value) {
              Map m1 = value as Map;
              print(
                  "dgffnjhj ${m1["product"]} ${m1["product_type"]} ${m1["count"]}");
              if (days_difference < 36)
                Constants.salesProductsGrouped3a.add(
                    Product(m1["product"], m1["product_type"], m1["count"]));
            });
          }
        }
        if (selectedButton1 == 4) {
          Constants.jsonMonthlySalesData4 = jsonResponse;
        }
        if (kDebugMode) {
          /* print(
              "formattedStartDate2aiab ${date_from} formattedStartDate2aia ${date_to}");*/
        }

        if (jsonResponse is List) {
          sales = List<Map<String, dynamic>>.from(jsonResponse);

          if (selectedButton1 == 1) {
            Constants.sales_salesbybranch1a.clear();
            Constants.sales_salesbybranch1b.clear();
            Constants.sales_salesbybranch1c.clear();
            Constants.sales_bardata2a.clear();
            Constants.sales_bardata2b.clear();
            Constants.sales_bardata2c.clear();
            Constants.sales_salesbyagent1a = [];
            Constants.sales_salesbyagent1b = [];
            Constants.sales_salesbyagent1c = [];

            Constants.sales_maxY5a = 0;
            Constants.sales_sectionsList1a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            if (kDebugMode) {
              // print("got here 1 ${baseUrl}");
            }

            for (var sale in sales) {
              dynamic assignedTo = sale['assigned_to'];

              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              DateTime date = DateTime.parse(sale['sale_datetime']);

              // Adjust the date if it's on a weekend
              if (date.day == 1) {
              } else if (date.weekday == DateTime.saturday) {
                // print("date is a saturday ${sale['sale_datetime']}");
                date = date.add(Duration(days: 2)); // Move to Monday
              } else if (date.weekday == DateTime.sunday) {
                if (kDebugMode) {
                  //  print("date is a sunday ${sale['sale_datetime']}");
                }
                date = date.add(Duration(days: 1)); // Move to Monday
              }

              // Only consider dates in the current month
              if (date.month == DateTime.now().month &&
                  date.year == DateTime.now().year) {
                salesCount1a.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
                DateTime dateWithSameTime =
                    DateTime(date.year, date.month, date.day, 0, 0, 0, 0);
                Constants.dailySalesCount_new.update(
                    dateWithSameTime, (value) => value + 1,
                    ifAbsent: () => 1);

                if (sale["status"] == "Inforced")
                  salesCount1b.update(date.day, (value) => value + 1,
                      ifAbsent: () => 1);
                if (sale["status"] != "Inforced")
                  salesCount1c.update(date.day, (value) => value + 1,
                      ifAbsent: () => 1);
                monthlyTotal += 1; // Increment the monthly total
              }

              Constants.sales_sectionsList1a[0].amount++;

              if (sale["status"] == "Inforced") {
                Constants.sales_sectionsList1a[1].amount++;
              } else {
                Constants.sales_sectionsList1a[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales1a.putIfAbsent(employeeName, () => []);
                groupedSales1a[employeeName]!.add(sale);

                if (sale["status"] == "Inforced") {
                  groupedSales1b.putIfAbsent(
                      employeeName, () => <Map<String, dynamic>>[]);
                  groupedSales1b[employeeName]!
                      .add(sale as Map<String, dynamic>);
                }

                if (sale["status"] != "Inforced")
                  groupedSales1c.putIfAbsent(employeeName, () => []);
                if (sale["status"] != "Inforced")
                  groupedSales1c[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (kDebugMode) {
                //print("branchId $branchId");
              }
              String branch_name = getBranchById(branchId);
              if (branch_name.isEmpty) {
                print("branch_name1 $branchId $branch_name");
              }

              groupedSalesByBranch1a.putIfAbsent(branch_name, () => []);
              groupedSalesByBranch1a[branch_name]?.add(sale);

              if (sale["status"] == "Inforced")
                groupedSalesByBranch1b.putIfAbsent(branch_name, () => []);
              if (sale["status"] == "Inforced")
                groupedSalesByBranch1b[branch_name]?.add(sale);

              if (sale["status"] != "Inforced")
                groupedSalesByBranch1c.putIfAbsent(branch_name, () => []);
              if (sale["status"] != "Inforced")
                groupedSalesByBranch1c[branch_name]?.add(sale);
            }
            Constants.sales_spots1a = [];
            Constants.sales_spots1b = [];
            Constants.sales_spots1c = [];
            Constants.sales_chartKey1a = UniqueKey();
            Constants.sales_chartKey1b = UniqueKey();
            Constants.sales_chartKey1c = UniqueKey();
            salesCount1a.forEach((day, count) {
              //print("ghhgsd $day $count");
              if (kDebugMode) {
                //  print(day);
              }
              Constants.sales_spots1a
                  .add(FlSpot(day.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY) {
                Constants.sales_maxY = count;
              }
            });
            salesCount1b.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots1b
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            salesCount1c.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots1c
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            groupedSales1a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent1a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            groupedSales1b.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent1b
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            groupedSales1c.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent1c
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent1b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent1c
                .sort((a, b) => b.sales.compareTo(a.sales));

            int id_y = 0;

            Constants.sales_bardata1a = [];
            Constants.sales_bardata1b = [];
            Constants.sales_bardata1c = [];
            groupedSalesByBranch1a.forEach((key, value) {
              Constants.sales_salesbybranch1a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch1b.forEach((key, value) {
              Constants.sales_salesbybranch1b
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch1c.forEach((key, value) {
              Constants.sales_salesbybranch1c
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });

            Constants.sales_salesbybranch1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch1b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch1c
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch1a) {
              if (element.sales > Constants.sales_bar_maxY1a) {
                Constants.sales_bar_maxY1a = element.sales;
              }

              Constants.sales_bottomTitles1a.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales1a
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData1a.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            for (var element in Constants.sales_salesbybranch1b) {
              if (element.sales > Constants.sales_bar_maxY1b) {
                Constants.sales_bar_maxY1b = element.sales;
              }

              Constants.sales_bottomTitles1b.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales1b
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData1b.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            for (var element in Constants.sales_salesbybranch1c) {
              if (element.sales > Constants.sales_bar_maxY1c) {
                Constants.sales_bar_maxY1c = element.sales;
              }

              Constants.sales_bottomTitles1c.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales1c
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData1c.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }

            if (kDebugMode) {
              //  print("sales_maxY5a ${Constants.sales_maxY5a}");
            }
            Constants.sales_salesbyagent1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent5a =
                Constants.sales_salesbyagent1a.reversed.toList();
            Constants.sales_salesbyagent5b =
                Constants.sales_salesbyagent1b.reversed.toList();
            Constants.sales_salesbyagent5c =
                Constants.sales_salesbyagent1c.reversed.toList();
            Constants.sales_ordinary_sales1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata1a.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales1a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata1b.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales1b,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata1c.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales1c,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
          } else if (selectedButton1 == 2) {
            Constants.sales_salesbybranch2a.clear();
            Constants.sales_salesbybranch2b.clear();
            Constants.sales_salesbybranch2c.clear();
            Constants.sales_bardata2a.clear();
            Constants.sales_bardata2b.clear();
            Constants.sales_bardata2c.clear();
            Constants.sales_salesbyagent2a = [];
            Constants.sales_salesbyagent2b = [];
            Constants.sales_salesbyagent2c = [];

            Constants.sales_bottomTitles2a = [];
            Constants.sales_maxY5b = 0;
            Constants.sales_sectionsList2a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            // print("got here 2 ${baseUrl}");
            for (var sale in sales) {
              dynamic assignedTo = sale['assigned_to'] ?? 0;

              int branchId = sale['branch_id'] ?? -1;
              if (assignedTo == 10262) {
                print("fgfgdfdf $sale");
              }

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              DateTime date = DateTime.parse(sale['sale_datetime']);
              int month = date.month;

              salesCount2a.update(month, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["status"] == "Inforced")
                salesCount2b.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              if (sale["status"] != "Inforced")
                salesCount2c.update(month, (value) => value + 1,
                    ifAbsent: () => 1);

              Constants.sales_sectionsList2a[0].amount++;

              if (sale["status"] == "Inforced") {
                Constants.sales_sectionsList2a[1].amount++;
              } else {
                Constants.sales_sectionsList2a[2].amount++;
              }
              if (employeeName.isNotEmpty) {
                groupedSales2a.putIfAbsent(employeeName, () => []);
                groupedSales2a[employeeName]!.add(sale);

                if (sale["status"] == "Inforced")
                  groupedSales2b.putIfAbsent(employeeName, () => []);
                if (sale["status"] == "Inforced")
                  groupedSales2b[employeeName]!.add(sale);

                if (sale["status"] != "Inforced")
                  groupedSales2c.putIfAbsent(employeeName, () => []);
                if (sale["status"] != "Inforced")
                  groupedSales2c[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (branchId.toString() != "") {
                //print("branchIdgffg $branchId");
                String branch_name = getBranchById(branchId);
                //print("branch_name1 $branch_name");

                groupedSalesByBranch2a.putIfAbsent(branch_name, () => []);
                groupedSalesByBranch2a[branch_name]?.add(sale);
                if (sale["status"] == "Inforced")
                  groupedSalesByBranch2b.putIfAbsent(branch_name, () => []);
                if (sale["status"] == "Inforced")
                  groupedSalesByBranch2b[branch_name]?.add(sale);

                if (sale["status"] != "Inforced")
                  groupedSalesByBranch2c.putIfAbsent(branch_name, () => []);
                if (sale["status"] != "Inforced")
                  groupedSalesByBranch2c[branch_name]?.add(sale);
              } else {
                //  print("Branch id is empty: $branchId");
              }
            }

            Constants.sales_spots2a = [];
            Constants.sales_spots2b = [];
            Constants.sales_spots2c = [];
            Constants.sales_chartKey2a = UniqueKey();
            Constants.sales_chartKey2b = UniqueKey();
            Constants.sales_chartKey2c = UniqueKey();
            salesCount2a.forEach((month, count) {
              print("fgghhg $month $count");
              Constants.sales_spots2a
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });
            salesCount2b.forEach((month, count) {
              Constants.sales_spots2b
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });
            salesCount2c.forEach((month, count) {
              Constants.sales_spots2c
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });

            // Sort the spots by month
            Constants.sales_spots2a.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots2b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots2c.sort((a, b) => a.x.compareTo(b.x));
            groupedSales2a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));
                /*    if (employee_name == "Fikile Luvuno") {
                  print("hghghg $key");
                }
*/
                if (employee_name.isNotEmpty)
                  Constants.sales_salesbyagent2a
                      .add(SalesByAgent(employee_name, value.length));
                /*    sheet
                    .cell(CellIndex.indexByString(
                        "A${Constants.sales_salesbyagent2a.length}"))
                    .value = TextCellValue(employee_name);
                sheet
                    .cell(CellIndex.indexByString(
                        "B${Constants.sales_salesbyagent2a.length}"))
                    .value = TextCellValue(value.length.toString());
                List<int>? fileBytes = excel.save();
                // print('saving executed in ${stopwatch.elapsed}');
                print("fhhgg0 saved");
                if (fileBytes != null) {
                  File("fhhgg0.xlsx")
                    ..createSync(recursive: true)
                    ..writeAsBytesSync(fileBytes);
                }*/
              }
            });
            groupedSales2b.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent2b
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            groupedSales2c.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent2c
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent2b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent2c
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            Constants.sales_bardata2a = [];
            Constants.sales_bardata2b = [];
            Constants.sales_bardata2c = [];
            groupedSalesByBranch2a.forEach((key, value) {
              Constants.sales_salesbybranch2a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch2b.forEach((key, value) {
              Constants.sales_salesbybranch2b
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch2c.forEach((key, value) {
              Constants.sales_salesbybranch2c
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });

            Constants.sales_salesbybranch2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch2b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch2c
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch2a) {
              if (element.sales > Constants.sales_bar_maxY2a) {
                Constants.sales_bar_maxY2a = element.sales;
              }

              Constants.sales_bottomTitles2a.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales2a
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData2a.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            for (var element in Constants.sales_salesbybranch2b) {
              if (element.sales > Constants.sales_bar_maxY2b) {
                Constants.sales_bar_maxY2b = element.sales;
              }

              Constants.sales_bottomTitles2b.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales2b
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData2b.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            for (var element in Constants.sales_salesbybranch2c) {
              if (element.sales > Constants.sales_bar_maxY2c) {
                Constants.sales_bar_maxY2c = element.sales;
              }

              Constants.sales_bottomTitles2c.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales2c
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData2c.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            Constants.sales_salesbyagent2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales2b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales2c
                .sort((a, b) => b.sales.compareTo(a.sales));

            Constants.sales_salesbyagent6a =
                Constants.sales_salesbyagent2a.reversed.toList();
            Constants.sales_salesbyagent6b =
                Constants.sales_salesbyagent2b.reversed.toList();
            Constants.sales_salesbyagent6c =
                Constants.sales_salesbyagent2c.reversed.toList();

            Constants.sales_bardata2a.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales2a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata2b.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales2b,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata2c.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales2c,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
          } else if (selectedButton1 == 3 && days_difference <= 31) {
            Constants.sales_salesbyagent3a = [];
            Constants.sales_salesbybranch3a.clear();
            Constants.sales_salesbybranch3b.clear();
            Constants.sales_salesbybranch3c.clear();
            Constants.sales_bardata5c.clear();
            Constants.sales_bardata3a.clear();
            Constants.sales_bardata3b.clear();
            Constants.sales_bardata3c.clear();
            Constants.sales_bar_maxY3a = 0;
            Constants.sales_bar_maxY3b = 0;
            Constants.sales_bar_maxY3c = 0;
            salesCount3a = {};
            salesCount3b = {};
            salesCount3c = {};
            groupedSales3a = {};
            groupedSalesByBranch3a = {};
            groupedSalesByBranch3b = {};
            groupedSalesByBranch3b = {};
            Constants.sales_maxY5c = 0;
            Constants.sales_spots3a = [];
            Constants.sales_spots3b = [];
            Constants.sales_spots3c = [];

            Constants.sales_ordinary_sales3a = [];
            Constants.sales_ordinary_sales3b = [];
            Constants.sales_ordinary_sales3c = [];
            Constants.sales_chartKey3a = UniqueKey();
            Constants.sales_chartKey3b = UniqueKey();
            Constants.sales_chartKey3c = UniqueKey();
            Constants.sales_sectionsList3a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            if (kDebugMode) {
              //  print("got here 3 ${baseUrl} ${Constants.sales_bardata5c}");
            }
            for (var sale in sales) {
              dynamic assignedTo = sale['assigned_to'] ?? 0;

              DateTime date = DateTime.parse(sale['sale_datetime']);

              if (date.day == 1) {
              } else if (date.weekday == DateTime.saturday) {
                //  print("date is a saturday ${sale['sale_datetime']}");
                date = date.add(Duration(days: 2)); // Move to Monday
              } else if (date.weekday == DateTime.sunday) {
                if (kDebugMode) {
                  //  print("date is a sunday ${sale['sale_datetime']}");
                }
                date = date.add(Duration(days: 1)); // Move to Monday
              }

              salesCount3a.update(date.day, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["status"] == "Inforced") {
                salesCount3b.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
              }
              if (sale["status"] != "Inforced") {
                salesCount3c.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
              }
              monthlyTotal += 1; // Increment the monthly total

              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList3a[0].amount++;

              if (sale["status"] == "Inforced") {
                Constants.sales_sectionsList3a[1].amount++;
              } else {
                Constants.sales_sectionsList3a[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales3a.putIfAbsent(employeeName, () => []);
                groupedSales3a[employeeName]!.add(sale);

                if (sale["status"] == "Inforced")
                  groupedSales3b.putIfAbsent(employeeName, () => []);
                if (sale["status"] == "Inforced")
                  groupedSales3b[employeeName]!.add(sale);

                if (sale["status"] != "Inforced")
                  groupedSales3c.putIfAbsent(employeeName, () => []);
                if (sale["status"] != "Inforced")
                  groupedSales3c[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }

              String branch_name = getBranchById(branchId);
              // print("branch_name3a $branch_name");

              groupedSalesByBranch3a!.putIfAbsent(branch_name, () => []);
              groupedSalesByBranch3a![branch_name]?.add(sale);
              if (sale["status"] == "Inforced")
                groupedSalesByBranch3b!.putIfAbsent(branch_name, () => []);
              if (sale["status"] == "Inforced")
                groupedSalesByBranch3b![branch_name]?.add(sale);

              if (sale["status"] != "Inforced")
                groupedSalesByBranch3c.putIfAbsent(branch_name, () => []);
              if (sale["status"] != "Inforced")
                groupedSalesByBranch3c[branch_name]?.add(sale);
            }
            int lastDay = 0;
            int xValue = 1;

            salesCount3a.forEach((day, count) {
              print("ssaghsg4 $day $count");
              if (day < lastDay) {
                // This condition indicates the start of a new month
                xValue =
                    lastDay + 1; // Continue from where the last month ended
              } else {
                xValue =
                    day; // Normal progression of days within the same month
              }

              lastDay = day;

              Constants.sales_spots3a
                  .add(FlSpot(xValue.toDouble(), count.toDouble()));

              if (count > Constants.sales_maxY3) {
                Constants.sales_maxY3 = count;
              }
            });
            salesCount3b.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots3b
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            salesCount3c.forEach((day, count) {
              if (kDebugMode) {
                //print(day);
              }
              Constants.sales_spots3c
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            Constants.sales_spots3a.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots3b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots3c.sort((a, b) => a.x.compareTo(b.x));
            groupedSales3a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent3a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            print("fgffggghjg $groupedSales3a");
            groupedSales3b.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent3b
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            groupedSales3c.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent3c
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            groupedSalesByBranch3a!.forEach((key, value) {
              Constants.sales_salesbybranch3a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch3b!.forEach((key, value) {
              Constants.sales_salesbybranch3b
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch3c!.forEach((key, value) {
              Constants.sales_salesbybranch3c
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            Constants.sales_salesbybranch3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch3c
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bottomTitles3a = [];
            Constants.sales_ordinary_sales3a = [];
            // print("sales_salesbybranch3a length ${Constants.sales_salesbybranch3a.length}");
            for (var element in Constants.sales_salesbybranch3a) {
              if (element.sales > Constants.sales_bar_maxY3a) {
                Constants.sales_bar_maxY3a = element.sales;
              }

              Constants.sales_bottomTitles3a.add(element.branch_name);
              Constants.sales_salesbyagent3a
                  .sort((b, a) => a.sales.compareTo(b.sales));
              Constants.sales_salesbyagent3b
                  .sort((b, a) => a.sales.compareTo(b.sales));
              Constants.sales_salesbyagent3c
                  .sort((b, a) => a.sales.compareTo(b.sales));
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales3a
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            for (var element in Constants.sales_salesbybranch3b) {
              if (element.sales > Constants.sales_bar_maxY3b) {
                Constants.sales_bar_maxY3b = element.sales;
              }

              Constants.sales_bottomTitles3b.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales3b
                    .add(OrdinalSales(element.branch_name, element.sales));
            }
            for (var element in Constants.sales_salesbybranch3c) {
              if (element.sales > Constants.sales_bar_maxY3c) {
                Constants.sales_bar_maxY3c = element.sales;
                print("fffhfg ${Constants.sales_bar_maxY3c} ${element.sales}");
              }
              print("fffhf0g ${Constants.sales_bar_maxY3c} ${element.sales}");

              Constants.sales_bottomTitles3c.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales3c
                    .add(OrdinalSales(element.branch_name, element.sales));
            }

            Constants.sales_salesbyagent3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent7a =
                Constants.sales_salesbyagent3a.reversed.toList();
            Constants.sales_salesbyagent7b =
                Constants.sales_salesbyagent3b.reversed.toList();
            Constants.sales_salesbyagent7c =
                Constants.sales_salesbyagent3c.reversed.toList();

            Constants.sales_ordinary_sales3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales3c
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata3a = [];
            Constants.sales_bardata3b = [];
            Constants.sales_bardata3c = [];

            Constants.sales_bardata3a.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales3a',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales3a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            print("dsjhsdh ${Constants.sales_bardata3a}");
            Constants.sales_bardata3b.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales3b,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata3c.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales3c,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            if (kDebugMode) {
              /*   print("sales_maxY5c ${Constants.sales_maxY5c}");
              print(
                  "sales_ordinary_sales3a length ${Constants.sales_ordinary_sales3a.length}");
              print(
                  "sales_bardata5c length2 ${Constants.sales_bardata5c[0].data.length}");
              print(Constants.sales_ordinary_sales3a);*/
            }
            Constants.sales_bardata3a_key = UniqueKey();
            Constants.sales_bardata3b_key = UniqueKey();
            Constants.sales_bardata3c_key = UniqueKey();
            salesValue.value++;
          } else if (selectedButton1 == 3 && days_difference >= 31) {
            Constants.sales_salesbybranch4a.clear();
            Constants.sales_salesbybranch4b.clear();
            Constants.sales_salesbybranch4c.clear();
            Constants.sales_bardata4a.clear();
            Constants.sales_bardata4b.clear();
            Constants.sales_bardata4c.clear();
            Constants.sales_salesbyagent4a = []; ///////////////
            Constants.sales_salesbyagent4b = [];
            Constants.sales_salesbyagent4c = [];
            Constants.sales_ordinary_sales4a = [];
            Constants.sales_ordinary_sales4b = [];
            Constants.sales_ordinary_sales4c = [];

            Constants.sales_bottomTitles3b = [];
            Constants.sales_maxY5d = 0;
            Constants.sales_bar_maxY4a = 0;
            Constants.sales_bar_maxY4b = 0;
            Constants.sales_bar_maxY4c = 0;
            Constants.sales_sectionsList3b = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            // print("got here 2 ${baseUrl}");
            for (var sale in sales) {
              dynamic assignedTo = sale['assigned_to'];
              DateTime date = DateTime.parse(sale['sale_datetime']);
              int month = date.month;

              monthlySalesCount4a.update(month, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["status"] == "Inforced")
                monthlySalesCount4b.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              if (sale["status"] != "Inforced")
                monthlySalesCount4c.update(month, (value) => value + 1,
                    ifAbsent: () => 1);

              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList3b[0].amount++;

              if (sale["status"] == "Inforced") {
                Constants.sales_sectionsList3b[1].amount++;
              } else {
                Constants.sales_sectionsList3b[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales4a.putIfAbsent(employeeName, () => []);
                groupedSales4a[employeeName]!.add(sale);

                if (sale["status"] == "Inforced")
                  groupedSales4b.putIfAbsent(employeeName, () => []);
                if (sale["status"] == "Inforced")
                  groupedSales4b[employeeName]!.add(sale);

                if (sale["status"] != "Inforced")
                  groupedSales4c.putIfAbsent(employeeName, () => []);
                if (sale["status"] != "Inforced")
                  groupedSales4c[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (branchId != null) {
                //print("branchIdgffg $branchId");
                String branch_name = getBranchById(branchId);
                //print("branch_name1 $branch_name");

                groupedSalesByBranch4a!.putIfAbsent(branch_name, () => []);
                groupedSalesByBranch4a[branch_name]?.add(sale);
                if (sale["status"] == "Inforced")
                  groupedSalesByBranch4b!.putIfAbsent(branch_name, () => []);
                if (sale["status"] == "Inforced")
                  groupedSalesByBranch4b![branch_name]?.add(sale);

                if (sale["status"] != "Inforced")
                  groupedSalesByBranch4c.putIfAbsent(branch_name, () => []);
                if (sale["status"] != "Inforced")
                  groupedSalesByBranch4c[branch_name]?.add(sale);
              }
            }
            Constants.sales_spots4a = [];
            Constants.sales_spots4b = [];
            Constants.sales_spots4c = [];
            Constants.sales_chartKey4a = UniqueKey();
            Constants.sales_chartKey4b = UniqueKey();
            Constants.sales_chartKey4c = UniqueKey();
            monthlySalesCount4a.forEach((month, count) {
              Constants.sales_spots4a
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });
            monthlySalesCount4b.forEach((month, count) {
              Constants.sales_spots4b
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });
            monthlySalesCount4c.forEach((month, count) {
              Constants.sales_spots4c
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });

            // Sort the spots by month
            Constants.sales_spots4a.sort((a, b) => a.x.compareTo(b.x));
            /*   Constants.sales_spots4b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots4c.sort((a, b) => a.x.compareTo(b.x));*/

            groupedSales4a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent4a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            groupedSales4b.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent4b
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            groupedSales4c.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent4c
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            // print("groupedSales3b");
            // print(groupedSales3b);
            Constants.sales_salesbyagent4a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent4b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent4c
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbyagent8a =
                Constants.sales_salesbyagent4a.reversed.toList();
            Constants.sales_salesbyagent8b =
                Constants.sales_salesbyagent4b.reversed.toList();
            Constants.sales_salesbyagent8c =
                Constants.sales_salesbyagent4c.reversed.toList();
            int id_y = 0;
            Constants.sales_bardata5d = [];
            groupedSalesByBranch4a.forEach((key, value) {
              //print("Constants.maxY ${Constants.sales_maxY}");

              Constants.sales_salesbybranch4a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch4b.forEach((key, value) {
              //print("Constants.maxY ${Constants.sales_maxY}");

              Constants.sales_salesbybranch4b
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            groupedSalesByBranch4c.forEach((key, value) {
              //print("Constants.maxY ${Constants.sales_maxY}");

              Constants.sales_salesbybranch4c
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            // print("groupedSalesByBranch2a");
            // print(groupedSalesByBranch3b);
            Constants.sales_salesbybranch4a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch4b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch4c
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch4a) {
              if (element.sales > Constants.sales_bar_maxY4a) {
                Constants.sales_bar_maxY4a = element.sales;
              }

              Constants.sales_bottomTitles4a.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales4a
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            for (var element in Constants.sales_salesbybranch4b) {
              if (element.sales > Constants.sales_bar_maxY4b) {
                Constants.sales_bar_maxY4b = element.sales;
              }

              Constants.sales_bottomTitles4b.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales4b
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            for (var element in Constants.sales_salesbybranch4c) {
              if (element.sales > Constants.sales_bar_maxY4c) {
                Constants.sales_bar_maxY4c = element.sales;
              }

              Constants.sales_bottomTitles4c.add(element.branch_name);
              if (element.branch_name.toString().isNotEmpty)
                Constants.sales_ordinary_sales4c
                    .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              /*print("sales_maxY5d ${Constants.sales_maxY5d}");
              print(
                  "sales_ordinary_sales3b length ${Constants.sales_ordinary_sales3b.length}");
              print(
                  "sales_bardata5c length ${Constants.sales_bardata5d.length}");
              print(Constants.sales_ordinary_sales3b);
              print(Constants.sales_ordinary_sales3b);*/
            }
            if (kDebugMode) {
              //print("ffgfh ${Constants.sales_maxY5b}");
            }
            Constants.sales_salesbyagent3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales4a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales4b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales4c
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata4a = [];
            Constants.sales_bardata4b = [];
            Constants.sales_bardata4c = [];
            Constants.sales_bardata4a.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales4a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata4b.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales4b,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata4c.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales4c,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            Constants.sales_bardata4a_key = UniqueKey();
            Constants.sales_bardata4b_key = UniqueKey();
            Constants.sales_bardata4c_key = UniqueKey();
            salesValue.value++;
          }
        }
      }
    });
  } on Exception catch (_, exception) {
    //Exception exc = exception as Exception;
    // print(exception);
  }
}

String getEmployeeById(
  int cec_employeeid,
) {
  String result = "";
  for (var employee in Constants.cec_employees) {
    if (employee['cec_employeeid'].toString() == cec_employeeid.toString()) {
      result =
          "${employee["employee_name"]} ${employee["employee_surname"].toString()}";
      if (kDebugMode) {
        //print("fgfghg $result");
      }
      return result;
    }
  }
  if (result.isEmpty) {
    return "";
  } else
    return result;
}

String getBranchById(
  int branch_id,
) {
  String result = "";
  for (var branch in Constants.all_branches) {
    if (branch['cec_organo_branches_id'].toString() == branch_id.toString()) {
      result = branch["branch_name"];
      //print("fgfghg $result");
      return result;
    }
  }
  if (result.isEmpty) {
    print("Branch is empty 2 $branch_id $result");
    return "";
  } else
    return result;
}
