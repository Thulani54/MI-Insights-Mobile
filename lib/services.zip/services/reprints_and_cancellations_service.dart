import "dart:convert";
import "dart:math";

import "package:fl_chart/fl_chart.dart";
import "package:flutter/foundation.dart";
import "package:flutter/material.dart";
import "package:http/http.dart" as http;
import "package:intl/intl.dart";

import "../constants/Constants.dart";
import "../screens/Reports/CollectionsReport.dart" as cllc;
import "../screens/Reports/ReprintsAndCancellations.dart";

Future<void> getReprintsData(String date_from, String date_to,
    int selectedButton1, BuildContext context) async {
  String baseUrl =
      "https://miinsightsapps.net/files/get_reprints_and_cancellations_data/";
  int days_difference = 0;
  DateTime startDateTime = DateFormat('yyyy-MM-dd').parse(date_from);
  DateTime endDateTime = DateFormat('yyyy-MM-dd').parse(date_to);

  days_difference = endDateTime.difference(startDateTime).inDays;

  try {
    Map<String, String>? payload = {
      "client_id": Constants.cec_client_id.toString(),
      "start_date": date_from,
      "end_date": date_to
    };
    if (kDebugMode) {
      //print("baseUrl $baseUrl");
      //print("payload $payload");
    }

    await http
        .post(
      Uri.parse(
        baseUrl,
      ),
      body: payload,
    )
        .then((value) {
      if (selectedButton1 == 1) {}
      http.Response response = value;
      if (response.statusCode != 200) {
      } else {
        var jsonResponse1 = jsonDecode(response.body);
        print("fgghhgg0 $jsonResponse1");
        print("fgghhgg1 ${jsonResponse1["reprints_total_counts"][1]}");
        print(
            "fgghhgg2 ${jsonResponse1["reprints_total_counts"][1]["total_amount"]}");
        print("fgghhgg2 ${jsonResponse1["reprints_total_counts"][1]["count"]}");

        if (selectedButton1 == 1) {
          Constants.reprints_sectionsList1a = [
            cllc.salesgridmodel1("Approved", 0, 0),
            cllc.salesgridmodel1("Expired & Declined", 0, 0),
            cllc.salesgridmodel1("Pending", 0, 0),
          ];

          Constants.reprints_sectionsList1a[0].amount =
              jsonResponse1["reprints_total_counts"][1]["total_amount"];
          Constants.reprints_sectionsList1a[0].count =
              jsonResponse1["reprints_total_counts"][1]["count"].round();

          Constants.reprints_sectionsList1a[1].amount =
              jsonResponse1["reprints_total_counts"][2]["total_amount"];
          Constants.reprints_sectionsList1a[1].count =
              jsonResponse1["reprints_total_counts"][2]["count"].round();

          Constants.reprints_sectionsList1a[2].amount =
              jsonResponse1["reprints_total_counts"][0]["total_amount"];
          Constants.reprints_sectionsList1a[2].count =
              jsonResponse1["reprints_total_counts"][0]["count"].round();
          reprints_barChartData1 = [];
          reprints_barChartData1 = processDataForReprintsDaily(response.body);
        } else if (selectedButton1 == 2) {
          Constants.reprints_sectionsList2a = [
            cllc.salesgridmodel1("Approved", 0, 0),
            cllc.salesgridmodel1("Expired & Declined", 0, 0),
            cllc.salesgridmodel1("Pending", 0, 0),
          ];

          Constants.reprints_sectionsList2a[0].amount =
              jsonResponse1["reprints_total_counts"][1]["total_amount"];
          Constants.reprints_sectionsList2a[0].count =
              jsonResponse1["reprints_total_counts"][1]["count"].round();

          Constants.reprints_sectionsList2a[1].amount =
              jsonResponse1["reprints_total_counts"][2]["total_amount"];
          Constants.reprints_sectionsList2a[1].count =
              jsonResponse1["reprints_total_counts"][2]["count"].round();

          Constants.reprints_sectionsList2a[2].amount =
              jsonResponse1["reprints_total_counts"][0]["total_amount"];
          Constants.reprints_sectionsList2a[2].count =
              jsonResponse1["reprints_total_counts"][0]["count"].round();
          reprints_barChartData2 = [];

          reprints_barChartData2 = processDataForCollectionsCountMonthly(
              response.body, date_from, date_to, context);
        } else if (selectedButton1 == 3 && days_difference <= 31) {
          Constants.reprints_sectionsList3a = [
            cllc.salesgridmodel1("Approved", 0, 0),
            cllc.salesgridmodel1("Expired & Declined", 0, 0),
            cllc.salesgridmodel1("Pending", 0, 0),
          ];

          Constants.reprints_sectionsList3a[0].amount =
              jsonResponse1["reprints_total_counts"][1]["total_amount"];
          Constants.reprints_sectionsList3a[0].count =
              jsonResponse1["reprints_total_counts"][1]["count"].round();

          Constants.reprints_sectionsList3a[1].amount =
              jsonResponse1["reprints_total_counts"][2]["total_amount"];
          Constants.reprints_sectionsList3a[1].count =
              jsonResponse1["reprints_total_counts"][2]["count"].round();

          Constants.reprints_sectionsList3a[2].amount =
              jsonResponse1["reprints_total_counts"][0]["total_amount"];
          Constants.reprints_sectionsList3a[2].count =
              jsonResponse1["reprints_total_counts"][0]["count"].round();
          reprints_barChartData3 = [];
        } else {
          Constants.reprints_sectionsList3b = [
            cllc.salesgridmodel1("Approved", 0, 0),
            cllc.salesgridmodel1("Expired & Declined", 0, 0),
            cllc.salesgridmodel1("Pending", 0, 0),
          ];

          Constants.reprints_sectionsList3b[0].amount =
              jsonResponse1["reprints_total_counts"][1]["total_amount"];
          Constants.reprints_sectionsList3b[0].count =
              jsonResponse1["reprints_total_counts"][1]["count"].round();

          Constants.reprints_sectionsList3b[1].amount =
              jsonResponse1["reprints_total_counts"][2]["total_amount"];
          Constants.reprints_sectionsList3b[1].count =
              jsonResponse1["reprints_total_counts"][2]["count"].round();

          Constants.reprints_sectionsList3b[2].amount =
              jsonResponse1["reprints_total_counts"][0]["total_amount"];
          Constants.reprints_sectionsList3b[2].count =
              jsonResponse1["reprints_total_counts"][0]["count"].round();
          reprints_barChartData4 = [];
        }
      }
    });
  } on Exception catch (_, exception) {
    //Exception exc = exception as Exception;
    print(exception);
  }
}

Map<Color, int> colorOrder = {
  Colors.blue: 1,
  Colors.purple: 2,
  Colors.green: 3,
};
List<BarChartGroupData> processDataForReprintsDaily(String jsonString) {
  List<dynamic> jsonData =
      jsonDecode(jsonString)["reprints_total_counts_by_date"];
  jsonData = [
    {
      "reprints_total_counts": [
        {"status": "Awaiting Action", "count": 0, "total_amount": 0.0},
        {"status": "Approved", "count": 2, "total_amount": 230.0},
        {"status": "Declined", "count": 0, "total_amount": 0.0},
        {"status": "Expired", "count": 0, "total_amount": 0.0}
      ],
      "reprints_total_counts_by_date": [
        {"date_or_month": "2024-01-01", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-01",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-01", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-01", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-02", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-02",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-02", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-02", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-03", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-03",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-03", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-03", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-04", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-04",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-04", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-04", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-05", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-05",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-05", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-05", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-06", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-06",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-06", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-06", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-07", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-07",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-07", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-07", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-08", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-08",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-08", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-08", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-09", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-09",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-09", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-09", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-10", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-10",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-10", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-10", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-11", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-11",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-11", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-11", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-12", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-12",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-12", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-12", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-13", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-13",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-13", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-13", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-14", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-14",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-14", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-14", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-15", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-15",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-15", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-15", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-16", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-16",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-16", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-16", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-17", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-17",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-17", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-17", "status": "Expired", "count": 0},
        {"date_or_month": "2024-01-18", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-18",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-18", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-18", "status": "Expired", "count": 0}
      ],
      "cancellations_total_counts": [
        {"status": "Awaiting Action", "count": 0, "total_amount": 0.0},
        {"status": "Approved", "count": 0, "total_amount": 0.0},
        {"status": "Declined", "count": 0, "total_amount": 0.0}
      ],
      "cancellations_total_counts_by_date": [
        {"date_or_month": "2024-01-01", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-01",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-01", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-02", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-02",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-02", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-03", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-03",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-03", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-04", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-04",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-04", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-05", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-05",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-05", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-06", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-06",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-06", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-07", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-07",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-07", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-08", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-08",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-08", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-09", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-09",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-09", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-10", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-10",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-10", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-11", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-11",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-11", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-12", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-12",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-12", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-13", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-13",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-13", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-14", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-14",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-14", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-15", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-15",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-15", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-16", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-16",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-16", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-17", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-17",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-17", "status": "Declined", "count": 0},
        {"date_or_month": "2024-01-18", "status": "Approved", "count": 0},
        {
          "date_or_month": "2024-01-18",
          "status": "Awaiting Action",
          "count": 0
        },
        {"date_or_month": "2024-01-18", "status": "Declined", "count": 0}
      ]
    }
  ];

  DateTime now = DateTime.now();
  int currentMonth = now.month;
  int currentYear = now.year;
  int daysInCurrentMonth = DateTime(currentYear, currentMonth + 1, 0).day;

  // Initialize data structure for daily sales for the current month
  Map<int, Map<String, double>> dailySales = {
    for (var day = 1; day <= daysInCurrentMonth; day++) day: {}
  };

  for (var collectionItem in jsonData) {
    if (collectionItem is Map<String, dynamic>) {
      DateTime date = DateTime.parse(collectionItem['date_or_month']);
      if (date.month == currentMonth && date.year == currentYear) {
        int dayOfMonth = date.day;
        String collectionType = collectionItem["status"];
        double premium = collectionItem["count"].toDouble();

        dailySales[dayOfMonth]!.update(
            collectionType, (value) => value + premium,
            ifAbsent: () => premium);
      }
    }
  }

  List<BarChartGroupData> collectionsGroupedData = [];
  dailySales.forEach((dayOfMonth, salesData) {
    double cumulativeAmount = 0.0;
    List<BarChartRodStackItem> rodStackItems = [];

    var sortedSalesData = sortReprintCancellationsData(salesData);

    sortedSalesData.forEach((entry) {
      String type = entry.key;
      double amount = entry.value;
      Color color;

      switch (type) {
        case 'Approved':
          color = Colors.blue;
          break;
        case 'Declined':
          color = Colors.purple;
          break;
        case 'Awaiting Action':
          color = Colors.orange;
          break;
        default:
          color = Colors.grey;
      }

      rodStackItems.add(BarChartRodStackItem(
          cumulativeAmount, cumulativeAmount + amount, color));
      cumulativeAmount += amount;
    });
    rodStackItems.sort(
        (a, b) => colorOrder[a.color]!.compareTo(colorOrder[b.color] ?? 0));
    rodStackItems = rodStackItems.reversed.toList();

    // Add a bar for each day of the month
    collectionsGroupedData.add(BarChartGroupData(
      x: dayOfMonth,
      barRods: [
        BarChartRodData(
          toY: cumulativeAmount,
          rodStackItems: rodStackItems.isEmpty
              ? [BarChartRodStackItem(0, 0, Colors.transparent)]
              : rodStackItems,
          borderRadius: BorderRadius.zero,
          width: 8,
        ),
      ],
      barsSpace: 4,
    ));
  });

  return collectionsGroupedData;
}

List<BarChartGroupData> processDataForCollectionsCountMonthly(
    String jsonString, String startDate, String endDate, BuildContext context) {
  //print("aaxdss");
  List<dynamic> jsonData =
      jsonDecode(jsonString)["reprints_total_counts_by_date"];
  jsonData = [
    {"date_or_month": "2023-01-01", "status": "Approved", "count": 20},
    {"date_or_month": "2023-01-01", "status": "Awaiting Action", "count": 10},
    {"date_or_month": "2023-01-01", "status": "Declined", "count": 14},
    {"date_or_month": "2023-02-01", "status": "Approved", "count": 10},
    {"date_or_month": "2023-02-01", "status": "Awaiting Action", "count": 60},
    {"date_or_month": "2023-02-01", "status": "Declined", "count": 10},
    {"date_or_month": "2023-03-01", "status": "Approved", "count": 10},
    {"date_or_month": "2023-03-01", "status": "Awaiting Action", "count": 5},
    {"date_or_month": "2023-03-01", "status": "Declined", "count": 8},
    {"date_or_month": "2023-04-01", "status": "Approved", "count": 12},
    {"date_or_month": "2023-04-01", "status": "Awaiting Action", "count": 0},
    {"date_or_month": "2023-04-01", "status": "Declined", "count": 0},
    {"date_or_month": "2023-05-01", "status": "Approved", "count": 0},
    {"date_or_month": "2023-05-01", "status": "Awaiting Action", "count": 0},
    {"date_or_month": "2023-05-01", "status": "Declined", "count": 0},
    {"date_or_month": "2023-06-01", "status": "Approved", "count": 0},
    {"date_or_month": "2023-06-01", "status": "Awaiting Action", "count": 0},
    {"date_or_month": "2023-06-01", "status": "Declined", "count": 0},
    {"date_or_month": "2023-07-01", "status": "Approved", "count": 0},
    {"date_or_month": "2023-07-01", "status": "Awaiting Action", "count": 0},
    {"date_or_month": "2023-07-01", "status": "Declined", "count": 0},
    {"date_or_month": "2023-08-01", "status": "Approved", "count": 0},
    {"date_or_month": "2023-08-01", "status": "Awaiting Action", "count": 0},
    {"date_or_month": "2023-08-01", "status": "Declined", "count": 0},
    {"date_or_month": "2023-09-01", "status": "Approved", "count": 0},
    {"date_or_month": "2023-09-01", "status": "Awaiting Action", "count": 0},
    {"date_or_month": "2023-09-01", "status": "Declined", "count": 0},
    {"date_or_month": "2023-10-01", "status": "Approved", "count": 0},
    {"date_or_month": "2023-10-01", "status": "Awaiting Action", "count": 0},
    {"date_or_month": "2023-10-01", "status": "Declined", "count": 0},
    {"date_or_month": "2023-11-01", "status": "Approved", "count": 0},
  ];

  DateTime end = DateTime.parse(endDate);
  DateTime start = DateTime(end.year - 1, end.month, end.day);
  int monthsInRange = 12;

  // Initialize monthlySales for each month in the range
  Map<int, Map<String, double>> monthlySales = {
    for (var i = 0; i < monthsInRange; i++)
      DateTime(end.year, end.month - i, 1).month: {}
  };

  for (var collectionItem in jsonData) {
    if (collectionItem is Map<String, dynamic>) {
      DateTime paymentDate = DateTime.parse(collectionItem['date_or_month']);
      if (paymentDate.isAfter(start) &&
          paymentDate.isBefore(end.add(const Duration(days: 1)))) {
        int monthIndex = paymentDate.month;
        String collectionType = collectionItem["status"];
        double premium = collectionItem["count"].toDouble();

        monthlySales.putIfAbsent(monthIndex, () => {});
        monthlySales[monthIndex]?.update(
            collectionType, (value) => value + premium,
            ifAbsent: () => premium);
      }
    }
  }

  monthlySales = monthlySales.entries
      .toList()
      .reversed
      .fold<Map<int, Map<String, double>>>({},
          (Map<int, Map<String, double>> newMap, entry) {
    newMap[entry.key] = entry.value;
    return newMap;
  });

  int numberOfBars = monthlySales.length;
  double chartWidth = MediaQuery.of(context).size.width;
  double maxBarWidth = 30; // Maximum width of a bar
  double minBarSpace = 4; // Minimum space between bars

  double barWidth = min(maxBarWidth, (chartWidth / (2 * numberOfBars)));
  double barsSpace = max(minBarSpace,
      (chartWidth - (barWidth * numberOfBars)) / (numberOfBars - 1));

  List<BarChartGroupData> collectionsGroupedData = [];
  monthlySales.forEach((monthIndex, salesData) {
    //print("aaxdss $monthIndex $salesData");
    double cumulativeAmount = 0.0;
    List<BarChartRodStackItem> rodStackItems = [];
    var sortedSalesData = sortReprintCancellationsData(salesData);

    sortedSalesData.forEach((entry) {
      String type = entry.key;
      double amount = entry.value;
      Color color;

      switch (type) {
        case 'Approved':
          color = Colors.blue;
          break;
        case 'Expired':
          color = Colors.purple;
          break;
        case 'Declined':
          color = Colors.purple;
          break;
        case 'Awaiting Action':
          color = Colors.orange;
          break;
        default:
          color = Colors.grey;
      }

      rodStackItems.add(BarChartRodStackItem(
          cumulativeAmount, cumulativeAmount + amount, color));
      cumulativeAmount += amount;
    });
    rodStackItems.sort(
        (a, b) => colorOrder[a.color]!.compareTo(colorOrder[b.color] ?? 0));
    rodStackItems = rodStackItems.reversed.toList();
    print(rodStackItems);

    collectionsGroupedData.add(BarChartGroupData(
      x: monthIndex,
      barRods: [
        BarChartRodData(
          toY: cumulativeAmount,
          rodStackItems: rodStackItems.isEmpty
              ? [BarChartRodStackItem(0, 0, Colors.transparent)]
              : rodStackItems,
          borderRadius: BorderRadius.zero,
          width: 23.5,
        ),
      ],
      barsSpace: barsSpace,
    ));
  });

  return collectionsGroupedData;
}

List<BarChartGroupData> processDataForCollectionsCountDaily2(
    String jsonString, String startDate, String endDate) {
  List<dynamic> jsonData = jsonDecode(jsonString)["message"];

  DateTime start = DateTime.parse(startDate);
  DateTime end = DateTime.parse(endDate);
  int daysInRange = end.difference(start).inDays;

  Map<int, Map<String, double>> dailySales = {
    for (var i = 0; i <= daysInRange; i++) i: {}
  };

  for (var collectionItem in jsonData) {
    if (collectionItem is Map<String, dynamic>) {
      DateTime paymentDate = DateTime.parse(collectionItem['payment_date']);
      if (paymentDate.isAfter(start.subtract(const Duration(days: 1))) &&
          paymentDate.isBefore(end.add(const Duration(days: 1)))) {
        int dayIndex = paymentDate.difference(start).inDays;
        String collectionType = collectionItem["collection_type"];
        double premium = collectionItem["collected_premium"];

        dailySales[dayIndex]!.update(collectionType, (value) => value + premium,
            ifAbsent: () => premium);
      }
    }
  }

  List<BarChartGroupData> collectionsGroupedData = [];
  dailySales.forEach((dayIndex, salesData) {
    double cumulativeAmount = 0.0;
    List<BarChartRodStackItem> rodStackItems = [];

    var sortedSalesData = sortReprintCancellationsData(salesData);

    sortedSalesData.forEach((entry) {
      String type = entry.key;
      double amount = entry.value;
      Color color;

      switch (type) {
        case 'Cash':
          color = Colors.blue;
          break;
        case 'EFT':
          color = Colors.purple;
          break;
        case 'Debit Order':
          color = Colors.orange;
          break;
        case 'Persal':
          color = Colors.grey;
          break;
        case 'Easypay':
          color = Colors.green;
          break;
        case 'Salary Deduction':
          color = Colors.yellow;
          break;
        default:
          color = Colors.grey; // Default color for unknown types
      }

      rodStackItems.add(BarChartRodStackItem(
          cumulativeAmount, cumulativeAmount + amount, color));
      cumulativeAmount += amount;
    });
    rodStackItems
        .sort((a, b) => colorOrder[a.color]!.compareTo(colorOrder[b.color]!));
    rodStackItems = rodStackItems.reversed.toList();
    print(rodStackItems);

    DateTime barDate = start.add(Duration(days: dayIndex));
    int dayOfMonth = barDate.day;

    collectionsGroupedData.add(BarChartGroupData(
      x: dayOfMonth, // Or use dayIndex if you prefer
      barRods: [
        BarChartRodData(
          toY: cumulativeAmount,
          rodStackItems: rodStackItems.isEmpty
              ? [BarChartRodStackItem(0, 0, Colors.transparent)]
              : rodStackItems,
          borderRadius: BorderRadius.zero,
          width: 8,
        ),
      ],
      barsSpace: 4,
    ));
  });

  return collectionsGroupedData;
}

List<MapEntry<String, double>> sortReprintCancellationsData(
    Map<String, double> salesData) {
  Map<String, Color> typeToColor = {
    'Approved': Colors.blue,
    'Declined': Colors.purple,
    'Expired': Colors.purple,
    'Awaiting Action': Colors.green,
    'Other': Colors.grey,
  };

  Map<Color, int> colorOrder = {
    Colors.blue: 1,
    Colors.purple: 2,
    Colors.green: 3,
    Colors.grey: 4,
  };

  var entries = salesData.entries.toList();

  entries.sort((a, b) {
    Color colorA =
        typeToColor[a.key] ?? Colors.grey; // Default to grey if not found
    Color colorB =
        typeToColor[b.key] ?? Colors.grey; // Default to grey if not found
    return colorOrder[colorA]!.compareTo(colorOrder[colorB]!);
  });

  return entries;
}
