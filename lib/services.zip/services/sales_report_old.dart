import 'dart:convert';

import 'package:community_charts_flutter/community_charts_flutter.dart'
    as charts;
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mi_insights/screens/Reports/SalesReport.dart';

import '../constants/Constants.dart';
import '../models/OrdinalSales.dart';
import '../models/SalesByAgent.dart';
import '../models/SalesByBranch.dart';
import '../models/salesgridmodel.dart';

Future<void> getSalesReport(String date_from, String date_to,
    int selectedButton1, int days_difference, BuildContext context) async {
  https: //uat.miinsightsapps.net/fieldV6/getLeadss?empId=3&searchKey=6&status=all&cec_client_id=1&type=field&startDate=2023-08-01&endDate=2023-08-31
  String baseUrl =
      "https://miinsightsapps.net/parlour/getSalesAll?cec_client_id=${Constants.cec_client_id}&type=field&startDate=${date_from}&endDate=${date_to}";

  try {
    if (kDebugMode) {
      // print("baseUrl $baseUrl");
    }
    List<Map<String, dynamic>> sales = [];
    Map<String, List<Map<String, dynamic>>> groupedSales1a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales2a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales3a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales3b = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3b = {};

    await http.get(
        Uri.parse(
          baseUrl,
        ),
        headers: {
          "Cookie":
              "userid=expiry=2021-04-25&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=&empid=3&empfirstname=Mncedisi&emplastname=Khumalo&email=mncedisi@athandwe.co.za&username=mncedisi@athandwe.co.za&dob=8/28/1985 12:00:00 AM&fullname=Mncedisi Khumalo&userRole=5&userImage=mncedisi@athandwe.co.za.jpg&employedAt=branch&role=leader&branchid=6&branchname=Boulders&jobtitle=Administrative Assistant&dialing_strategy=Campaign Manager&clientname=Test 1 Funeral Parlour&foldername=maafrica&client_abbr=AS&pbx_account=pbx1051ef0a&soft_phone_ip=&agent_type=branch&mip_username=mnces@mip.co.za&agent_email=Mr Mncedisi Khumalo&ViciDial_phone_login=&ViciDial_phone_password=&ViciDial_agent_user=99&ViciDial_agent_password=&device_id=dC7JwXFwwdI:APA91bF0gTbuXlfT6wIcGMLY57Xo7VxUMrMH-MuFYL5PnjUVI0G5X1d3d90FNRb8-XmcjI40L1XqDH-KAc1KWnPpxNg8Z8SK4Ty0xonbz4L3sbKz3Rlr4hyBqePWx9ZfEp53vWwkZ3tx&servername=http://localhost:55661"
        }).then((value) {
      http.Response response = value;
      if (kDebugMode) {
        //print(response.bodyBytes);
        //print(response.statusCode);
        //print(response.body);
        //print(response.body);
      }
      if (response.statusCode != 200) {
      } else {
        Constants.sales_barData = [];
        Constants.sales_pieData = [];

        Constants.sales_bottomTitles2a = [];
        Map<int, int> dailySalesCount = {};
        Map<int, int> dailySalesCount1b = {};
        Map<int, int> dailySalesCount1c = {};
        Map<int, int> dailySalesCount3a = {};
        Map<int, int> dailySalesCount3b = {};
        Map<int, int> dailySalesCount3c = {};
        Map<int, int> monthlySalesCount2a = {};
        Map<int, int> monthlySalesCount2b = {};
        Map<int, int> monthlySalesCount2c = {};

        Map<int, int> monthlySalesCount3a = {};
        Map<int, int> monthlySalesCount3b = {};
        Map<int, int> monthlySalesCount3c = {};
        int monthlyTotal = 0;

        var jsonResponse = jsonDecode(response.body);

        if (kDebugMode) {
          //print(jsonResponse);
        }

        if (jsonResponse is List) {
          sales = List<Map<String, dynamic>>.from(jsonResponse);

          if (selectedButton1 == 1) {
            Constants.sales_salesbyagent1a = [];
            Constants.sales_bottomTitles1a = [];
            Constants.sales_maxY5a = 0;
            Constants.sales_sectionsList1a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            if (kDebugMode) {
              // print("got here 1 ${baseUrl}");
            }
            for (var sale in sales) {
              DateTime date = DateTime.parse(sale['sale_datetime']);

              // Adjust the date if it's on a weekend
              if (date.weekday == DateTime.saturday) {
                // print("date is a saturday ${sale['sale_datetime']}");
                date = date.add(Duration(days: 2)); // Move to Monday
              } else if (date.weekday == DateTime.sunday) {
                if (kDebugMode) {
                  //  print("date is a sunday ${sale['sale_datetime']}");
                }
                date = date.add(Duration(days: 1)); // Move to Monday
              }

              // Only consider dates in the current month
              if (date.month == DateTime.now().month &&
                  date.year == DateTime.now().year) {
                dailySalesCount.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
                if (sale["quote_status"] == "Inforced")
                  dailySalesCount1b.update(date.day, (value) => value + 1,
                      ifAbsent: () => 1);
                if (sale["quote_status"] != "Inforced")
                  dailySalesCount1c.update(date.day, (value) => value + 1,
                      ifAbsent: () => 1);
                monthlyTotal += 1; // Increment the monthly total
              }
              dynamic assignedTo = sale['assigned_to'];
              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList1a[0].amount++;

              if (sale["quote_status"] == "Inforced") {
                Constants.sales_sectionsList1a[1].amount++;
              } else {
                Constants.sales_sectionsList1a[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales1a.putIfAbsent(employeeName, () => []);
                groupedSales1a[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (kDebugMode) {
                //print("branchId $branchId");
              }
              String branch_name = getBranchById(branchId);
              //print("branch_name1 $branch_name");

              groupedSalesByBranch1a.putIfAbsent(branch_name, () => []);
              groupedSalesByBranch1a[branch_name]?.add(sale);
            }
            Constants.sales_spots1a = [];
            Constants.sales_spots1b = [];
            Constants.sales_spots1c = [];
            Constants.sales_chartKey1a = UniqueKey();
            Constants.sales_chartKey1b = UniqueKey();
            Constants.sales_chartKey1c = UniqueKey();
            dailySalesCount.forEach((day, count) {
              if (kDebugMode) {
                //  print(day);
              }
              Constants.sales_spots1a
                  .add(FlSpot(day.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY) {
                Constants.sales_maxY = count;
              }
            });
            dailySalesCount1b.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots1b
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            dailySalesCount1c.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots1c
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            groupedSales1a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent1a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            Constants.sales_bardata5a = [];
            groupedSalesByBranch1a.forEach((key, value) {
              Constants.sales_salesbybranch1a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            Constants.sales_salesbybranch1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch1a) {
              if (element.sales > Constants.sales_maxY5a) {
                Constants.sales_maxY5a = element.sales;
              }

              Constants.sales_bottomTitles1a.add(element.branch_name);
              Constants.sales_ordinary_sales1a
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              //  print("sales_maxY5a ${Constants.sales_maxY5a}");
            }
            Constants.sales_salesbyagent1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5a.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales1a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
          } else if (selectedButton1 == 2) {
            Constants.sales_salesbyagent2a = [];
            Constants.sales_bottomTitles2a = [];
            Constants.sales_maxY5b = 0;
            Constants.sales_sectionsList2a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            // print("got here 2 ${baseUrl}");
            for (var sale in sales) {
              DateTime date = DateTime.parse(sale['sale_datetime']);
              int month = date.month;

              monthlySalesCount2a.update(month, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["quote_status"] == "Inforced")
                monthlySalesCount2b.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              if (sale["quote_status"] != "Inforced")
                monthlySalesCount2c.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              dynamic assignedTo = sale['assigned_to'];
              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList2a[0].amount++;

              if (sale["quote_status"] == "Inforced") {
                Constants.sales_sectionsList2a[1].amount++;
              } else {
                Constants.sales_sectionsList2a[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales2a.putIfAbsent(employeeName, () => []);
                groupedSales2a[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (branchId.toString() != "") {
                //print("branchIdgffg $branchId");
                String branch_name = getBranchById(branchId);
                //print("branch_name1 $branch_name");

                groupedSalesByBranch2a.putIfAbsent(branch_name, () => []);
                groupedSalesByBranch2a[branch_name]?.add(sale);
              } else {
                //  print("Branch id is empty: $branchId");
              }
            }
            Constants.sales_spots2a = [];
            Constants.sales_spots2b = [];
            Constants.sales_spots2c = [];
            Constants.sales_chartKey2a = UniqueKey();
            Constants.sales_chartKey2b = UniqueKey();
            Constants.sales_chartKey2c = UniqueKey();
            monthlySalesCount2a.forEach((month, count) {
              Constants.sales_spots2a
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });
            monthlySalesCount2b.forEach((month, count) {
              Constants.sales_spots2b
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });
            monthlySalesCount2c.forEach((month, count) {
              Constants.sales_spots2c
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });

            // Sort the spots by month
            Constants.sales_spots2a.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots2b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots2c.sort((a, b) => a.x.compareTo(b.x));
            groupedSales2a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent2a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            Constants.sales_bardata5b = [];
            groupedSalesByBranch2a.forEach((key, value) {
              //print("Constants.maxY ${Constants.sales_maxY}");

              Constants.sales_salesbybranch2a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            Constants.sales_salesbybranch2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch2a) {
              if (element.sales > Constants.sales_maxY5b) {
                Constants.sales_maxY5b = element.sales;
              }

              Constants.sales_bottomTitles2a.add(element.branch_name);
              Constants.sales_ordinary_sales2a
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              print("ffgfh ${Constants.sales_maxY5b}");
            }
            Constants.sales_salesbyagent2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5b.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales2a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
          } else if (selectedButton1 == 3 && days_difference <= 31) {
            Constants.sales_salesbyagent3a = [];
            Constants.sales_salesbybranch3a.clear();
            Constants.sales_bardata5c.clear();
            dailySalesCount3a = {};
            dailySalesCount3b = {};
            dailySalesCount3c = {};
            groupedSales3a = {};
            groupedSalesByBranch3a = {};
            Constants.sales_maxY5c = 0;
            Constants.sales_spots3a = [];
            Constants.sales_spots3b = [];
            Constants.sales_spots3c = [];
            Constants.sales_chartKey3a = UniqueKey();
            Constants.sales_chartKey3b = UniqueKey();
            Constants.sales_chartKey3c = UniqueKey();
            Constants.sales_sectionsList3a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            if (kDebugMode) {
              //  print("got here 3 ${baseUrl} ${Constants.sales_bardata5c}");
            }
            for (var sale in sales) {
              DateTime date = DateTime.parse(sale['sale_datetime']);

              // Adjust the date if it's on a weekend
              if (date.weekday == DateTime.saturday) {
                //  print("date is a saturday ${sale['sale_datetime']}");
                date = date.add(Duration(days: 2)); // Move to Monday
              } else if (date.weekday == DateTime.sunday) {
                if (kDebugMode) {
                  //  print("date is a sunday ${sale['sale_datetime']}");
                }
                date = date.add(Duration(days: 1)); // Move to Monday
              }

              dailySalesCount3a.update(date.day, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["quote_status"] == "Inforced") {
                dailySalesCount3b.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
              }
              if (sale["quote_status"] != "Inforced") {
                dailySalesCount3c.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
              }
              monthlyTotal += 1; // Increment the monthly total

              dynamic assignedTo = sale['assigned_to'];
              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList3a[0].amount++;

              if (sale["quote_status"] == "Inforced") {
                Constants.sales_sectionsList3a[1].amount++;
              } else {
                Constants.sales_sectionsList3a[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales3a.putIfAbsent(employeeName, () => []);
                groupedSales3a[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (kDebugMode) {
                // print("branchId3 $branchId");
              }
              String branch_name = getBranchById(branchId);
              // print("branch_name3a $branch_name");

              groupedSalesByBranch3a!.putIfAbsent(branch_name, () => []);
              groupedSalesByBranch3a![branch_name]?.add(sale);
            }
            int lastDay = 0;
            int xValue = 1;

            dailySalesCount3a.forEach((day, count) {
              print("ssaghsg $day $count");
              if (day < lastDay) {
                // This condition indicates the start of a new month
                xValue =
                    lastDay + 1; // Continue from where the last month ended
              } else {
                xValue =
                    day; // Normal progression of days within the same month
              }

              lastDay = day;

              Constants.sales_spots3a
                  .add(FlSpot(xValue.toDouble(), count.toDouble()));

              if (count > Constants.sales_maxY3) {
                Constants.sales_maxY3 = count;
              }
            });
            dailySalesCount3b.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots3b
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            dailySalesCount3c.forEach((day, count) {
              if (kDebugMode) {
                //print(day);
              }
              Constants.sales_spots3c
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            Constants.sales_spots3a.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots3b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots3c.sort((a, b) => a.x.compareTo(b.x));
            groupedSales3a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent3a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            groupedSalesByBranch3a!.forEach((key, value) {
              Constants.sales_salesbybranch3a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            Constants.sales_salesbybranch3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bottomTitles3a = [];
            Constants.sales_ordinary_sales3a = [];
            // print("sales_salesbybranch3a length ${Constants.sales_salesbybranch3a.length}");
            for (var element in Constants.sales_salesbybranch3a) {
              if (element.sales > Constants.sales_maxY5c) {
                Constants.sales_maxY5c = element.sales;
              }

              Constants.sales_bottomTitles3a.add(element.branch_name);
              Constants.sales_ordinary_sales3a
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              /*      print("sales_maxY5c ${Constants.sales_maxY5c}");
              print(
                  "sales_ordinary_sales3a length ${Constants.sales_ordinary_sales3a.length}");
              print(
                  "sales_bardata5c length ${Constants.sales_bardata5c.length}");
              print(Constants.sales_ordinary_sales3a);
              print(Constants.sales_ordinary_sales3a);*/
            }

            Constants.sales_salesbyagent3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5c.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales3a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            if (kDebugMode) {
              /*   print("sales_maxY5c ${Constants.sales_maxY5c}");
              print(
                  "sales_ordinary_sales3a length ${Constants.sales_ordinary_sales3a.length}");
              print(
                  "sales_bardata5c length2 ${Constants.sales_bardata5c[0].data.length}");
              print(Constants.sales_ordinary_sales3a);*/
            }

            salesValue.value++;
          } else if (selectedButton1 == 3 && days_difference >= 31) {
            Constants.sales_salesbyagent3b = [];
            Constants.sales_bottomTitles3b = [];
            Constants.sales_maxY5d = 0;
            Constants.sales_sectionsList3b = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            // print("got here 2 ${baseUrl}");
            for (var sale in sales) {
              DateTime date = DateTime.parse(sale['sale_datetime']);
              int month = date.month;

              monthlySalesCount3a.update(month, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["quote_status"] == "Inforced")
                monthlySalesCount3b.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              if (sale["quote_status"] != "Inforced")
                monthlySalesCount3c.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              dynamic assignedTo = sale['assigned_to'];
              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList3b[0].amount++;

              if (sale["quote_status"] == "Inforced") {
                Constants.sales_sectionsList3b[1].amount++;
              } else {
                Constants.sales_sectionsList3b[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales3b.putIfAbsent(employeeName, () => []);
                groupedSales3b[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (branchId != null) {
                //print("branchIdgffg $branchId");
                String branch_name = getBranchById(branchId);
                //print("branch_name1 $branch_name");

                groupedSalesByBranch3b.putIfAbsent(branch_name, () => []);
                groupedSalesByBranch3b[branch_name]?.add(sale);
              }
            }
            Constants.sales_spots4a = [];
            Constants.sales_spots4b = [];
            Constants.sales_spots4c = [];
            Constants.sales_chartKey4a = UniqueKey();
            Constants.sales_chartKey4b = UniqueKey();
            Constants.sales_chartKey4c = UniqueKey();
            monthlySalesCount3a.forEach((month, count) {
              Constants.sales_spots4a
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });
            monthlySalesCount3b.forEach((month, count) {
              Constants.sales_spots4b
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });
            monthlySalesCount3c.forEach((month, count) {
              Constants.sales_spots4c
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });

            // Sort the spots by month
            Constants.sales_spots4a.sort((a, b) => a.x.compareTo(b.x));
            /*   Constants.sales_spots4b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots4c.sort((a, b) => a.x.compareTo(b.x));*/

            groupedSales3b.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent3b
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            // print("groupedSales3b");
            // print(groupedSales3b);
            Constants.sales_salesbyagent3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            Constants.sales_bardata5d = [];
            groupedSalesByBranch3b.forEach((key, value) {
              //print("Constants.maxY ${Constants.sales_maxY}");

              Constants.sales_salesbybranch3b
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            // print("groupedSalesByBranch2a");
            // print(groupedSalesByBranch3b);
            Constants.sales_salesbybranch3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch3b) {
              if (element.sales > Constants.sales_maxY5d) {
                Constants.sales_maxY5d = element.sales;
              }

              Constants.sales_bottomTitles3b.add(element.branch_name);
              Constants.sales_ordinary_sales3b
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              /*print("sales_maxY5d ${Constants.sales_maxY5d}");
              print(
                  "sales_ordinary_sales3b length ${Constants.sales_ordinary_sales3b.length}");
              print(
                  "sales_bardata5c length ${Constants.sales_bardata5d.length}");
              print(Constants.sales_ordinary_sales3b);
              print(Constants.sales_ordinary_sales3b);*/
            }
            if (kDebugMode) {
              //print("ffgfh ${Constants.sales_maxY5b}");
            }
            Constants.sales_salesbyagent3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5d.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales3b,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            salesValue.value++;
          }
        }
      }
    });
  } on Exception catch (_, exception) {
    //Exception exc = exception as Exception;
    // print(exception);
  }
}

String getEmployeeById(
  int cec_employeeid,
) {
  String result = "";
  for (var employee in Constants.cec_employees) {
    if (employee['cec_employeeid'].toString() == cec_employeeid.toString()) {
      result = employee["employee_name"] + " " + employee["employee_surname"];
      //print("fgfghg $result");
      return result;
    }
  }
  if (result.isEmpty) {
    return "";
  } else
    return result;
}

String getBranchById(
  int branch_id,
) {
  String result = "";
  for (var branch in Constants.all_branches) {
    if (branch['cec_organo_branches_id'].toString() == branch_id.toString()) {
      result = branch["branch_name"];
      //print("fgfghg $result");
      return result;
    }
  }
  if (result.isEmpty) {
    print("Branch is empty 2 $branch_id $result");
    return "";
  } else
    return result;
}

Future<void> getSalesReportB(String date_from, String date_to,
    int selectedButton1, int days_difference, BuildContext context) async {
  String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

  Map<String, String>? payload = {
    "client_id": "${Constants.cec_client_id}",
    "start_date": date_from,
    "end_date": date_to
  };
  try {
    await http
        .post(
            Uri.parse(
              baseUrl,
            ),
            body: payload)
        .then((value) {
      http.Response response = value;
      if (kDebugMode) {}
      if (response.statusCode != 200) {
      } else {
        Constants.sales_barData = [];
        Constants.sales_pieData = [];
        var jsonResponse = jsonDecode(response.body);
        if (selectedButton1 == 1) {
          getSalesReport1(jsonResponse, date_from, date_to, selectedButton1,
              days_difference, context);
        }

        if (selectedButton1 == 2) {
          getSalesReport2(jsonResponse, date_from, date_to, selectedButton1,
              days_difference, context);
        }
        if (selectedButton1 == 3) {
          getSalesReport3(jsonResponse, date_from, date_to, selectedButton1,
              days_difference, context);
        }
      }
    });
  } catch (_, exception) {
    //Exception exc = exception as Exception;
    // print(exception);
  }
}

Future<void> getSalesReport1(jsonResponse, String date_from, String date_to,
    int selectedButton1, int days_difference, BuildContext context) async {
  https: //uat.miinsightsapps.net/fieldV6/getLeadss?empId=3&searchKey=6&status=all&cec_client_id=1&type=field&startDate=2023-08-01&endDate=2023-08-31

  try {
    List<Map<String, dynamic>> sales = [];
    Map<String, List<Map<String, dynamic>>> groupedSales1a = {};

    Constants.sales_barData = [];
    Constants.sales_pieData = [];

    Constants.sales_bottomTitles2a = [];
    Map<int, int> dailySalesCount = {};
    Map<int, int> dailySalesCount1b = {};
    Map<int, int> dailySalesCount1c = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1a = {};
    if (jsonResponse["sales"] is List) {
      sales = List<Map<String, dynamic>>.from(jsonResponse);

      if (selectedButton1 == 1) {
        Constants.sales_salesbyagent1a = [];
        Constants.sales_bottomTitles1a = [];
        Constants.sales_maxY5a = 0;
        Constants.sales_sectionsList1a = [
          salesgridmodel("All Sales", 0),
          salesgridmodel("Inforced Sales", 0),
          salesgridmodel("Not Accepted", 0),
        ];
        if (kDebugMode) {
          // print("got here 1 ${baseUrl}");
        }
        for (var sale in sales) {
          DateTime date = DateTime.parse(sale['sale_datetime']);

          // Adjust the date if it's on a weekend
          if (date.weekday == DateTime.saturday) {
            // print("date is a saturday ${sale['sale_datetime']}");
            date = date.add(Duration(days: 2)); // Move to Monday
          } else if (date.weekday == DateTime.sunday) {
            if (kDebugMode) {
              //  print("date is a sunday ${sale['sale_datetime']}");
            }
            date = date.add(Duration(days: 1)); // Move to Monday
          }

          // Only consider dates in the current month
          if (date.month == DateTime.now().month &&
              date.year == DateTime.now().year) {
            dailySalesCount.update(date.day, (value) => value + 1,
                ifAbsent: () => 1);
            DateTime dateWithSameTime =
                DateTime(date.year, date.month, date.day, 0, 0, 0, 0);
            Constants.dailySalesCount_new.update(
                dateWithSameTime, (value) => value + 1,
                ifAbsent: () => 1);

            if (sale["quote_status"] == "Inforced")
              dailySalesCount1b.update(date.day, (value) => value + 1,
                  ifAbsent: () => 1);
            if (sale["quote_status"] != "Inforced")
              dailySalesCount1c.update(date.day, (value) => value + 1,
                  ifAbsent: () => 1);
          }
          dynamic assignedTo = sale['assigned_to'];
          int branchId = sale['branch_id'] ?? -1;
          String employeeName = assignedTo != null ? assignedTo.toString() : '';
          Constants.sales_sectionsList1a[0].amount++;
          if (sale["quote_status"] == "Inforced") {
            Constants.sales_sectionsList1a[1].amount++;
          } else {
            Constants.sales_sectionsList1a[2].amount++;
          }
          if (employeeName.isNotEmpty) {
            groupedSales1a.putIfAbsent(employeeName, () => []);
            groupedSales1a[employeeName]!.add(sale);
          } else {}
          if (kDebugMode) {}
          String branch_name = getBranchById(branchId);
          groupedSalesByBranch1a.putIfAbsent(branch_name, () => []);
          groupedSalesByBranch1a[branch_name]?.add(sale);
        }
        Constants.sales_spots1a = [];
        Constants.sales_spots1b = [];
        Constants.sales_spots1c = [];
        Constants.sales_chartKey1a = UniqueKey();
        Constants.sales_chartKey1b = UniqueKey();
        Constants.sales_chartKey1c = UniqueKey();
        dailySalesCount.forEach((day, count) {
          print("ghhgsd $day $count");
          if (kDebugMode) {
            //  print(day);
          }
          Constants.sales_spots1a.add(FlSpot(day.toDouble(), count.toDouble()));
          if (count > Constants.sales_maxY) {
            Constants.sales_maxY = count;
          }
        });
        dailySalesCount1b.forEach((day, count) {
          if (kDebugMode) {
            // print(day);
          }
          Constants.sales_spots1b.add(FlSpot(day.toDouble(), count.toDouble()));
        });
        dailySalesCount1c.forEach((day, count) {
          Constants.sales_spots1c.add(FlSpot(day.toDouble(), count.toDouble()));
        });
        groupedSales1a.forEach((key, value) {
          if (key.isNotEmpty) {
            String employee_name = getEmployeeById(int.parse(key));

            Constants.sales_salesbyagent1a
                .add(SalesByAgent(employee_name, value.length));
          }
        });
        Constants.sales_salesbyagent1a
            .sort((a, b) => b.sales.compareTo(a.sales));
        Constants.sales_salesbybranch1a
            .sort((a, b) => b.sales.compareTo(a.sales));
        int id_y = 0;
        Constants.sales_bardata5a = [];
        groupedSalesByBranch1a.forEach((key, value) {
          Constants.sales_salesbybranch1a.add(SalesByBranch(key, value.length));
          if (key.isNotEmpty) {}
        });
        Constants.sales_salesbybranch1a
            .sort((a, b) => b.sales.compareTo(a.sales));
        for (var element in Constants.sales_salesbybranch1a) {
          if (element.sales > Constants.sales_maxY5a) {
            Constants.sales_maxY5a = element.sales;
          }

          Constants.sales_bottomTitles1a.add(element.branch_name);
          Constants.sales_ordinary_sales1a
              .add(OrdinalSales(element.branch_name, element.sales));

          Constants.sales_barData.add(
            BarChartGroupData(
              x: id_y++,
              barRods: [
                BarChartRodData(
                  toY: element.sales.toDouble(),
                  color: Colors.grey.shade400,
                  borderRadius: BorderRadius.zero,
                  width: 12,
                ),
              ],
            ),
          );
        }
        if (kDebugMode) {}
        Constants.sales_salesbyagent1a
            .sort((a, b) => b.sales.compareTo(a.sales));
        Constants.sales_ordinary_sales1a
            .sort((a, b) => b.sales.compareTo(a.sales));
        Constants.sales_bardata5a.add(charts.Series<OrdinalSales, String>(
            id: 'BranchSales1',
            domainFn: (OrdinalSales sale, _) => sale.branch,
            measureFn: (OrdinalSales sale, _) => sale.sales,
            data: Constants.sales_ordinary_sales1a,
            // Set a label accessor to control the text of the bar label.
            labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
      }
    }
  } catch (_, exception) {
    //Exception exc = exception as Exception;
    // print(exception);
  }
}

Future<void> getSalesReport2(jsonResponse, String date_from, String date_to,
    int selectedButton1, int days_difference, BuildContext context) async {
  try {
    List<Map<String, dynamic>> sales = [];
    Map<String, List<Map<String, dynamic>>> groupedSales2a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2a = {};
    Constants.sales_barData = [];
    Constants.sales_pieData = [];
    Constants.sales_bottomTitles2a = [];
    Map<int, int> monthlySalesCount2a = {};
    Map<int, int> monthlySalesCount2b = {};
    Map<int, int> monthlySalesCount2c = {};
    if (jsonResponse["sales"] is List) {
      sales = List<Map<String, dynamic>>.from(jsonResponse);

      if (selectedButton1 == 2) {
        Constants.sales_salesbyagent2a = [];
        Constants.sales_bottomTitles2a = [];
        Constants.sales_maxY5b = 0;
        Constants.sales_sectionsList2a = [
          salesgridmodel("All Sales", 0),
          salesgridmodel("Inforced Sales", 0),
          salesgridmodel("Not Accepted", 0),
        ];
        // print("got here 2 ${baseUrl}");
        for (var sale in sales) {
          DateTime date = DateTime.parse(sale['sale_datetime']);
          int month = date.month;

          monthlySalesCount2a.update(month, (value) => value + 1,
              ifAbsent: () => 1);
          if (sale["quote_status"] == "Inforced")
            monthlySalesCount2b.update(month, (value) => value + 1,
                ifAbsent: () => 1);
          if (sale["quote_status"] != "Inforced")
            monthlySalesCount2c.update(month, (value) => value + 1,
                ifAbsent: () => 1);
          dynamic assignedTo = sale['assigned_to'];
          int branchId = sale['branch_id'] ?? -1;
          String employeeName = assignedTo != null ? assignedTo.toString() : '';
          Constants.sales_sectionsList2a[0].amount++;
          if (sale["quote_status"] == "Inforced") {
            Constants.sales_sectionsList2a[1].amount++;
          } else {
            Constants.sales_sectionsList2a[2].amount++;
          }
          if (employeeName.isNotEmpty) {
            groupedSales2a.putIfAbsent(employeeName, () => []);
            groupedSales2a[employeeName]!.add(sale);
          } else {
            print("Sale does not have an employee: $sale");
          }
          if (branchId.toString() != "") {
            //print("branchIdgffg $branchId");
            String branch_name = getBranchById(branchId);
            //print("branch_name1 $branch_name");

            groupedSalesByBranch2a.putIfAbsent(branch_name, () => []);
            groupedSalesByBranch2a[branch_name]?.add(sale);
          } else {
            //  print("Branch id is empty: $branchId");
          }
        }
        Constants.sales_spots2a = [];
        Constants.sales_spots2b = [];
        Constants.sales_spots2c = [];
        Constants.sales_chartKey2a = UniqueKey();
        Constants.sales_chartKey2b = UniqueKey();
        Constants.sales_chartKey2c = UniqueKey();
        monthlySalesCount2a.forEach((month, count) {
          print("fgghhg0 $month $count");
          Constants.sales_spots2a
              .add(FlSpot(month.toDouble(), count.toDouble()));
          if (count > Constants.sales_maxY2) {
            Constants.sales_maxY2 = count;
          }
        });
        monthlySalesCount2b.forEach((month, count) {
          Constants.sales_spots2b
              .add(FlSpot(month.toDouble(), count.toDouble()));
          if (count > Constants.sales_maxY2) {
            Constants.sales_maxY2 = count;
          }
        });
        monthlySalesCount2c.forEach((month, count) {
          Constants.sales_spots2c
              .add(FlSpot(month.toDouble(), count.toDouble()));
          if (count > Constants.sales_maxY2) {
            Constants.sales_maxY2 = count;
          }
        });

        // Sort the spots by month
        //Constants.sales_spots2a.sort((a, b) => a.x.compareTo(b.x));
        Constants.sales_spots2b.sort((a, b) => a.x.compareTo(b.x));
        Constants.sales_spots2c.sort((a, b) => a.x.compareTo(b.x));
        groupedSales2a.forEach((key, value) {
          if (key.isNotEmpty) {
            String employee_name = getEmployeeById(int.parse(key));

            Constants.sales_salesbyagent2a
                .add(SalesByAgent(employee_name, value.length));
          }
        });
        Constants.sales_salesbyagent2a
            .sort((a, b) => b.sales.compareTo(a.sales));
        Constants.sales_salesbybranch2a
            .sort((a, b) => b.sales.compareTo(a.sales));
        int id_y = 0;
        Constants.sales_bardata5b = [];
        groupedSalesByBranch2a.forEach((key, value) {
          //print("Constants.maxY ${Constants.sales_maxY}");

          Constants.sales_salesbybranch2a.add(SalesByBranch(key, value.length));
          if (key.isNotEmpty) {}
        });
        Constants.sales_salesbybranch2a
            .sort((a, b) => b.sales.compareTo(a.sales));
        for (var element in Constants.sales_salesbybranch2a) {
          if (element.sales > Constants.sales_maxY5b) {
            Constants.sales_maxY5b = element.sales;
          }

          Constants.sales_bottomTitles2a.add(element.branch_name);
          Constants.sales_ordinary_sales2a
              .add(OrdinalSales(element.branch_name, element.sales));

          Constants.sales_barData.add(
            BarChartGroupData(
              x: id_y++,
              barRods: [
                BarChartRodData(
                  toY: element.sales.toDouble(),
                  color: Colors.grey.shade400,
                  borderRadius: BorderRadius.zero,
                  width: 12,
                ),
              ],
            ),
          );
        }
        Constants.sales_salesbyagent2a
            .sort((a, b) => b.sales.compareTo(a.sales));
        Constants.sales_ordinary_sales2a
            .sort((a, b) => b.sales.compareTo(a.sales));
        Constants.sales_bardata5b.add(charts.Series<OrdinalSales, String>(
            id: 'BranchSales1',
            domainFn: (OrdinalSales sale, _) => sale.branch,
            measureFn: (OrdinalSales sale, _) => sale.sales,
            data: Constants.sales_ordinary_sales2a,
            // Set a label accessor to control the text of the bar label.
            labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
      }
    }
  } catch (_, exception) {
    //Exception exc = exception as Exception;
    // print(exception);
  }
}

Future<void> getSalesReport3(jsonResponse, String date_from, String date_to,
    int selectedButton1, int days_difference, BuildContext context) async {
  Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3a = {};
  Map<String, List<Map<String, dynamic>>> groupedSales3a = {};
  Map<String, List<Map<String, dynamic>>> groupedSales3b = {};
  Map<String, List<Map<String, dynamic>>> groupedSales3c = {};
  Map<int, int> dailySalesCount3a = {};
  Map<int, int> dailySalesCount3b = {};
  Map<int, int> dailySalesCount3c = {};
  Constants.sales_salesbyagent3a = [];
  Constants.sales_salesbyagent3b = [];
  Constants.sales_salesbyagent3c = [];
  Constants.sales_salesbybranch3a.clear();
  Constants.sales_bardata5c.clear();
  dailySalesCount3a = {};
  dailySalesCount3b = {};
  dailySalesCount3c = {};
  groupedSales3a = {};
  groupedSales3b = {};
  groupedSales3c = {};
  groupedSalesByBranch3a = {};
  Constants.sales_maxY5c = 0;
  Constants.sales_spots3a = [];
  Constants.sales_spots3b = [];
  Constants.sales_spots3c = [];
  Constants.sales_chartKey3a = UniqueKey();
  Constants.sales_chartKey3b = UniqueKey();
  Constants.sales_chartKey3c = UniqueKey();
  Constants.sales_sectionsList3a = [
    salesgridmodel("All Sales", 0),
    salesgridmodel("Inforced Sales", 0),
    salesgridmodel("Not Accepted", 0),
  ];
  if (kDebugMode) {
    //  print("got here 3 ${baseUrl} ${Constants.sales_bardata5c}");
  }
  List sales = List<Map<String, dynamic>>.from(jsonResponse);
  for (var sale in sales) {
    DateTime date = DateTime.parse(sale['sale_datetime']);

    // Adjust the date if it's on a weekend
    if (date.weekday == DateTime.saturday) {
      //  print("date is a saturday ${sale['sale_datetime']}");
      date = date.add(Duration(days: 2)); // Move to Monday
    } else if (date.weekday == DateTime.sunday) {
      if (kDebugMode) {
        //  print("date is a sunday ${sale['sale_datetime']}");
      }
      date = date.add(Duration(days: 1)); // Move to Monday
    }

    dailySalesCount3a.update(date.day, (value) => value + 1, ifAbsent: () => 1);
    if (sale["quote_status"] == "Inforced") {
      dailySalesCount3b.update(date.day, (value) => value + 1,
          ifAbsent: () => 1);
    }
    if (sale["quote_status"] != "Inforced") {
      dailySalesCount3c.update(date.day, (value) => value + 1,
          ifAbsent: () => 1);
    }

    dynamic assignedTo = sale['assigned_to'];
    int branchId = sale['branch_id'] ?? -1;

    String employeeName = assignedTo != null ? assignedTo.toString() : '';

    Constants.sales_sectionsList3a[0].amount++;

    if (sale["quote_status"] == "Inforced") {
      Constants.sales_sectionsList3a[1].amount++;
    } else {
      Constants.sales_sectionsList3a[2].amount++;
    }

    if (employeeName.isNotEmpty) {
      groupedSales3a.putIfAbsent(employeeName, () => []);
      groupedSales3a[employeeName]!.add(sale);

      if (sale["quote_status"] == "Inforced")
        groupedSales3b.putIfAbsent(employeeName, () => []);
      if (sale["quote_status"] == "Inforced")
        groupedSales3b[employeeName]!.add(sale);

      if (sale["quote_status"] != "Inforced")
        groupedSales3c.putIfAbsent(employeeName, () => []);
      if (sale["quote_status"] != "Inforced")
        groupedSales3c[employeeName]!.add(sale);
    } else {
      // print("Sale does not have an employee: $sale");
    }
    if (kDebugMode) {
      // print("branchId3 $branchId");
    }
    String branch_name = getBranchById(branchId);
    // print("branch_name3a $branch_name");

    groupedSalesByBranch3a!.putIfAbsent(branch_name, () => []);
    groupedSalesByBranch3a![branch_name]?.add(sale);
  }
  int lastDay = 0;
  int xValue = 1;

  dailySalesCount3a.forEach((day, count) {
    print("ssaghsg57 $day $count");
    if (day < lastDay) {
      // This condition indicates the start of a new month
      xValue = lastDay + 1; // Continue from where the last month ended
    } else {
      xValue = day; // Normal progression of days within the same month
    }

    lastDay = day;

    Constants.sales_spots3a.add(FlSpot(xValue.toDouble(), count.toDouble()));

    if (count > Constants.sales_maxY3) {
      Constants.sales_maxY3 = count;
    }
  });
  dailySalesCount3b.forEach((day, count) {
    if (kDebugMode) {
      // print(day);
    }
    Constants.sales_spots3b.add(FlSpot(day.toDouble(), count.toDouble()));
  });
  dailySalesCount3c.forEach((day, count) {
    if (kDebugMode) {
      //print(day);
    }
    Constants.sales_spots3c.add(FlSpot(day.toDouble(), count.toDouble()));
  });
  Constants.sales_spots3a.sort((a, b) => a.x.compareTo(b.x));
  Constants.sales_spots3b.sort((a, b) => a.x.compareTo(b.x));
  Constants.sales_spots3c.sort((a, b) => a.x.compareTo(b.x));
  groupedSales3a.forEach((key, value) {
    if (key.isNotEmpty) {
      String employee_name = getEmployeeById(int.parse(key));

      Constants.sales_salesbyagent3a
          .add(SalesByAgent(employee_name, value.length));
    }
  });
  groupedSales3b.forEach((key, value) {
    if (key.isNotEmpty) {
      String employee_name = getEmployeeById(int.parse(key));

      Constants.sales_salesbyagent3b
          .add(SalesByAgent(employee_name, value.length));
    }
  });
  groupedSales3c.forEach((key, value) {
    if (key.isNotEmpty) {
      String employee_name = getEmployeeById(int.parse(key));

      Constants.sales_salesbyagent3c
          .add(SalesByAgent(employee_name, value.length));
    }
  });
  Constants.sales_salesbyagent3a.sort((a, b) => b.sales.compareTo(a.sales));
  Constants.sales_salesbyagent3b.sort((a, b) => b.sales.compareTo(a.sales));
  Constants.sales_salesbyagent3c.sort((a, b) => b.sales.compareTo(a.sales));

  Constants.sales_salesbyagent7a =
      Constants.sales_salesbyagent3a.reversed.toList();
  Constants.sales_salesbyagent7b =
      Constants.sales_salesbyagent3b.reversed.toList();
  Constants.sales_salesbyagent7c =
      Constants.sales_salesbyagent3c.reversed.toList();

  Constants.sales_salesbybranch3a.sort((a, b) => b.sales.compareTo(a.sales));
  int id_y = 0;
  groupedSalesByBranch3a!.forEach((key, value) {
    Constants.sales_salesbybranch3a.add(SalesByBranch(key, value.length));
    if (key.isNotEmpty) {}
  });
  Constants.sales_salesbybranch3a.sort((a, b) => b.sales.compareTo(a.sales));
  Constants.sales_bottomTitles3a = [];
  Constants.sales_ordinary_sales3a = [];
  // print("sales_salesbybranch3a length ${Constants.sales_salesbybranch3a.length}");
  for (var element in Constants.sales_salesbybranch3a) {
    if (element.sales > Constants.sales_maxY5c) {
      Constants.sales_maxY5c = element.sales;
    }

    Constants.sales_bottomTitles3a.add(element.branch_name);
    Constants.sales_ordinary_sales3a
        .add(OrdinalSales(element.branch_name, element.sales));

    Constants.sales_barData.add(
      BarChartGroupData(
        x: id_y++,
        barRods: [
          BarChartRodData(
            toY: element.sales.toDouble(),
            color: Colors.grey.shade400,
            borderRadius: BorderRadius.zero,
            width: 12,
          ),
        ],
      ),
    );
  }

  Constants.sales_salesbyagent3a.sort((a, b) => b.sales.compareTo(a.sales));
  Constants.sales_ordinary_sales3a.sort((a, b) => b.sales.compareTo(a.sales));
  Constants.sales_bardata5c.add(charts.Series<OrdinalSales, String>(
      id: 'BranchSales1',
      domainFn: (OrdinalSales sale, _) => sale.branch,
      measureFn: (OrdinalSales sale, _) => sale.sales,
      data: Constants.sales_ordinary_sales3a,
      // Set a label accessor to control the text of the bar label.
      labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
  if (kDebugMode) {
    /*   print("sales_maxY5c ${Constants.sales_maxY5c}");
              print(
                  "sales_ordinary_sales3a length ${Constants.sales_ordinary_sales3a.length}");
              print(
                  "sales_bardata5c length2 ${Constants.sales_bardata5c[0].data.length}");
              print(Constants.sales_ordinary_sales3a);*/
  }

  salesValue.value++;
}

/*Future<void> getSalesReportOld(String date_from, String date_to,
    int selectedButton1, int days_difference, BuildContext context) async {
  https: //uat.miinsightsapps.net/fieldV6/getLeadss?empId=3&searchKey=6&status=all&cec_client_id=1&type=field&startDate=2023-08-01&endDate=2023-08-31
  String baseUrl =
      "https://miinsightsapps.net/parlour/getSalesAll?cec_client_id=${Constants.cec_client_id}&type=field&startDate=${date_from}&endDate=${date_to}";

  try {
    if (kDebugMode) {
      // print("baseUrl $baseUrl");
    }
    List<Map<String, dynamic>> sales = [];
    Map<String, List<Map<String, dynamic>>> groupedSales1a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales2a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales3a = {};
    Map<String, List<Map<String, dynamic>>> groupedSales3b = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch1a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch2a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3a = {};
    Map<String, List<Map<String, dynamic>>>? groupedSalesByBranch3b = {};

    await http.get(
        Uri.parse(
          baseUrl,
        ),
        headers: {
          "Cookie":
              "userid=expiry=2021-04-25&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=&empid=3&empfirstname=Mncedisi&emplastname=Khumalo&email=mncedisi@athandwe.co.za&username=mncedisi@athandwe.co.za&dob=8/28/1985 12:00:00 AM&fullname=Mncedisi Khumalo&userRole=5&userImage=mncedisi@athandwe.co.za.jpg&employedAt=branch&role=leader&branchid=6&branchname=Boulders&jobtitle=Administrative Assistant&dialing_strategy=Campaign Manager&clientname=Test 1 Funeral Parlour&foldername=maafrica&client_abbr=AS&pbx_account=pbx1051ef0a&soft_phone_ip=&agent_type=branch&mip_username=mnces@mip.co.za&agent_email=Mr Mncedisi Khumalo&ViciDial_phone_login=&ViciDial_phone_password=&ViciDial_agent_user=99&ViciDial_agent_password=&device_id=dC7JwXFwwdI:APA91bF0gTbuXlfT6wIcGMLY57Xo7VxUMrMH-MuFYL5PnjUVI0G5X1d3d90FNRb8-XmcjI40L1XqDH-KAc1KWnPpxNg8Z8SK4Ty0xonbz4L3sbKz3Rlr4hyBqePWx9ZfEp53vWwkZ3tx&servername=http://localhost:55661"
        }).then((value) {
      http.Response response = value;
      if (kDebugMode) {}
      if (response.statusCode != 200) {
      } else {
        Constants.sales_barData = [];
        Constants.sales_pieData = [];

        Constants.sales_bottomTitles2a = [];
        Map<int, int> dailySalesCount = {};
        Map<int, int> dailySalesCount1b = {};
        Map<int, int> dailySalesCount1c = {};
        Map<int, int> dailySalesCount3a = {};
        Map<int, int> dailySalesCount3b = {};
        Map<int, int> dailySalesCount3c = {};
        Map<int, int> monthlySalesCount2a = {};
        Map<int, int> monthlySalesCount2b = {};
        Map<int, int> monthlySalesCount2c = {};

        Map<int, int> monthlySalesCount3a = {};
        Map<int, int> monthlySalesCount3b = {};
        Map<int, int> monthlySalesCount3c = {};
        int monthlyTotal = 0;

        var jsonResponse = jsonDecode(response.body);

        if (kDebugMode) {
          //print(jsonResponse);
        }

        if (jsonResponse is List) {
          sales = List<Map<String, dynamic>>.from(jsonResponse);

          if (selectedButton1 == 1) {
            Constants.sales_salesbyagent1a = [];
            Constants.sales_salesbyagent4a = [];
            Constants.sales_bottomTitles1a = [];
            Constants.sales_maxY5a = 0;
            Constants.sales_sectionsList1a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            if (kDebugMode) {
              // print("got here 1 ${baseUrl}");
            }
            for (var sale in sales) {
              dynamic assignedTo = sale['assigned_to'] ?? 0;
              if (!excludedEmps.contains(assignedTo)) {
                DateTime date = DateTime.parse(sale['sale_datetime']);

                // Adjust the date if it's on a weekend
                if (date.weekday == DateTime.saturday) {
                  // print("date is a saturday ${sale['sale_datetime']}");
                  date = date.add(Duration(days: 2)); // Move to Monday
                } else if (date.weekday == DateTime.sunday) {
                  if (kDebugMode) {
                    //  print("date is a sunday ${sale['sale_datetime']}");
                  }
                  date = date.add(Duration(days: 1)); // Move to Monday
                }

                // Only consider dates in the current month
                if (date.month == DateTime.now().month &&
                    date.year == DateTime.now().year) {
                  dailySalesCount.update(date.day, (value) => value + 1,
                      ifAbsent: () => 1);
                  DateTime dateWithSameTime =
                      DateTime(date.year, date.month, date.day, 0, 0, 0, 0);
                  Constants.dailySalesCount_new.update(
                      dateWithSameTime, (value) => value + 1,
                      ifAbsent: () => 1);

                  if (sale["quote_status"] == "Inforced")
                    dailySalesCount1b.update(date.day, (value) => value + 1,
                        ifAbsent: () => 1);
                  if (sale["quote_status"] != "Inforced")
                    dailySalesCount1c.update(date.day, (value) => value + 1,
                        ifAbsent: () => 1);
                  monthlyTotal += 1; // Increment the monthly total
                }

                int branchId = sale['branch_id'] ?? -1;

                String employeeName =
                    assignedTo != null ? assignedTo.toString() : '';

                Constants.sales_sectionsList1a[0].amount++;

                if (sale["quote_status"] == "Inforced") {
                  Constants.sales_sectionsList1a[1].amount++;
                } else {
                  Constants.sales_sectionsList1a[2].amount++;
                }

                if (employeeName.isNotEmpty) {
                  groupedSales1a.putIfAbsent(employeeName, () => []);
                  groupedSales1a[employeeName]!.add(sale);
                } else {
                  // print("Sale does not have an employee: $sale");
                }
                if (kDebugMode) {
                  //print("branchId $branchId");
                }
                String branch_name = getBranchById(branchId);
                //print("branch_name1 $branch_name");

                groupedSalesByBranch1a.putIfAbsent(branch_name, () => []);
                groupedSalesByBranch1a[branch_name]?.add(sale);
              }
            }
            Constants.sales_spots1a = [];
            Constants.sales_spots1b = [];
            Constants.sales_spots1c = [];
            Constants.sales_chartKey1a = UniqueKey();
            Constants.sales_chartKey1b = UniqueKey();
            Constants.sales_chartKey1c = UniqueKey();
            dailySalesCount.forEach((day, count) {
              print("ghhgsd $day $count");
              if (kDebugMode) {
                //  print(day);
              }
              Constants.sales_spots1a
                  .add(FlSpot(day.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY) {
                Constants.sales_maxY = count;
              }
            });
            dailySalesCount1b.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots1b
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            dailySalesCount1c.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots1c
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            groupedSales1a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent1a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent1a
                .sort((a, b) => b.sales.compareTo(a.sales));

            Constants.sales_salesbyagent4a
                .sort((b, a) => a.sales.compareTo(b.sales));
            Constants.sales_salesbybranch1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            Constants.sales_bardata5a = [];
            groupedSalesByBranch1a.forEach((key, value) {
              Constants.sales_salesbybranch1a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            Constants.sales_salesbybranch1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch1a) {
              if (element.sales > Constants.sales_maxY5a) {
                Constants.sales_maxY5a = element.sales;
              }

              Constants.sales_bottomTitles1a.add(element.branch_name);
              Constants.sales_ordinary_sales1a
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              //  print("sales_maxY5a ${Constants.sales_maxY5a}");
            }
            Constants.sales_salesbyagent1a
                .sort((a, b) => b.sales.compareTo(a.sales));

            Constants.sales_ordinary_sales1a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5a.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales1a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
          } else if (selectedButton1 == 2) {
            Constants.sales_salesbyagent2a = [];
            Constants.sales_bottomTitles2a = [];
            Constants.sales_maxY5b = 0;
            Constants.sales_sectionsList2a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            // print("got here 2 ${baseUrl}");
            for (var sale in sales) {
              dynamic assignedTo = sale['assigned_to'] ?? 0;
              if (!excludedEmps.contains(assignedTo)) {
                DateTime date = DateTime.parse(sale['sale_datetime']);
                int month = date.month;

                monthlySalesCount2a.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
                if (sale["quote_status"] == "Inforced")
                  monthlySalesCount2b.update(month, (value) => value + 1,
                      ifAbsent: () => 1);
                if (sale["quote_status"] != "Inforced")
                  monthlySalesCount2c.update(month, (value) => value + 1,
                      ifAbsent: () => 1);

                int branchId = sale['branch_id'] ?? -1;

                String employeeName =
                    assignedTo != null ? assignedTo.toString() : '';

                Constants.sales_sectionsList2a[0].amount++;

                if (sale["quote_status"] == "Inforced") {
                  Constants.sales_sectionsList2a[1].amount++;
                } else {
                  Constants.sales_sectionsList2a[2].amount++;
                }
                if (employeeName.isNotEmpty) {
                  groupedSales2a.putIfAbsent(employeeName, () => []);
                  groupedSales2a[employeeName]!.add(sale);
                } else {
                  // print("Sale does not have an employee: $sale");
                }
                if (branchId.toString() != "") {
                  //print("branchIdgffg $branchId");
                  String branch_name = getBranchById(branchId);
                  //print("branch_name1 $branch_name");

                  groupedSalesByBranch2a.putIfAbsent(branch_name, () => []);
                  groupedSalesByBranch2a[branch_name]?.add(sale);
                } else {
                  //  print("Branch id is empty: $branchId");
                }
              }
            }
            Constants.sales_spots2a = [];
            Constants.sales_spots2b = [];
            Constants.sales_spots2c = [];
            Constants.sales_chartKey2a = UniqueKey();
            Constants.sales_chartKey2b = UniqueKey();
            Constants.sales_chartKey2c = UniqueKey();
            monthlySalesCount2a.forEach((month, count) {
              print("fgghhg $month $count");
              Constants.sales_spots2a
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });
            monthlySalesCount2b.forEach((month, count) {
              Constants.sales_spots2b
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });
            monthlySalesCount2c.forEach((month, count) {
              Constants.sales_spots2c
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY2) {
                Constants.sales_maxY2 = count;
              }
            });

            // Sort the spots by month
            Constants.sales_spots2a.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots2b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots2c.sort((a, b) => a.x.compareTo(b.x));
            groupedSales2a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent2a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            Constants.sales_bardata5b = [];
            groupedSalesByBranch2a.forEach((key, value) {
              //print("Constants.maxY ${Constants.sales_maxY}");

              Constants.sales_salesbybranch2a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            Constants.sales_salesbybranch2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch2a) {
              if (element.sales > Constants.sales_maxY5b) {
                Constants.sales_maxY5b = element.sales;
              }

              Constants.sales_bottomTitles2a.add(element.branch_name);
              Constants.sales_ordinary_sales2a
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              print("ffgfh ${Constants.sales_maxY5b}");
            }
            Constants.sales_salesbyagent2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales2a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5b.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales2a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
          } else if (selectedButton1 == 3 && days_difference <= 31) {
            Constants.sales_salesbyagent3a = [];
            Constants.sales_salesbybranch3a.clear();
            Constants.sales_bardata5c.clear();
            dailySalesCount3a = {};
            dailySalesCount3b = {};
            dailySalesCount3c = {};
            groupedSales3a = {};
            groupedSalesByBranch3a = {};
            Constants.sales_maxY5c = 0;
            Constants.sales_spots3a = [];
            Constants.sales_spots3b = [];
            Constants.sales_spots3c = [];
            Constants.sales_chartKey3a = UniqueKey();
            Constants.sales_chartKey3b = UniqueKey();
            Constants.sales_chartKey3c = UniqueKey();
            Constants.sales_sectionsList3a = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            if (kDebugMode) {
              //  print("got here 3 ${baseUrl} ${Constants.sales_bardata5c}");
            }
            for (var sale in sales) {
              DateTime date = DateTime.parse(sale['sale_datetime']);

              // Adjust the date if it's on a weekend
              if (date.weekday == DateTime.saturday) {
                //  print("date is a saturday ${sale['sale_datetime']}");
                date = date.add(Duration(days: 2)); // Move to Monday
              } else if (date.weekday == DateTime.sunday) {
                if (kDebugMode) {
                  //  print("date is a sunday ${sale['sale_datetime']}");
                }
                date = date.add(Duration(days: 1)); // Move to Monday
              }

              dailySalesCount3a.update(date.day, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["quote_status"] == "Inforced") {
                dailySalesCount3b.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
              }
              if (sale["quote_status"] != "Inforced") {
                dailySalesCount3c.update(date.day, (value) => value + 1,
                    ifAbsent: () => 1);
              }
              monthlyTotal += 1; // Increment the monthly total

              dynamic assignedTo = sale['assigned_to'];
              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList3a[0].amount++;

              if (sale["quote_status"] == "Inforced") {
                Constants.sales_sectionsList3a[1].amount++;
              } else {
                Constants.sales_sectionsList3a[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales3a.putIfAbsent(employeeName, () => []);
                groupedSales3a[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (kDebugMode) {
                // print("branchId3 $branchId");
              }
              String branch_name = getBranchById(branchId);
              // print("branch_name3a $branch_name");

              groupedSalesByBranch3a!.putIfAbsent(branch_name, () => []);
              groupedSalesByBranch3a![branch_name]?.add(sale);
            }
            int lastDay = 0;
            int xValue = 1;

            dailySalesCount3a.forEach((day, count) {
              print("ssaghsg5 $day $count");
              if (day < lastDay) {
                // This condition indicates the start of a new month
                xValue =
                    lastDay + 1; // Continue from where the last month ended
              } else {
                xValue =
                    day; // Normal progression of days within the same month
              }

              lastDay = day;

              Constants.sales_spots3a
                  .add(FlSpot(xValue.toDouble(), count.toDouble()));

              if (count > Constants.sales_maxY3) {
                Constants.sales_maxY3 = count;
              }
            });
            dailySalesCount3b.forEach((day, count) {
              if (kDebugMode) {
                // print(day);
              }
              Constants.sales_spots3b
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            dailySalesCount3c.forEach((day, count) {
              if (kDebugMode) {
                //print(day);
              }
              Constants.sales_spots3c
                  .add(FlSpot(day.toDouble(), count.toDouble()));
            });
            Constants.sales_spots3a.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots3b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots3c.sort((a, b) => a.x.compareTo(b.x));
            groupedSales3a.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent3a
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            Constants.sales_salesbyagent3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            groupedSalesByBranch3a!.forEach((key, value) {
              Constants.sales_salesbybranch3a
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            Constants.sales_salesbybranch3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bottomTitles3a = [];
            Constants.sales_ordinary_sales3a = [];
            // print("sales_salesbybranch3a length ${Constants.sales_salesbybranch3a.length}");
            for (var element in Constants.sales_salesbybranch3a) {
              if (element.sales > Constants.sales_maxY5c) {
                Constants.sales_maxY5c = element.sales;
              }

              Constants.sales_bottomTitles3a.add(element.branch_name);
              Constants.sales_ordinary_sales3a
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              */ /*      print("sales_maxY5c ${Constants.sales_maxY5c}");
              print(
                  "sales_ordinary_sales3a length ${Constants.sales_ordinary_sales3a.length}");
              print(
                  "sales_bardata5c length ${Constants.sales_bardata5c.length}");
              print(Constants.sales_ordinary_sales3a);
              print(Constants.sales_ordinary_sales3a);*/ /*
            }

            Constants.sales_salesbyagent3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales3a
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5c.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales3a,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            if (kDebugMode) {
              */ /*   print("sales_maxY5c ${Constants.sales_maxY5c}");
              print(
                  "sales_ordinary_sales3a length ${Constants.sales_ordinary_sales3a.length}");
              print(
                  "sales_bardata5c length2 ${Constants.sales_bardata5c[0].data.length}");
              print(Constants.sales_ordinary_sales3a);*/ /*
            }

            salesValue.value++;
          } else if (selectedButton1 == 3 && days_difference >= 31) {
            Constants.sales_salesbyagent3b = [];
            Constants.sales_bottomTitles3b = [];
            Constants.sales_maxY5d = 0;
            Constants.sales_sectionsList3b = [
              salesgridmodel("All Sales", 0),
              salesgridmodel("Inforced Sales", 0),
              salesgridmodel("Not Accepted", 0),
            ];
            // print("got here 2 ${baseUrl}");
            for (var sale in sales) {
              DateTime date = DateTime.parse(sale['sale_datetime']);
              int month = date.month;

              monthlySalesCount3a.update(month, (value) => value + 1,
                  ifAbsent: () => 1);
              if (sale["quote_status"] == "Inforced")
                monthlySalesCount3b.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              if (sale["quote_status"] != "Inforced")
                monthlySalesCount3c.update(month, (value) => value + 1,
                    ifAbsent: () => 1);
              dynamic assignedTo = sale['assigned_to'];
              int branchId = sale['branch_id'] ?? -1;

              String employeeName =
                  assignedTo != null ? assignedTo.toString() : '';

              Constants.sales_sectionsList3b[0].amount++;

              if (sale["quote_status"] == "Inforced") {
                Constants.sales_sectionsList3b[1].amount++;
              } else {
                Constants.sales_sectionsList3b[2].amount++;
              }

              if (employeeName.isNotEmpty) {
                groupedSales3b.putIfAbsent(employeeName, () => []);
                groupedSales3b[employeeName]!.add(sale);
              } else {
                // print("Sale does not have an employee: $sale");
              }
              if (branchId != null) {
                //print("branchIdgffg $branchId");
                String branch_name = getBranchById(branchId);
                //print("branch_name1 $branch_name");

                groupedSalesByBranch3b.putIfAbsent(branch_name, () => []);
                groupedSalesByBranch3b[branch_name]?.add(sale);
              }
            }
            Constants.sales_spots4a = [];
            Constants.sales_spots4b = [];
            Constants.sales_spots4c = [];
            Constants.sales_chartKey4a = UniqueKey();
            Constants.sales_chartKey4b = UniqueKey();
            Constants.sales_chartKey4c = UniqueKey();
            monthlySalesCount3a.forEach((month, count) {
              Constants.sales_spots4a
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });
            monthlySalesCount3b.forEach((month, count) {
              Constants.sales_spots4b
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });
            monthlySalesCount3c.forEach((month, count) {
              Constants.sales_spots4c
                  .add(FlSpot(month.toDouble(), count.toDouble()));
              if (count > Constants.sales_maxY4) {
                Constants.sales_maxY4 = count;
              }
            });

            // Sort the spots by month
            Constants.sales_spots4a.sort((a, b) => a.x.compareTo(b.x));
            */ /*   Constants.sales_spots4b.sort((a, b) => a.x.compareTo(b.x));
            Constants.sales_spots4c.sort((a, b) => a.x.compareTo(b.x));*/ /*

            groupedSales3b.forEach((key, value) {
              if (key.isNotEmpty) {
                String employee_name = getEmployeeById(int.parse(key));

                Constants.sales_salesbyagent3b
                    .add(SalesByAgent(employee_name, value.length));
              }
            });
            // print("groupedSales3b");
            // print(groupedSales3b);
            Constants.sales_salesbyagent3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_salesbybranch3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            int id_y = 0;
            Constants.sales_bardata5d = [];
            groupedSalesByBranch3b.forEach((key, value) {
              //print("Constants.maxY ${Constants.sales_maxY}");

              Constants.sales_salesbybranch3b
                  .add(SalesByBranch(key, value.length));
              if (key.isNotEmpty) {}
            });
            // print("groupedSalesByBranch2a");
            // print(groupedSalesByBranch3b);
            Constants.sales_salesbybranch3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            for (var element in Constants.sales_salesbybranch3b) {
              if (element.sales > Constants.sales_maxY5d) {
                Constants.sales_maxY5d = element.sales;
              }

              Constants.sales_bottomTitles3b.add(element.branch_name);
              Constants.sales_ordinary_sales3b
                  .add(OrdinalSales(element.branch_name, element.sales));

              Constants.sales_barData.add(
                BarChartGroupData(
                  x: id_y++,
                  barRods: [
                    BarChartRodData(
                      toY: element.sales.toDouble(),
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.zero,
                      width: 12,
                    ),
                  ],
                ),
              );
            }
            if (kDebugMode) {
              */ /*print("sales_maxY5d ${Constants.sales_maxY5d}");
              print(
                  "sales_ordinary_sales3b length ${Constants.sales_ordinary_sales3b.length}");
              print(
                  "sales_bardata5c length ${Constants.sales_bardata5d.length}");
              print(Constants.sales_ordinary_sales3b);
              print(Constants.sales_ordinary_sales3b);*/ /*
            }
            if (kDebugMode) {
              //print("ffgfh ${Constants.sales_maxY5b}");
            }
            Constants.sales_salesbyagent3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_ordinary_sales3b
                .sort((a, b) => b.sales.compareTo(a.sales));
            Constants.sales_bardata5d.add(charts.Series<OrdinalSales, String>(
                id: 'BranchSales1',
                domainFn: (OrdinalSales sale, _) => sale.branch,
                measureFn: (OrdinalSales sale, _) => sale.sales,
                data: Constants.sales_ordinary_sales3b,
                // Set a label accessor to control the text of the bar label.
                labelAccessorFn: (OrdinalSales sale, _) => '${sale.sales}'));
            salesValue.value++;
          }
        }
      }
    });
  } on Exception catch (_, exception) {
    //Exception exc = exception as Exception;
    // print(exception);
  }
}*/
