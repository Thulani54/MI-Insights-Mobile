class ReprintItem {
  final String payment_date;
  final String collection_date;
  final String amount;
  final String status;
  final String policy_number;
  final String branch;
  bool is_printed;
  final String pos_transaction_id;
  ReprintItem({
    required this.payment_date,
    required this.amount,
    required this.status,
    required this.collection_date,
    required this.policy_number,
    required this.branch,
    required this.is_printed,
    required this.pos_transaction_id,
  });
  toJson() {
    return {
      "payment_date": payment_date,
      "amount": amount,
      "is_printed": is_printed,
      "status": status,
      "pos_transaction_id": pos_transaction_id,
      "collection_date": collection_date,
      "policy_number": policy_number,
    };
  }
}
