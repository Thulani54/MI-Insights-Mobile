class salesgridmodel {
  String id;
  int amount;
  salesgridmodel(
    this.id,
    this.amount,
  );
}
