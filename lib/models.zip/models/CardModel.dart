class HomeCard2 {
  final int id;
  final String name;
  final String image;
  final String description;
  HomeCard2(this.id, this.name, this.image, this.description);
}
