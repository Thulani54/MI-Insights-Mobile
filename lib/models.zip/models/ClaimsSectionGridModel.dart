class claims_sections_gridmodel {
  String id;
  String amount;
  claims_sections_gridmodel(
    this.id,
    this.amount,
  );
}
