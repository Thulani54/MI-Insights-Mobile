class Product {
  Product(this.product, this.productType, this.count);

  final String product;
  final String productType;
  final int count;
}
