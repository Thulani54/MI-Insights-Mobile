class SlipMonths {
  String month;
  String amount;
  SlipMonths(this.month, this.amount);
}
