class SalesByAgent {
  final String agent_name;
  final int sales;
  SalesByAgent(this.agent_name, this.sales);
}
