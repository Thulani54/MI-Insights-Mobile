class OrdinalSales {
  final String branch;
  final int sales;

  OrdinalSales(this.branch, this.sales);
}
