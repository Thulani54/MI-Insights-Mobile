class SalesByBranch {
  final String branch_name;
  final int sales;
  SalesByBranch(this.branch_name, this.sales);
}
