import 'dart:convert';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:community_charts_flutter/community_charts_flutter.dart'
    as charts;
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:mi_insights/constants/Constants.dart';
import 'package:mrx_charts/mrx_charts.dart';
import 'package:syncfusion_flutter_treemap/treemap.dart';

import '../../customwidgets/custom_date_range_picker.dart';
import '../../services/MyNoyifier.dart';
import '../../services/sales_report_service.dart';
import '../../services/window_manager.dart';

int noOfDaysThisMonth = 30;
bool isLoading = false;
final salesValue = ValueNotifier<int>(0);
MyNotifier? myNotifier;
DateTime datefrom = DateTime.now().subtract(Duration(days: 60));
DateTime dateto = DateTime.now();
int days_difference = 0;
Widget wdg1 = Container();
int report_index = 0;
int sales_index = 0;
String data2 = "";
Key kyrt = UniqueKey();
int touchedIndex = -1;

class SalesReport extends StatefulWidget {
  const SalesReport({Key? key}) : super(key: key);

  @override
  State<SalesReport> createState() => _SalesReportState();
}

List<Map<String, dynamic>> leads = [];
List<List<Map<String, dynamic>>> policies = [];
double _sliderPosition = 0.0;
int _selectedButton = 1;
bool isSameDaysRange = true;

class _SalesReportState extends State<SalesReport> {
  Color _button1Color = Colors.grey.withOpacity(0.0);
  Color _button2Color = Colors.grey.withOpacity(0.0);
  Color _button3Color = Colors.grey.withOpacity(0.0);
  int currentLevel = 0;

  void _animateButton(int buttonNumber) {
    DateTime? startDate = DateTime.now();
    DateTime? endDate = DateTime.now();
    leads = [];

    setState(() {});

    if (kDebugMode) {
      print("jhhh $buttonNumber");
    }

    _selectedButton = buttonNumber;
    if (buttonNumber == 1) {
      _sliderPosition = 0.0;
    } else if (buttonNumber == 2) {
      _sliderPosition = (MediaQuery.of(context).size.width / 3) - 18;
    } else if (buttonNumber == 3)
      _sliderPosition = 2 * (MediaQuery.of(context).size.width / 3) - 32;
    setState(() {});
    if (buttonNumber != 3) {
      setState(() {
        // Update colors
        _button1Color = buttonNumber == 1
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);
        _button2Color = buttonNumber == 2
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);
        _button3Color = buttonNumber == 3
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);

        // Update slider position based on the button tapped
      });
      DateTime now = DateTime.now();

      setState(() {});
    } else {
      showCustomDateRangePicker(
        context,
        dismissible: true,
        minimumDate: DateTime.now().subtract(const Duration(days: 360)),
        maximumDate: DateTime.now(),
        /*    endDate: endDate,
        startDate: startDate,*/
        backgroundColor: Colors.white,
        primaryColor: Constants.ctaColorLight,
        onApplyClick: (start, end) {
          setState(() {
            endDate = end;
            startDate = start;
          });

          days_difference = end!.difference(start).inDays;
          if (end.month == start.month) {
            isSameDaysRange = true;
          } else {
            isSameDaysRange = false;
          }
          Constants.sales_formattedStartDate =
              DateFormat('yyyy-MM-dd').format(start);
          Constants.sales_formattedEndDate =
              DateFormat('yyyy-MM-dd').format(end);
          isLoading = true;
          setState(() {});

          getSalesReport(Constants.sales_formattedStartDate,
                  Constants.sales_formattedEndDate, 3, days_difference, context)
              .then((value) {
            isLoading = false;
            kyrt = UniqueKey();
            setState(() {});
          });
        },
        onCancelClick: () {
          if (kDebugMode) {
            print("user cancelled.");
          }
          setState(() {
            _animateButton(1);
          });
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
            elevation: 6,
            leading: InkWell(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.black,
                )),
            backgroundColor: Colors.white,
            centerTitle: true,
            title: const Text(
              "Sales Report",
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            )),
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              SizedBox(
                height: 12,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(36)),
                  child: Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(36)),
                        child: Center(
                          child: Row(
                            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  _animateButton(1);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  height: 35,
                                  child: Center(
                                    child: Text(
                                      '1 Mth View',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  _animateButton(2);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  child: Center(
                                    child: Text(
                                      '12 Mths View',
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 14),
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  _animateButton(3);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  child: Center(
                                    child: Text(
                                      'Select Dates',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      AnimatedPositioned(
                        duration: Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        left: _sliderPosition,
                        child: InkWell(
                          onTap: () {
                            _animateButton(3);
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width / 3,
                            height: 35,
                            decoration: BoxDecoration(
                              color: Constants
                                  .ctaColorLight, // Color of the slider
                              borderRadius: BorderRadius.circular(36),
                            ),
                            child: _selectedButton == 1
                                ? Center(
                                    child: Text(
                                      '1 Mth View',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  )
                                : _selectedButton == 2
                                    ? Center(
                                        child: Text(
                                          '12 Mths View',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      )
                                    : Center(
                                        child: Text(
                                          'Select Dates',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              isLoading
                  ? Center(
                      child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: Constants.ctaColorLight,
                            strokeWidth: 1.8,
                          ),
                        ),
                      ),
                    ))
                  : Container(),
              Padding(
                padding: const EdgeInsets.only(left: 20.0, right: 20, top: 12),
                child: Container(
                  height: 1,
                  color: Colors.grey.withOpacity(0.35),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    if (isLoading)
                      SizedBox(
                        height: 12,
                      ),

                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            childAspectRatio:
                                MediaQuery.of(context).size.width /
                                    (MediaQuery.of(context).size.height / 2.3)),
                        itemCount: _selectedButton == 1
                            ? Constants.sales_sectionsList1a.length
                            : _selectedButton == 2
                                ? Constants.sales_sectionsList2a.length
                                : _selectedButton == 3 && days_difference <= 31
                                    ? Constants.sales_sectionsList3a.length
                                    : Constants.sales_sectionsList3b.length,
                        padding: EdgeInsets.all(2.0),
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                              onTap: () {},
                              child: Container(
                                height: 290,
                                width: MediaQuery.of(context).size.width / 2.9,
                                child: Stack(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        sales_index = index;
                                        setState(() {});
                                        if (kDebugMode) {
                                          print("sales_index " +
                                              index.toString());
                                        }
                                        if (index == 1) {
                                          /*     Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) => SalesReport()));*/
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            bottom: 4.0, right: 8),
                                        child: Card(
                                          elevation: 6,
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            side: BorderSide(
                                                color: Colors.white70,
                                                width: 0),
                                            borderRadius:
                                                BorderRadius.circular(16),
                                          ),
                                          child: ClipPath(
                                            clipper: ShapeBorderClipper(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16))),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: Constants
                                                              .ctaColorLight,
                                                          width: 6))),
                                              child: Column(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: sales_index ==
                                                                  index
                                                              ? Colors.grey
                                                                  .withOpacity(
                                                                      0.45)
                                                              : Colors.grey
                                                                  .withOpacity(
                                                                      0.05),
                                                          border: Border.all(
                                                              color: Colors.grey
                                                                  .withOpacity(
                                                                      0.0)),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8)),
                                                      child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        14),
                                                          ),
                                                          width: MediaQuery.of(
                                                                  context)
                                                              .size
                                                              .width,
                                                          height: 270,
                                                          /*     decoration: BoxDecoration(
                                                          color:Colors.white,
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                          border: Border.all(
                                                              width: 1,
                                                              color: Colors
                                                                  .grey.withOpacity(0.2))),*/
                                                          margin:
                                                              EdgeInsets.only(
                                                                  right: 0,
                                                                  left: 0,
                                                                  bottom: 4),
                                                          child: Column(
                                                            children: [
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Expanded(
                                                                child: Center(
                                                                    child:
                                                                        Padding(
                                                                  padding:
                                                                      const EdgeInsets
                                                                          .all(
                                                                          8.0),
                                                                  child: Text(
                                                                    formatLargeNumber((_selectedButton ==
                                                                                1
                                                                            ? Constants.sales_sectionsList1a[index].amount
                                                                            : _selectedButton == 2
                                                                                ? Constants.sales_sectionsList2a[index].amount
                                                                                : _selectedButton == 3 && days_difference <= 31
                                                                                    ? Constants.sales_sectionsList3a[index].amount
                                                                                    : Constants.sales_sectionsList3b[index].amount)
                                                                        .toString()),
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            16.5,
                                                                        fontWeight:
                                                                            FontWeight.w500),
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 2,
                                                                  ),
                                                                )),
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        8.0),
                                                                child: Text(
                                                                  _selectedButton ==
                                                                          1
                                                                      ? Constants
                                                                          .sales_sectionsList1a[
                                                                              index]
                                                                          .id
                                                                      : _selectedButton ==
                                                                              2
                                                                          ? Constants
                                                                              .sales_sectionsList2a[index]
                                                                              .id
                                                                          : _selectedButton == 3 && days_difference <= 31
                                                                              ? Constants.sales_sectionsList3a[index].id
                                                                              : Constants.sales_sectionsList3b[index].id,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          12.5),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 1,
                                                                ),
                                                              )),
                                                            ],
                                                          )),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ));
                        },
                      ),
                    ),
                    _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0),
                            child: Text(
                                "Sales Overview (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 16.0),
                                    child:
                                        Text("Sales Overview (12 Months View)"),
                                  ),
                                  Spacer(),
                                  /*        Padding(
                                    padding: const EdgeInsets.only(right: 8.0),
                                    child: Transform.scale(
                                      scale:
                                          0.9, // Adjust the scale factor to your preference
                                      child: CupertinoSwitch(
                                        value: _months12RollingswitchValue,
                                        onChanged: (bool value) {
                                          setState(() {
                                            _months12RollingswitchValue = value;
                                          });
                                        },
                                        activeColor: Constants.ctaColorLight,
                                      ),
                                    ),
                                  )*/
                                ],
                              )
                            : Padding(
                                padding: const EdgeInsets.only(left: 16.0),
                                child: Text(
                                    "Sales Overview (${Constants.sales_formattedStartDate} to ${Constants.sales_formattedEndDate})"),
                              ),

                    if (_selectedButton == 1)
                      Container(
                          height: 280,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Padding(
                                  padding: const EdgeInsets.all(14.0),
                                  child: sales_index == 0
                                      ? Column(
                                          children: [
                                            Expanded(
                                              child: LineChart(
                                                key: Constants.sales_chartKey1b,
                                                LineChartData(
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .sales_spots1a,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          /*    if (_selectedButton == 1) {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 30,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                } else {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 12,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                }*/
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  lineTouchData: LineTouchData(
                                                      enabled: true,
                                                      touchCallback:
                                                          (FlTouchEvent event,
                                                              LineTouchResponse?
                                                                  touchResponse) {
                                                        // TODO : Utilize touch event here to perform any operation
                                                      },
                                                      touchTooltipData:
                                                          LineTouchTooltipData(
                                                        tooltipBgColor:
                                                            Colors.blueGrey,
                                                        tooltipRoundedRadius:
                                                            20.0,
                                                        showOnTopOfTheChartBoxArea:
                                                            false,
                                                        fitInsideHorizontally:
                                                            true,
                                                        tooltipMargin: 0,
                                                        getTooltipItems:
                                                            (touchedSpots) {
                                                          return touchedSpots
                                                              .map(
                                                            (LineBarSpot
                                                                touchedSpot) {
                                                              const textStyle =
                                                                  TextStyle(
                                                                fontSize: 10,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                                color: Colors
                                                                    .white70,
                                                              );
                                                              return LineTooltipItem(
                                                                touchedSpot.y
                                                                    .round()
                                                                    .toString(),
                                                                textStyle,
                                                              );
                                                            },
                                                          ).toList();
                                                        },
                                                      ),
                                                      getTouchedSpotIndicator:
                                                          (LineChartBarData
                                                                  barData,
                                                              List<int>
                                                                  indicators) {
                                                        return indicators.map(
                                                          (int index) {
                                                            final line = FlLine(
                                                                color:
                                                                    Colors.grey,
                                                                strokeWidth: 1,
                                                                dashArray: [
                                                                  2,
                                                                  4
                                                                ]);
                                                            return TouchedSpotIndicatorData(
                                                              line,
                                                              FlDotData(
                                                                  show: false),
                                                            );
                                                          },
                                                        ).toList();
                                                      },
                                                      getTouchLineEnd:
                                                          (_, __) =>
                                                              double.infinity),
                                                  minX: 1,
                                                  maxX: noOfDaysThisMonth < 28
                                                      ? 30
                                                      : noOfDaysThisMonth
                                                          .toDouble(),
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              value
                                                                  .toInt()
                                                                  .toString(),
                                                              style: TextStyle(
                                                                  fontSize: 7),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Days of the Month',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber3(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 7.5),
                                                          );
                                                        },
                                                      ),
                                                      /*axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets.only(top: 0.0),
                                                        child: Text(
                                                          'Sales',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight: FontWeight.w500,
                                                              color: Colors.black),
                                                        ),
                                                      ),*/
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: _selectedButton == 1
                                                      ? Constants.sales_maxY
                                                          .toDouble()
                                                      : Constants.sales_maxY2
                                                          .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 6,
                                            ),
                                            Text(
                                              "Weekend Sales are Added to / Accounted For On The Next Monday",
                                              style: TextStyle(fontSize: 9),
                                            )
                                          ],
                                        )
                                      : sales_index == 1
                                          ? Column(
                                              children: [
                                                Expanded(
                                                  child: LineChart(
                                                    key: Constants
                                                        .sales_chartKey1b,
                                                    LineChartData(
                                                      lineTouchData:
                                                          LineTouchData(
                                                              enabled: true,
                                                              touchCallback:
                                                                  (FlTouchEvent
                                                                          event,
                                                                      LineTouchResponse?
                                                                          touchResponse) {
                                                                // TODO : Utilize touch event here to perform any operation
                                                              },
                                                              touchTooltipData:
                                                                  LineTouchTooltipData(
                                                                tooltipBgColor:
                                                                    Colors
                                                                        .blueGrey,
                                                                tooltipRoundedRadius:
                                                                    20.0,
                                                                showOnTopOfTheChartBoxArea:
                                                                    false,
                                                                fitInsideHorizontally:
                                                                    true,
                                                                tooltipMargin:
                                                                    0,
                                                                getTooltipItems:
                                                                    (touchedSpots) {
                                                                  return touchedSpots
                                                                      .map(
                                                                    (LineBarSpot
                                                                        touchedSpot) {
                                                                      const textStyle =
                                                                          TextStyle(
                                                                        fontSize:
                                                                            10,
                                                                        fontWeight:
                                                                            FontWeight.w700,
                                                                        color: Colors
                                                                            .white70,
                                                                      );
                                                                      return LineTooltipItem(
                                                                        touchedSpot
                                                                            .y
                                                                            .round()
                                                                            .toString(),
                                                                        textStyle,
                                                                      );
                                                                    },
                                                                  ).toList();
                                                                },
                                                              ),
                                                              getTouchedSpotIndicator:
                                                                  (LineChartBarData
                                                                          barData,
                                                                      List<int>
                                                                          indicators) {
                                                                return indicators
                                                                    .map(
                                                                  (int index) {
                                                                    final line = FlLine(
                                                                        color: Colors
                                                                            .grey,
                                                                        strokeWidth: 1,
                                                                        dashArray: [
                                                                          2,
                                                                          4
                                                                        ]);
                                                                    return TouchedSpotIndicatorData(
                                                                      line,
                                                                      FlDotData(
                                                                          show:
                                                                              false),
                                                                    );
                                                                  },
                                                                ).toList();
                                                              },
                                                              getTouchLineEnd: (_,
                                                                      __) =>
                                                                  double
                                                                      .infinity),
                                                      lineBarsData: [
                                                        LineChartBarData(
                                                          spots: Constants
                                                              .sales_spots1b,
                                                          isCurved: true,
                                                          barWidth: 3,
                                                          color: Colors
                                                              .grey.shade400,
                                                          dotData: FlDotData(
                                                            show: true,
                                                            getDotPainter:
                                                                (spot,
                                                                    percent,
                                                                    barData,
                                                                    index) {
                                                              // Show custom dot and text for specific x-values

                                                              return FlDotCirclePainter(
                                                                  radius: 2,
                                                                  color: Colors
                                                                      .red,
                                                                  strokeColor:
                                                                      Colors
                                                                          .green);
                                                              /*    if (_selectedButton == 1) {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 30,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                } else {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 12,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                }*/
                                                            },
                                                          ),
                                                        ),
                                                      ],
                                                      minX: 1,
                                                      maxX: noOfDaysThisMonth <
                                                              28
                                                          ? 30
                                                          : noOfDaysThisMonth
                                                              .toDouble(),
                                                      gridData: FlGridData(
                                                        show: true,
                                                        drawVerticalLine: false,
                                                        getDrawingHorizontalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.10),
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                        getDrawingVerticalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey,
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                      ),
                                                      titlesData: FlTitlesData(
                                                        bottomTitles:
                                                            AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            interval: 1,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        2.0),
                                                                child: Text(
                                                                  value
                                                                      .toInt()
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          7),
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                          axisNameWidget:
                                                              Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 0.0),
                                                            child: Text(
                                                              'Days of the Month',
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  color: Colors
                                                                      .black),
                                                            ),
                                                          ),
                                                        ),
                                                        topTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        rightTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        leftTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            reservedSize: 20,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(
                                                                formatLargeNumber3(
                                                                    value
                                                                        .toInt()
                                                                        .toString()),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        7.5),
                                                              );
                                                            },
                                                          ),
                                                          /*axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets.only(top: 0.0),
                                                        child: Text(
                                                          'Sales',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight: FontWeight.w500,
                                                              color: Colors.black),
                                                        ),
                                                      ),*/
                                                        ),
                                                      ),
                                                      minY: 0,
                                                      maxY: _selectedButton == 1
                                                          ? Constants.sales_maxY
                                                              .toDouble()
                                                          : Constants
                                                              .sales_maxY2
                                                              .toDouble(),
                                                      borderData: FlBorderData(
                                                        show: true,
                                                        border: Border(
                                                          left: BorderSide.none,
                                                          bottom: BorderSide(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.35),
                                                            width: 1,
                                                          ),
                                                          right:
                                                              BorderSide.none,
                                                          top: BorderSide.none,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Text(
                                                  "Weekend Sales are Added to / Accounted For On The Next Monday",
                                                  style: TextStyle(fontSize: 9),
                                                )
                                              ],
                                            )
                                          : Column(
                                              children: [
                                                Expanded(
                                                  child: LineChart(
                                                    key: Constants
                                                        .sales_chartKey1c,
                                                    LineChartData(
                                                      lineTouchData:
                                                          LineTouchData(
                                                              enabled: true,
                                                              touchCallback:
                                                                  (FlTouchEvent
                                                                          event,
                                                                      LineTouchResponse?
                                                                          touchResponse) {
                                                                // TODO : Utilize touch event here to perform any operation
                                                              },
                                                              touchTooltipData:
                                                                  LineTouchTooltipData(
                                                                tooltipBgColor:
                                                                    Colors
                                                                        .blueGrey,
                                                                tooltipRoundedRadius:
                                                                    20.0,
                                                                showOnTopOfTheChartBoxArea:
                                                                    false,
                                                                fitInsideHorizontally:
                                                                    true,
                                                                tooltipMargin:
                                                                    0,
                                                                getTooltipItems:
                                                                    (touchedSpots) {
                                                                  return touchedSpots
                                                                      .map(
                                                                    (LineBarSpot
                                                                        touchedSpot) {
                                                                      const textStyle =
                                                                          TextStyle(
                                                                        fontSize:
                                                                            10,
                                                                        fontWeight:
                                                                            FontWeight.w700,
                                                                        color: Colors
                                                                            .white70,
                                                                      );
                                                                      return LineTooltipItem(
                                                                        touchedSpot
                                                                            .y
                                                                            .round()
                                                                            .toString(),
                                                                        textStyle,
                                                                      );
                                                                    },
                                                                  ).toList();
                                                                },
                                                              ),
                                                              getTouchedSpotIndicator:
                                                                  (LineChartBarData
                                                                          barData,
                                                                      List<int>
                                                                          indicators) {
                                                                return indicators
                                                                    .map(
                                                                  (int index) {
                                                                    final line = FlLine(
                                                                        color: Colors
                                                                            .grey,
                                                                        strokeWidth: 1,
                                                                        dashArray: [
                                                                          2,
                                                                          4
                                                                        ]);
                                                                    return TouchedSpotIndicatorData(
                                                                      line,
                                                                      FlDotData(
                                                                          show:
                                                                              false),
                                                                    );
                                                                  },
                                                                ).toList();
                                                              },
                                                              getTouchLineEnd: (_,
                                                                      __) =>
                                                                  double
                                                                      .infinity),
                                                      lineBarsData: [
                                                        LineChartBarData(
                                                          spots: Constants
                                                              .sales_spots1c,
                                                          isCurved: true,
                                                          barWidth: 3,
                                                          color: Colors
                                                              .grey.shade400,
                                                          dotData: FlDotData(
                                                            show: true,
                                                            getDotPainter:
                                                                (spot,
                                                                    percent,
                                                                    barData,
                                                                    index) {
                                                              return FlDotCirclePainter(
                                                                  radius: 2,
                                                                  color: Colors
                                                                      .red,
                                                                  strokeColor:
                                                                      Colors
                                                                          .green);
                                                            },
                                                          ),
                                                        ),
                                                      ],
                                                      minX: 1,
                                                      maxX: noOfDaysThisMonth
                                                          .toDouble(),
                                                      gridData: FlGridData(
                                                        show: true,
                                                        drawVerticalLine: false,
                                                        getDrawingHorizontalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.10),
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                        getDrawingVerticalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey,
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                      ),
                                                      titlesData: FlTitlesData(
                                                        bottomTitles:
                                                            AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            interval: 1,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        2.0),
                                                                child: Text(
                                                                  value
                                                                      .toInt()
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          7),
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                          axisNameWidget:
                                                              Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 0.0),
                                                            child: Text(
                                                              'Days of the Month',
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  color: Colors
                                                                      .black),
                                                            ),
                                                          ),
                                                        ),
                                                        topTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        rightTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        leftTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            reservedSize: 20,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(
                                                                formatLargeNumber3(
                                                                    value
                                                                        .toInt()
                                                                        .toString()),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        7.5),
                                                              );
                                                            },
                                                          ),
                                                          /*axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets.only(top: 0.0),
                                                        child: Text(
                                                          'Sales',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight: FontWeight.w500,
                                                              color: Colors.black),
                                                        ),
                                                      ),*/
                                                        ),
                                                      ),
                                                      minY: 0,
                                                      maxY: _selectedButton == 1
                                                          ? Constants.sales_maxY
                                                              .toDouble()
                                                          : Constants
                                                              .sales_maxY2
                                                              .toDouble(),
                                                      borderData: FlBorderData(
                                                        show: true,
                                                        border: Border(
                                                          left: BorderSide.none,
                                                          bottom: BorderSide(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.35),
                                                            width: 1,
                                                          ),
                                                          right:
                                                              BorderSide.none,
                                                          top: BorderSide.none,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Text(
                                                  "Weekend Sales are Added to / Accounted For On The Next Monday",
                                                  style: TextStyle(fontSize: 9),
                                                )
                                              ],
                                            ),
                                )),
                          )),
                    //if (_selectedButton == 1) SalesGraph1(),
                    if (_selectedButton == 2 && sales_index == 0) SalesGraph2(),
                    if (_selectedButton == 2 && sales_index == 1)
                      SalesGraph2b(),
                    if (_selectedButton == 2 && sales_index == 2)
                      SalesGraph2c(),
                    //Container(height: 400, child: LinePage()),
                    if (_selectedButton == 3 &&
                        days_difference <= 31 &&
                        isSameDaysRange == true)
                      Container(
                          height: 250,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Padding(
                                    padding: const EdgeInsets.all(14.0),
                                    child: sales_index == 0
                                        ? LineChart(
                                            key: Constants.sales_chartKey3a,
                                            LineChartData(
                                              lineTouchData: LineTouchData(
                                                  enabled: true,
                                                  touchCallback:
                                                      (FlTouchEvent event,
                                                          LineTouchResponse?
                                                              touchResponse) {
                                                    // TODO : Utilize touch event here to perform any operation
                                                  },
                                                  touchTooltipData:
                                                      LineTouchTooltipData(
                                                    tooltipBgColor:
                                                        Colors.blueGrey,
                                                    tooltipRoundedRadius: 20.0,
                                                    showOnTopOfTheChartBoxArea:
                                                        false,
                                                    fitInsideHorizontally: true,
                                                    tooltipMargin: 0,
                                                    getTooltipItems:
                                                        (touchedSpots) {
                                                      return touchedSpots.map(
                                                        (LineBarSpot
                                                            touchedSpot) {
                                                          const textStyle =
                                                              TextStyle(
                                                            fontSize: 10,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            color:
                                                                Colors.white70,
                                                          );
                                                          return LineTooltipItem(
                                                            touchedSpot.y
                                                                .round()
                                                                .toString(),
                                                            textStyle,
                                                          );
                                                        },
                                                      ).toList();
                                                    },
                                                  ),
                                                  getTouchedSpotIndicator:
                                                      (LineChartBarData barData,
                                                          List<int>
                                                              indicators) {
                                                    return indicators.map(
                                                      (int index) {
                                                        final line = FlLine(
                                                            color: Colors.grey,
                                                            strokeWidth: 1,
                                                            dashArray: [2, 4]);
                                                        return TouchedSpotIndicatorData(
                                                          line,
                                                          FlDotData(
                                                              show: false),
                                                        );
                                                      },
                                                    ).toList();
                                                  },
                                                  getTouchLineEnd: (_, __) =>
                                                      double.infinity),
                                              lineBarsData: [
                                                LineChartBarData(
                                                  spots:
                                                      Constants.sales_spots3a,
                                                  isCurved: true,
                                                  barWidth: 3,
                                                  color: Colors.grey.shade400,
                                                  dotData: FlDotData(
                                                    show: true,
                                                    getDotPainter: (spot,
                                                        percent,
                                                        barData,
                                                        index) {
                                                      // Show custom dot and text for specific x-values

                                                      return FlDotCirclePainter(
                                                          radius: 2,
                                                          color: Colors.red,
                                                          strokeColor:
                                                              Colors.green);
                                                      /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                                    },
                                                  ),
                                                ),
                                              ],
                                              maxX: 30,
                                              gridData: FlGridData(
                                                show: true,
                                                drawVerticalLine: false,
                                                getDrawingHorizontalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey
                                                        .withOpacity(0.10),
                                                    strokeWidth: 1,
                                                  );
                                                },
                                                getDrawingVerticalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey,
                                                    strokeWidth: 1,
                                                  );
                                                },
                                              ),
                                              titlesData: FlTitlesData(
                                                bottomTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    interval: 1,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      /*       DateTime end = DateTime
                                                          .parse(Constants
                                                              .sales_formattedEndDate);
                                                      // Calculate the start date by subtracting 29 days from the end date
                                                      DateTime start =
                                                          end.subtract(Duration(
                                                              days: 29));

                                                      // Calculate the specific date for the given value within the last 30 days
                                                      DateTime currentDate =
                                                          start.add(Duration(
                                                              days: value
                                                                  .toInt()));
*/
                                                      return Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(2.0),
                                                        child: Text(
                                                          value
                                                              .toInt()
                                                              .toString(), // Show the day of the month
                                                          style: TextStyle(
                                                              fontSize: 7),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                ),
                                                topTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                rightTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                leftTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    reservedSize: 20,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(
                                                        formatLargeNumber3(value
                                                            .toInt()
                                                            .toString()),
                                                        style: TextStyle(
                                                            fontSize: 7.5),
                                                      );
                                                    },
                                                  ),
                                                  /*axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                                ),
                                              ),
                                              minY: 0,
                                              minX: 1,
                                              maxY: Constants.sales_maxY3
                                                  .toDouble(),
                                              borderData: FlBorderData(
                                                show: true,
                                                border: Border(
                                                  left: BorderSide.none,
                                                  bottom: BorderSide(
                                                    color: Colors.grey
                                                        .withOpacity(0.35),
                                                    width: 1,
                                                  ),
                                                  right: BorderSide.none,
                                                  top: BorderSide.none,
                                                ),
                                              ),
                                            ),
                                          )
                                        : sales_index == 1
                                            ? LineChart(
                                                key: Constants.sales_chartKey3b,
                                                LineChartData(
                                                  lineTouchData: LineTouchData(
                                                      enabled: true,
                                                      touchCallback:
                                                          (FlTouchEvent event,
                                                              LineTouchResponse?
                                                                  touchResponse) {
                                                        // TODO : Utilize touch event here to perform any operation
                                                      },
                                                      touchTooltipData:
                                                          LineTouchTooltipData(
                                                        tooltipBgColor:
                                                            Colors.blueGrey,
                                                        tooltipRoundedRadius:
                                                            20.0,
                                                        showOnTopOfTheChartBoxArea:
                                                            false,
                                                        fitInsideHorizontally:
                                                            true,
                                                        tooltipMargin: 0,
                                                        getTooltipItems:
                                                            (touchedSpots) {
                                                          return touchedSpots
                                                              .map(
                                                            (LineBarSpot
                                                                touchedSpot) {
                                                              const textStyle =
                                                                  TextStyle(
                                                                fontSize: 10,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                                color: Colors
                                                                    .white70,
                                                              );
                                                              return LineTooltipItem(
                                                                touchedSpot.y
                                                                    .round()
                                                                    .toString(),
                                                                textStyle,
                                                              );
                                                            },
                                                          ).toList();
                                                        },
                                                      ),
                                                      getTouchedSpotIndicator:
                                                          (LineChartBarData
                                                                  barData,
                                                              List<int>
                                                                  indicators) {
                                                        return indicators.map(
                                                          (int index) {
                                                            final line = FlLine(
                                                                color:
                                                                    Colors.grey,
                                                                strokeWidth: 1,
                                                                dashArray: [
                                                                  2,
                                                                  4
                                                                ]);
                                                            return TouchedSpotIndicatorData(
                                                              line,
                                                              FlDotData(
                                                                  show: false),
                                                            );
                                                          },
                                                        ).toList();
                                                      },
                                                      getTouchLineEnd:
                                                          (_, __) =>
                                                              double.infinity),
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .sales_spots3b,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              value
                                                                  .toInt()
                                                                  .toString(),
                                                              style: TextStyle(
                                                                  fontSize: 7),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Days of the Month',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber3(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 7.5),
                                                          );
                                                        },
                                                      ),
                                                      /*axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants.sales_maxY3
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : LineChart(
                                                LineChartData(
                                                  lineTouchData: LineTouchData(
                                                      enabled: true,
                                                      touchCallback:
                                                          (FlTouchEvent event,
                                                              LineTouchResponse?
                                                                  touchResponse) {
                                                        // TODO : Utilize touch event here to perform any operation
                                                      },
                                                      touchTooltipData:
                                                          LineTouchTooltipData(
                                                        tooltipBgColor:
                                                            Colors.blueGrey,
                                                        tooltipRoundedRadius:
                                                            20.0,
                                                        showOnTopOfTheChartBoxArea:
                                                            false,
                                                        fitInsideHorizontally:
                                                            true,
                                                        tooltipMargin: 0,
                                                        getTooltipItems:
                                                            (touchedSpots) {
                                                          return touchedSpots
                                                              .map(
                                                            (LineBarSpot
                                                                touchedSpot) {
                                                              const textStyle =
                                                                  TextStyle(
                                                                fontSize: 10,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                                color: Colors
                                                                    .white70,
                                                              );
                                                              return LineTooltipItem(
                                                                touchedSpot.y
                                                                    .round()
                                                                    .toString(),
                                                                textStyle,
                                                              );
                                                            },
                                                          ).toList();
                                                        },
                                                      ),
                                                      getTouchedSpotIndicator:
                                                          (LineChartBarData
                                                                  barData,
                                                              List<int>
                                                                  indicators) {
                                                        return indicators.map(
                                                          (int index) {
                                                            final line = FlLine(
                                                                color:
                                                                    Colors.grey,
                                                                strokeWidth: 1,
                                                                dashArray: [
                                                                  2,
                                                                  4
                                                                ]);
                                                            return TouchedSpotIndicatorData(
                                                              line,
                                                              FlDotData(
                                                                  show: false),
                                                            );
                                                          },
                                                        ).toList();
                                                      },
                                                      getTouchLineEnd:
                                                          (_, __) =>
                                                              double.infinity),
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .sales_spots3c,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  maxX: noOfDaysThisMonth
                                                      .toDouble(),
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              value
                                                                  .toInt()
                                                                  .toString(),
                                                              style: TextStyle(
                                                                  fontSize: 7),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Days of the Month',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber3(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 7.5),
                                                          );
                                                        },
                                                      ),
                                                      /*axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants.sales_maxY3
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              ))),
                          )),
                    if (_selectedButton == 3 &&
                        days_difference <= 31 &&
                        sales_index == 0 &&
                        isSameDaysRange == false)
                      SalesGraph3a(
                        key: Constants.sales_chartKey3a,
                      ),
                    if (_selectedButton == 3 &&
                        days_difference <= 31 &&
                        sales_index == 1 &&
                        isSameDaysRange == false)
                      SalesGraph3b(
                        key: Constants.sales_chartKey3b,
                      ),
                    if (_selectedButton == 3 &&
                        days_difference <= 31 &&
                        sales_index == 2 &&
                        isSameDaysRange == false)
                      SalesGraph3c(
                        key: Constants.sales_chartKey3c,
                      ),
                    if (_selectedButton == 3 && days_difference > 31)
                      SalesGraph4a(
                        key: Constants.sales_chartKey4a,
                      ),
                    /*       Padding(
                      padding: const EdgeInsets.only(top: 24.0),
                      child: Center(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(360),
                            color: Constants.ctaColorLight.withOpacity(0.35),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 0.0),
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 12.0, right: 12, top: 8, bottom: 8),
                              child: Text(
                                "Views Below Are On Inforced Sales Only",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),*/

                    _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 12),
                            child: Text(
                                "Top 10 Sales Agents (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Top 10 Sales By Agent (12 Months View)"),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Top 10 Sales By Agent (${Constants.sales_formattedStartDate} to ${Constants.sales_formattedEndDate})"),
                              ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 6,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20)),
                        child: Container(
                            child: Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(36)),
                              child: Padding(
                                padding: const EdgeInsets.all(6.0),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 28,
                                      height: 28,
                                      decoration: BoxDecoration(
                                          color: Colors.green,
                                          borderRadius:
                                              BorderRadius.circular(360)),
                                      child: Center(
                                        child: Text(
                                          "#",
                                          style: TextStyle(color: Colors.black),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 12,
                                    ),
                                    Expanded(
                                        flex: 4,
                                        child: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 12.0),
                                          child: Text("Agent Name"),
                                        )),
                                    Expanded(
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(right: 24.0),
                                        child: Text(
                                          "Sales",
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: ListView.builder(
                                  itemCount: (_selectedButton == 1)
                                      ? (sales_index == 0
                                          ? min(
                                              Constants
                                                  .sales_salesbyagent1a.length,
                                              10)
                                          : sales_index == 1
                                              ? min(
                                                  Constants.sales_salesbyagent1b
                                                      .length,
                                                  10)
                                              : min(
                                                  Constants.sales_salesbyagent1c
                                                      .length,
                                                  10))
                                      : (_selectedButton == 2)
                                          ? (sales_index == 0
                                              ? min(
                                                  Constants.sales_salesbyagent2a
                                                      .length,
                                                  10)
                                              : sales_index == 1
                                                  ? min(
                                                      Constants
                                                          .sales_salesbyagent2b
                                                          .length,
                                                      10)
                                                  : min(
                                                      Constants
                                                          .sales_salesbyagent2c
                                                          .length,
                                                      10))
                                          : (_selectedButton == 3 &&
                                                  days_difference <= 31)
                                              ? (sales_index == 0
                                                  ? min(
                                                      Constants
                                                          .sales_salesbyagent3a
                                                          .length,
                                                      10)
                                                  : sales_index == 1
                                                      ? min(
                                                          Constants
                                                              .sales_salesbyagent3b
                                                              .length,
                                                          10)
                                                      : min(
                                                          Constants
                                                              .sales_salesbyagent3c
                                                              .length,
                                                          10))
                                              : (sales_index == 0
                                                  ? min(
                                                      Constants
                                                          .sales_salesbyagent4a
                                                          .length,
                                                      10)
                                                  : sales_index == 1
                                                      ? min(
                                                          Constants
                                                              .sales_salesbyagent4b
                                                              .length,
                                                          10)
                                                      : min(
                                                          Constants
                                                              .sales_salesbyagent4c
                                                              .length,
                                                          10)),
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Container(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Container(
                                                  width: 45,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 4.0),
                                                    child:
                                                        Text("${index + 1} "),
                                                  ),
                                                ),
                                                Expanded(
                                                    flex: 4,
                                                    child: Text(
                                                        "${(_selectedButton == 1) ? (sales_index == 0 ? Constants.sales_salesbyagent1a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent1b[index].agent_name : Constants.sales_salesbyagent1c[index].agent_name) : (_selectedButton == 2) ? (sales_index == 0 ? Constants.sales_salesbyagent2a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent2b[index].agent_name : Constants.sales_salesbyagent2c[index].agent_name) : (_selectedButton == 3 && days_difference <= 31) ? (sales_index == 0 ? Constants.sales_salesbyagent3a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent3a[index].agent_name : Constants.sales_salesbyagent3c[index].agent_name) : (sales_index == 0 ? Constants.sales_salesbyagent4a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent4b[index].agent_name : Constants.sales_salesbyagent4c[index].agent_name)}")),
                                                Expanded(
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: Container(
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    left: 8.0),
                                                            child: Text(
                                                              "${(_selectedButton == 1) ? (sales_index == 0 ? Constants.sales_salesbyagent1a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent1b[index].sales.toInt() : Constants.sales_salesbyagent1c[index].sales.toInt()) : (_selectedButton == 2) ? (sales_index == 0 ? Constants.sales_salesbyagent2a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent2b[index].sales.toInt() : Constants.sales_salesbyagent2c[index].sales.toInt()) : (_selectedButton == 3 && days_difference <= 31) ? (sales_index == 0 ? Constants.sales_salesbyagent3a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent3a[index].sales.toInt() : Constants.sales_salesbyagent3c[index].sales.toInt()) : (sales_index == 0 ? Constants.sales_salesbyagent4a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent4b[index].sales.toInt() : Constants.sales_salesbyagent4c[index].sales.toInt())}",
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              ],
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 8.0),
                                              child: Container(
                                                height: 1,
                                                color: Colors.grey
                                                    .withOpacity(0.10),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  }),
                            ),
                          ],
                        )),
                      ),
                    ),

                    _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 12),
                            child: Text(
                                "Bottom 10 Sales Agents (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Bottom 10 Sales By Agent (12 Months View)"),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Bottom 10 Sales By Agent (${Constants.sales_formattedStartDate} to ${Constants.sales_formattedEndDate})"),
                              ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 6,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20)),
                        child: Container(
                            child: Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(36)),
                              child: Padding(
                                padding: const EdgeInsets.all(6.0),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 28,
                                      height: 28,
                                      decoration: BoxDecoration(
                                          color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(360)),
                                      child: Center(
                                        child: Text(
                                          "#",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 12,
                                    ),
                                    Expanded(
                                        flex: 4,
                                        child: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 12.0),
                                          child: Text("Agent Name"),
                                        )),
                                    Expanded(
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(right: 24.0),
                                        child: Text(
                                          "Sales",
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: ListView.builder(
                                  reverse: true,
                                  itemCount: (_selectedButton == 1)
                                      ? (sales_index == 0
                                          ? min(
                                              Constants
                                                  .sales_salesbyagent5a.length,
                                              10)
                                          : sales_index == 1
                                              ? min(
                                                  Constants.sales_salesbyagent5b
                                                      .length,
                                                  10)
                                              : min(
                                                  Constants.sales_salesbyagent5c
                                                      .length,
                                                  10))
                                      : (_selectedButton == 2)
                                          ? (sales_index == 0
                                              ? min(
                                                  Constants.sales_salesbyagent6a
                                                      .length,
                                                  10)
                                              : sales_index == 1
                                                  ? min(
                                                      Constants
                                                          .sales_salesbyagent6b
                                                          .length,
                                                      10)
                                                  : min(
                                                      Constants
                                                          .sales_salesbyagent6c
                                                          .length,
                                                      10))
                                          : (_selectedButton == 3 &&
                                                  days_difference <= 31)
                                              ? (sales_index == 0
                                                  ? min(
                                                      Constants
                                                          .sales_salesbyagent7a
                                                          .length,
                                                      10)
                                                  : sales_index == 1
                                                      ? min(
                                                          Constants
                                                              .sales_salesbyagent7b
                                                              .length,
                                                          10)
                                                      : min(
                                                          Constants
                                                              .sales_salesbyagent7c
                                                              .length,
                                                          10))
                                              : (sales_index == 0
                                                  ? min(
                                                      Constants
                                                          .sales_salesbyagent8a
                                                          .length,
                                                      10)
                                                  : sales_index == 1
                                                      ? min(
                                                          Constants
                                                              .sales_salesbyagent8b
                                                              .length,
                                                          10)
                                                      : min(
                                                          Constants
                                                              .sales_salesbyagent8c
                                                              .length,
                                                          10)),
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Container(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Container(
                                                  width: 45,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 4.0),
                                                    child: Text(
                                                        "${((index - 9).abs()) + 1} "),
                                                  ),
                                                ),
                                                Expanded(
                                                    flex: 4,
                                                    child: Text(
                                                        "${(_selectedButton == 1) ? (sales_index == 0 ? Constants.sales_salesbyagent5a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent5b[index].agent_name : Constants.sales_salesbyagent5c[index].agent_name) : (_selectedButton == 2) ? (sales_index == 0 ? Constants.sales_salesbyagent6a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent6b[index].agent_name : Constants.sales_salesbyagent6c[index].agent_name) : (_selectedButton == 3 && days_difference <= 31) ? (sales_index == 0 ? Constants.sales_salesbyagent7a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent7b[index].agent_name : Constants.sales_salesbyagent7c[index].agent_name) : (sales_index == 0 ? Constants.sales_salesbyagent8a[index].agent_name : sales_index == 1 ? Constants.sales_salesbyagent8b[index].agent_name : Constants.sales_salesbyagent8c[index].agent_name)}")),
                                                Expanded(
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: Container(
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    left: 8.0),
                                                            child: Text(
                                                              "${(_selectedButton == 1) ? (sales_index == 0 ? Constants.sales_salesbyagent5a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent5b[index].sales.toInt() : Constants.sales_salesbyagent5c[index].sales.toInt()) : (_selectedButton == 2) ? (sales_index == 0 ? Constants.sales_salesbyagent6a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent6b[index].sales.toInt() : Constants.sales_salesbyagent6c[index].sales.toInt()) : (_selectedButton == 3 && days_difference <= 31) ? (sales_index == 0 ? Constants.sales_salesbyagent7a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent7b[index].sales.toInt() : Constants.sales_salesbyagent7c[index].sales.toInt()) : (sales_index == 0 ? Constants.sales_salesbyagent8a[index].sales.toInt() : sales_index == 1 ? Constants.sales_salesbyagent8b[index].sales.toInt() : Constants.sales_salesbyagent8c[index].sales.toInt())}",
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              ],
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 8.0),
                                              child: Container(
                                                height: 1,
                                                color: Colors.grey
                                                    .withOpacity(0.10),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  }),
                            ),
                          ],
                        )),
                      ),
                    ),

                    /*      Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 6,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20)),
                        child: Container(
                            child: Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(36)),
                              child: Padding(
                                padding: const EdgeInsets.all(6.0),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 28,
                                      height: 28,
                                      decoration: BoxDecoration(
                                          color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(360)),
                                      child: Center(
                                        child: Text(
                                          "#",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 12,
                                    ),
                                    Expanded(
                                        flex: 4,
                                        child: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 12.0),
                                          child: Text("Agent Name"),
                                        )),
                                    Expanded(
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(right: 24.0),
                                        child: Text(
                                          "Sales",
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: ListView.builder(
                                  reverse: true,
                                  itemCount: (_selectedButton == 1)
                                      ? Constants.sales_salesbyagent5a.length >
                                              10
                                          ? 10
                                          : Constants
                                              .sales_salesbyagent5a.length
                                      : (_selectedButton == 2)
                                          ? Constants.sales_salesbyagent5a
                                                      .length >
                                                  10
                                              ? 10
                                              : Constants
                                                  .sales_salesbyagent3a.length
                                          : (_selectedButton == 3 &&
                                                  days_difference <= 31)
                                              ? Constants.sales_salesbyagent3a
                                                          .length >
                                                      10
                                                  ? 10
                                                  : Constants
                                                      .sales_salesbyagent3b
                                                      .length
                                              : Constants.sales_salesbyagent3b
                                                          .length >
                                                      10
                                                  ? 10
                                                  : Constants
                                                      .sales_salesbyagent3b
                                                      .length,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Container(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Container(
                                                  width: 45,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 4.0),
                                                    child: Text(
                                                        "${((index - 9).abs()) + 1} "),
                                                  ),
                                                ),
                                                Expanded(
                                                    flex: 4,
                                                    child: Text(
                                                        "${(_selectedButton == 1) ? Constants.sales_salesbyagent4a[index].agent_name : (_selectedButton == 2) ? Constants.sales_salesbyagent5a[index].agent_name : (_selectedButton == 3 && days_difference <= 31) ? Constants.sales_salesbyagent3a[index].agent_name : Constants.sales_salesbyagent3b[index].agent_name}")),
                                                Expanded(
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: Container(
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    left: 8.0),
                                                            child: Text(
                                                              "${(_selectedButton == 1) ? Constants.sales_salesbyagent4a[index].sales.toInt() : (_selectedButton == 2) ? Constants.sales_salesbyagent5a[index].sales.toInt() : (_selectedButton == 3 && days_difference <= 31) ? Constants.sales_salesbyagent3a[index].sales.toInt() : Constants.sales_salesbyagent3b[index].sales.toInt()}",
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              ],
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 8.0),
                                              child: Container(
                                                height: 1,
                                                color: Colors.grey
                                                    .withOpacity(0.10),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  }),
                            ),
                          ],
                        )),
                      ),
                    ),*/

                    _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 12),
                            child: Text(
                                "All Sales By Branch (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "All Sales By Branch (12 Months View)"),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "All Sales By Branch (${Constants.sales_formattedStartDate} to ${Constants.sales_formattedEndDate})"),
                              ),

                    _selectedButton == 1
                        ? sales_index == 0
                            ? Container(
                                height:
                                    Constants.sales_salesbybranch1a.length * 35,
                                width: MediaQuery.of(context).size.width,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Card(
                                    elevation: 6,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(20)),
                                    child: Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child: charts.BarChart(
                                        Constants.sales_bardata1a,

                                        animate: true,
                                        vertical: false,

                                        // Set a bar label decorator.
                                        // Example configuring different styles for inside/outside:
                                        //       barRendererDecorator: new charts.BarLabelDecorator(
                                        //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                        //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                        barRendererDecorator: new charts
                                            .BarLabelDecorator<String>(),
                                        // Hide domain axis.
                                        /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                        primaryMeasureAxis:
                                            new charts.NumericAxisSpec(
                                          renderSpec:
                                              new charts.NoneRenderSpec(),
                                          viewport: new charts.NumericExtents(
                                              0, Constants.sales_bar_maxY1a),
                                        ),
                                        domainAxis: new charts.OrdinalAxisSpec(
                                          renderSpec:
                                              new charts.SmallTickRendererSpec(
                                            labelStyle:
                                                new charts.TextStyleSpec(
                                              fontSize: 10,
                                              color:
                                                  charts.MaterialPalette.black,
                                            ),
                                            lineStyle: new charts.LineStyleSpec(
                                              color:
                                                  charts.MaterialPalette.black,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            : sales_index == 1
                                ? Container(
                                    height:
                                        Constants.sales_salesbybranch1b.length *
                                            35,
                                    width: MediaQuery.of(context).size.width,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Card(
                                        elevation: 6,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: charts.BarChart(
                                            Constants.sales_bardata1b,

                                            animate: true,
                                            vertical: false,

                                            // Set a bar label decorator.
                                            // Example configuring different styles for inside/outside:
                                            //       barRendererDecorator: new charts.BarLabelDecorator(
                                            //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                            //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                            barRendererDecorator: new charts
                                                .BarLabelDecorator<String>(),
                                            // Hide domain axis.
                                            /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                            primaryMeasureAxis:
                                                new charts.NumericAxisSpec(
                                              renderSpec:
                                                  new charts.NoneRenderSpec(),
                                              viewport:
                                                  new charts.NumericExtents(
                                                      0,
                                                      Constants
                                                          .sales_bar_maxY1b),
                                            ),
                                            domainAxis:
                                                new charts.OrdinalAxisSpec(
                                              renderSpec: new charts
                                                  .SmallTickRendererSpec(
                                                labelStyle:
                                                    new charts.TextStyleSpec(
                                                  fontSize: 10,
                                                  color: charts
                                                      .MaterialPalette.black,
                                                ),
                                                lineStyle:
                                                    new charts.LineStyleSpec(
                                                  color: charts
                                                      .MaterialPalette.black,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                : Container(
                                    height:
                                        Constants.sales_salesbybranch1c.length *
                                            35,
                                    width: MediaQuery.of(context).size.width,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Card(
                                        elevation: 6,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: charts.BarChart(
                                            Constants.sales_bardata1c,

                                            animate: true,
                                            vertical: false,

                                            // Set a bar label decorator.
                                            // Example configuring different styles for inside/outside:
                                            //       barRendererDecorator: new charts.BarLabelDecorator(
                                            //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                            //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                            barRendererDecorator: new charts
                                                .BarLabelDecorator<String>(),
                                            // Hide domain axis.
                                            /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                            primaryMeasureAxis:
                                                new charts.NumericAxisSpec(
                                              renderSpec:
                                                  new charts.NoneRenderSpec(),
                                              viewport:
                                                  new charts.NumericExtents(
                                                      0,
                                                      Constants
                                                          .sales_bar_maxY1c),
                                            ),
                                            domainAxis:
                                                new charts.OrdinalAxisSpec(
                                              renderSpec: new charts
                                                  .SmallTickRendererSpec(
                                                labelStyle:
                                                    new charts.TextStyleSpec(
                                                  fontSize: 10,
                                                  color: charts
                                                      .MaterialPalette.black,
                                                ),
                                                lineStyle:
                                                    new charts.LineStyleSpec(
                                                  color: charts
                                                      .MaterialPalette.black,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                        : _selectedButton == 2
                            ? sales_index == 0
                                ? Container(
                                    height:
                                        Constants.sales_salesbybranch2a.length *
                                            35,
                                    width: MediaQuery.of(context).size.width,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Card(
                                        elevation: 6,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: charts.BarChart(
                                            Constants.sales_bardata2a,

                                            animate: true,
                                            vertical: false,

                                            // Set a bar label decorator.
                                            // Example configuring different styles for inside/outside:
                                            //       barRendererDecorator: new charts.BarLabelDecorator(
                                            //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                            //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                            barRendererDecorator: new charts
                                                .BarLabelDecorator<String>(),
                                            // Hide domain axis.
                                            /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                            primaryMeasureAxis:
                                                new charts.NumericAxisSpec(
                                              renderSpec:
                                                  new charts.NoneRenderSpec(),
                                              viewport:
                                                  new charts.NumericExtents(
                                                      0,
                                                      Constants
                                                          .sales_bar_maxY2a),
                                            ),
                                            domainAxis:
                                                new charts.OrdinalAxisSpec(
                                              renderSpec: new charts
                                                  .SmallTickRendererSpec(
                                                labelStyle:
                                                    new charts.TextStyleSpec(
                                                  fontSize: 10,
                                                  color: charts
                                                      .MaterialPalette.black,
                                                ),
                                                lineStyle:
                                                    new charts.LineStyleSpec(
                                                  color: charts
                                                      .MaterialPalette.black,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                : sales_index == 1
                                    ? Container(
                                        height: Constants
                                                .sales_salesbybranch2b.length *
                                            35,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Card(
                                            elevation: 6,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(20)),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(4.0),
                                              child: charts.BarChart(
                                                Constants.sales_bardata2b,

                                                animate: true,
                                                vertical: false,

                                                // Set a bar label decorator.
                                                // Example configuring different styles for inside/outside:
                                                //       barRendererDecorator: new charts.BarLabelDecorator(
                                                //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                barRendererDecorator: new charts
                                                    .BarLabelDecorator<
                                                        String>(),
                                                // Hide domain axis.
                                                /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                primaryMeasureAxis:
                                                    new charts.NumericAxisSpec(
                                                  renderSpec: new charts
                                                      .NoneRenderSpec(),
                                                  viewport: new charts
                                                      .NumericExtents(
                                                      0,
                                                      Constants
                                                          .sales_bar_maxY2b),
                                                ),
                                                domainAxis:
                                                    new charts.OrdinalAxisSpec(
                                                  renderSpec: new charts
                                                      .SmallTickRendererSpec(
                                                    labelStyle: new charts
                                                        .TextStyleSpec(
                                                      fontSize: 10,
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                    lineStyle: new charts
                                                        .LineStyleSpec(
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                                    : Container(
                                        height: Constants
                                                .sales_salesbybranch2c.length *
                                            35,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Card(
                                            elevation: 6,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(20)),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(4.0),
                                              child: charts.BarChart(
                                                Constants.sales_bardata2c,

                                                animate: true,
                                                vertical: false,

                                                // Set a bar label decorator.
                                                // Example configuring different styles for inside/outside:
                                                //       barRendererDecorator: new charts.BarLabelDecorator(
                                                //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                barRendererDecorator: new charts
                                                    .BarLabelDecorator<
                                                        String>(),
                                                // Hide domain axis.
                                                /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                primaryMeasureAxis:
                                                    new charts.NumericAxisSpec(
                                                  renderSpec: new charts
                                                      .NoneRenderSpec(),
                                                  viewport: new charts
                                                      .NumericExtents(
                                                      0,
                                                      Constants
                                                          .sales_bar_maxY2c),
                                                ),
                                                domainAxis:
                                                    new charts.OrdinalAxisSpec(
                                                  renderSpec: new charts
                                                      .SmallTickRendererSpec(
                                                    labelStyle: new charts
                                                        .TextStyleSpec(
                                                      fontSize: 10,
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                    lineStyle: new charts
                                                        .LineStyleSpec(
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                            : (_selectedButton == 3 && days_difference <= 31)
                                ? sales_index == 0
                                    ? Container(
                                        height: Constants
                                                .sales_salesbybranch3a.length *
                                            45,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Card(
                                            key: Constants.sales_bardata3a_key,
                                            elevation: 6,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(20)),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(4.0),
                                              child: charts.BarChart(
                                                Constants.sales_bardata3a,

                                                animate: true,
                                                vertical: false,

                                                // Set a bar label decorator.
                                                // Example configuring different styles for inside/outside:
                                                //       barRendererDecorator: new charts.BarLabelDecorator(
                                                //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                barRendererDecorator: new charts
                                                    .BarLabelDecorator<
                                                        String>(),
                                                // Hide domain axis.
                                                /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                primaryMeasureAxis:
                                                    new charts.NumericAxisSpec(
                                                  renderSpec: new charts
                                                      .NoneRenderSpec(),
                                                  viewport: new charts
                                                      .NumericExtents(
                                                      0,
                                                      Constants
                                                          .sales_bar_maxY3a),
                                                ),
                                                domainAxis:
                                                    new charts.OrdinalAxisSpec(
                                                  renderSpec: new charts
                                                      .SmallTickRendererSpec(
                                                    labelStyle: new charts
                                                        .TextStyleSpec(
                                                      fontSize: 10,
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                    lineStyle: new charts
                                                        .LineStyleSpec(
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                                    : sales_index == 1
                                        ? Container(
                                            height: Constants
                                                    .sales_salesbybranch3b
                                                    .length *
                                                45,
                                            width: MediaQuery.of(context)
                                                .size
                                                .width,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Card(
                                                elevation: 6,
                                                key: Constants
                                                    .sales_bardata3b_key,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(4.0),
                                                  child: charts.BarChart(
                                                    Constants.sales_bardata3b,

                                                    animate: true,
                                                    vertical: false,

                                                    // Set a bar label decorator.
                                                    // Example configuring different styles for inside/outside:
                                                    //       barRendererDecorator: new charts.BarLabelDecorator(
                                                    //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                    //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                    barRendererDecorator:
                                                        new charts
                                                            .BarLabelDecorator<
                                                                String>(),
                                                    // Hide domain axis.
                                                    /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                    primaryMeasureAxis:
                                                        new charts
                                                            .NumericAxisSpec(
                                                      renderSpec: new charts
                                                          .NoneRenderSpec(),
                                                      viewport: new charts
                                                          .NumericExtents(
                                                          0,
                                                          Constants
                                                              .sales_bar_maxY3b),
                                                    ),
                                                    domainAxis: new charts
                                                        .OrdinalAxisSpec(
                                                      renderSpec: new charts
                                                          .SmallTickRendererSpec(
                                                        labelStyle: new charts
                                                            .TextStyleSpec(
                                                          fontSize: 10,
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                        lineStyle: new charts
                                                            .LineStyleSpec(
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                        : Container(
                                            height: Constants
                                                    .sales_salesbybranch3c
                                                    .length *
                                                45,
                                            width: MediaQuery.of(context)
                                                .size
                                                .width,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Card(
                                                elevation: 6,
                                                key: Constants
                                                    .sales_bardata3c_key,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(4.0),
                                                  child: charts.BarChart(
                                                    Constants.sales_bardata3c,

                                                    animate: true,
                                                    vertical: false,

                                                    // Set a bar label decorator.
                                                    // Example configuring different styles for inside/outside:
                                                    //       barRendererDecorator: new charts.BarLabelDecorator(
                                                    //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                    //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                    barRendererDecorator:
                                                        new charts
                                                            .BarLabelDecorator<
                                                                String>(),
                                                    // Hide domain axis.
                                                    /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                    primaryMeasureAxis:
                                                        new charts
                                                            .NumericAxisSpec(
                                                      renderSpec: new charts
                                                          .NoneRenderSpec(),
                                                      viewport: new charts
                                                          .NumericExtents(
                                                          0,
                                                          Constants
                                                              .sales_bar_maxY3c),
                                                    ),
                                                    domainAxis: new charts
                                                        .OrdinalAxisSpec(
                                                      renderSpec: new charts
                                                          .SmallTickRendererSpec(
                                                        labelStyle: new charts
                                                            .TextStyleSpec(
                                                          fontSize: 10,
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                        lineStyle: new charts
                                                            .LineStyleSpec(
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                : sales_index == 0
                                    ? Container(
                                        height: Constants
                                                .sales_salesbybranch4a.length *
                                            35,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Card(
                                            elevation: 6,
                                            key: Constants.sales_bardata4a_key,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(20)),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(4.0),
                                              child: charts.BarChart(
                                                Constants.sales_bardata4a,

                                                animate: true,
                                                vertical: false,

                                                // Set a bar label decorator.
                                                // Example configuring different styles for inside/outside:
                                                //       barRendererDecorator: new charts.BarLabelDecorator(
                                                //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                barRendererDecorator: new charts
                                                    .BarLabelDecorator<
                                                        String>(),
                                                // Hide domain axis.
                                                /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                primaryMeasureAxis:
                                                    new charts.NumericAxisSpec(
                                                  renderSpec: new charts
                                                      .NoneRenderSpec(),
                                                  viewport: new charts
                                                      .NumericExtents(
                                                      0,
                                                      Constants
                                                          .sales_bar_maxY4a),
                                                ),
                                                domainAxis:
                                                    new charts.OrdinalAxisSpec(
                                                  renderSpec: new charts
                                                      .SmallTickRendererSpec(
                                                    labelStyle: new charts
                                                        .TextStyleSpec(
                                                      fontSize: 10,
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                    lineStyle: new charts
                                                        .LineStyleSpec(
                                                      color: charts
                                                          .MaterialPalette
                                                          .black,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                                    : sales_index == 1
                                        ? Container(
                                            height: Constants
                                                    .sales_salesbybranch4b
                                                    .length *
                                                35,
                                            width: MediaQuery.of(context)
                                                .size
                                                .width,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Card(
                                                elevation: 6,
                                                key: Constants
                                                    .sales_bardata4b_key,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(4.0),
                                                  child: charts.BarChart(
                                                    Constants.sales_bardata4b,

                                                    animate: true,
                                                    vertical: false,

                                                    // Set a bar label decorator.
                                                    // Example configuring different styles for inside/outside:
                                                    //       barRendererDecorator: new charts.BarLabelDecorator(
                                                    //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                    //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                    barRendererDecorator:
                                                        new charts
                                                            .BarLabelDecorator<
                                                                String>(),
                                                    // Hide domain axis.
                                                    /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                    primaryMeasureAxis:
                                                        new charts
                                                            .NumericAxisSpec(
                                                      renderSpec: new charts
                                                          .NoneRenderSpec(),
                                                      viewport: new charts
                                                          .NumericExtents(
                                                          0,
                                                          Constants
                                                              .sales_bar_maxY4b),
                                                    ),
                                                    domainAxis: new charts
                                                        .OrdinalAxisSpec(
                                                      renderSpec: new charts
                                                          .SmallTickRendererSpec(
                                                        labelStyle: new charts
                                                            .TextStyleSpec(
                                                          fontSize: 10,
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                        lineStyle: new charts
                                                            .LineStyleSpec(
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                        : Container(
                                            height: Constants
                                                    .sales_salesbybranch4c
                                                    .length *
                                                35,
                                            width: MediaQuery.of(context)
                                                .size
                                                .width,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Card(
                                                elevation: 6,
                                                key: Constants
                                                    .sales_bardata4c_key,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20)),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(4.0),
                                                  child: charts.BarChart(
                                                    Constants.sales_bardata4c,

                                                    animate: true,
                                                    vertical: false,

                                                    // Set a bar label decorator.
                                                    // Example configuring different styles for inside/outside:
                                                    //       barRendererDecorator: new charts.BarLabelDecorator(
                                                    //          insideLabelStyleSpec: new charts.TextStyleSpec(...),
                                                    //          outsideLabelStyleSpec: new charts.TextStyleSpec(...)),
                                                    barRendererDecorator:
                                                        new charts
                                                            .BarLabelDecorator<
                                                                String>(),
                                                    // Hide domain axis.
                                                    /*          domainAxis: new charts.OrdinalAxisSpec(
                                  renderSpec: new charts.NoneRenderSpec()),*/
                                                    primaryMeasureAxis:
                                                        new charts
                                                            .NumericAxisSpec(
                                                      renderSpec: new charts
                                                          .NoneRenderSpec(),
                                                      viewport: new charts
                                                          .NumericExtents(
                                                          0,
                                                          Constants
                                                              .sales_bar_maxY4c),
                                                    ),
                                                    domainAxis: new charts
                                                        .OrdinalAxisSpec(
                                                      renderSpec: new charts
                                                          .SmallTickRendererSpec(
                                                        labelStyle: new charts
                                                            .TextStyleSpec(
                                                          fontSize: 10,
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                        lineStyle: new charts
                                                            .LineStyleSpec(
                                                          color: charts
                                                              .MaterialPalette
                                                              .black,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                    /*   _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 12),
                            child: Text("All Sales By Product Type"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text("All Sales By Product Type"),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text("All Sales By Product Type"),
                              ),*/
                    /*     (_selectedButton == 1 &&
                            Constants.salesProductsGrouped1a.length > 1)
                        ? Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: SfTreemap(
                              key: Constants.sales_product_type_key,
                              dataCount:
                                  Constants.salesProductsGrouped1a.length,
                              levels: _buildFirstLevel(),
                              weightValueMapper: (int index) {
                                return Constants
                                    .salesProductsGrouped1a[index].count
                                    .toDouble();
                              },
                            ),
                          )
                        : Container(),*/

                    /*Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      child: charts.BarChart(
                        bardata5,
                        animate: false,
                        vertical: false,
                        barRendererDecorator: new charts.BarLabelDecorator<String>(),
                        domainAxis: new charts.OrdinalAxisSpec(
                          renderSpec: new charts.SmallTickRendererSpec(
                            labelStyle: new charts.TextStyleSpec(
                              fontSize: 10,
                              color: charts.MaterialPalette.black, // color for the text
                            ),
                            lineStyle: new charts.LineStyleSpec(
                              color: charts.MaterialPalette.black, // color for the line
                            ),
                          ),
                        ),
                        // ... Other chart configurations
                      ),
                    ),*/
                    /*ListView.builder(
                      itemCount: salesbybranch.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        var element = salesbybranch[index];
                        double barWidth = (element.sales.toDouble() / Constants.maxY) *
                            MediaQuery.of(context)
                                .size
                                .width; // Calculate bar width as a fraction of maxSales

                        return Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: <Widget>[
                              Container(
                                width: barWidth, // Width of the bar
                                height: 20, // Fixed height of the bar
                                color: Colors.blue, // Color of the bar
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: Text(
                                      element.sales.toString()), // Display the value
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),*/

                    /*  Container(
                      height: barData.length * 40,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Card(
                          elevation: 6,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                          child: Padding(
                              padding: const EdgeInsets.all(14.0),
                              child: Container(
                                height: barData.length * 30,
                                child: RotatedBox(
                                  quarterTurns: -3,
                                  child: BarChart(
                                    BarChartData(
                                      gridData: FlGridData(
                                        show: true,
                                        drawVerticalLine: true,
                                        drawHorizontalLine: false,
                                        getDrawingHorizontalLine: (value) {
                                          return FlLine(
                                            color: Colors.grey.withOpacity(0.10),
                                            strokeWidth: 1,
                                          );
                                        },
                                        getDrawingVerticalLine: (value) {
                                          return FlLine(
                                            color: Colors.grey,
                                            strokeWidth: 1,
                                          );
                                        },
                                      ),
                                      borderData: FlBorderData(
                                        show: false,
                                      ),
                                      titlesData: getTitlesData(bottomTitles1),
                                      barGroups: barData,
                                    ),
                                  ),
                                ),
                              )),
                        ),
                      ),
                    ),*/
                    /*         _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 12),
                            child: Text("Top 5 Sales By Branch (MTD)"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text("Top 5 Sales By Branch (YTD)"),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Top 5 Sales By Branch (${formattedEndDate} to ${formattedEndDate})"),
                              ),*/
                    /*AspectRatio(
                      aspectRatio: 1.3,
                      child: Row(
                        children: <Widget>[
                          const SizedBox(
                            height: 18,
                          ),
                          Expanded(
                            flex: 3,
                            child: AspectRatio(
                              aspectRatio: 1,
                              child: PieChart(
                                PieChartData(
                                  pieTouchData: PieTouchData(
                                    touchCallback:
                                        (FlTouchEvent event, pieTouchResponse) {
                                      setState(() {
                                        if (!event
                                                .isInterestedForInteractions ||
                                            pieTouchResponse == null ||
                                            pieTouchResponse.touchedSection ==
                                                null) {
                                          touchedIndex = -1;
                                          return;
                                        }
                                        touchedIndex = pieTouchResponse
                                            .touchedSection!
                                            .touchedSectionIndex;
                                      });
                                    },
                                  ),
                                  borderData: FlBorderData(
                                    show: true,
                                    border: Border(
                                      left: BorderSide.none,
                                      bottom: BorderSide(
                                        color: Colors.grey.withOpacity(0.35),
                                        width: 1,
                                      ),
                                      right: BorderSide.none,
                                      top: BorderSide.none,
                                    ),
                                  ),
                                  sectionsSpace: 0,
                                  centerSpaceRadius: 40,
                                  sections: pieData,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: ListView.builder(
                                itemCount: salesbybranch.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  if (index < 5) {
                                    return Indicator(
                                      color: samplecolors[index],
                                      text: salesbybranch[index]
                                          .branch_name
                                          .toString(),
                                      isSquare: true,
                                    );
                                  } else
                                    Container();
                                }),
                          ),
                          const SizedBox(
                            width: 28,
                          ),
                        ],
                      ),
                    ),*/
                    //PieChart(data)

                    /*(leads.isNotEmpty)
                        ? DataTable(
                            columns: const [
                              DataColumn(label: Text('No.')),
                              DataColumn(label: Text('Date & Time')),
                              DataColumn(label: Text('Employee')),
                              DataColumn(label: Text('Cell Number')),
                              DataColumn(label: Text('Customer Name')),
                              DataColumn(label: Text('Branch Type')),
                              DataColumn(label: Text('Branch')),
                              DataColumn(label: Text('Status')),
                              DataColumn(label: Text('View')),
                            ],
                            rows: List<DataRow>.generate(
                              leads.length,
                              (index) {
                                final lead = leads[index];

                                return DataRow(
                                  cells: [
                                    DataCell(Text((index + 1).toString())),
                                    DataCell(Text(
                                      '${DateFormat('MMM d, yyyy').format(DateTime.parse(lead["sale_datetime"]))}',
                                    )), // Replace with date and time data
                                    DataCell(Text(getEmployeeById(
                                        int.parse(lead["assigned_to"].toString()) ??
                                            0))), // Replace with employee data
                                    DataCell(Text(lead["cell_number"] ?? '')),
                                    DataCell(Text(lead["first_name"] +
                                        " " +
                                        lead[
                                            "last_name"])), // Replace with customer name data
                                    DataCell(
                                        Text('...')), // Replace with branch type data
                                    DataCell(Text('...')), // Replace with branch data
                                    DataCell(Text('...')), // Replace with status data
                                    DataCell(
                                      IconButton(
                                        icon: Icon(Icons.visibility),
                                        onPressed: () {
                                          // handle view button pressed
                                        },
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          )
                        : Center(
                            child: Container(
                            height: 80,
                            width: 80,
                            child: CircularProgressIndicator(
                              strokeWidth: 1,
                              valueColor:
                                  new AlwaysStoppedAnimation<Color>(Color(0xff121212)),
                            ),
                          )),*/
                  ],
                )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    secureScreen();
    _animateButton(1);
    setState(() {});

/*    myNotifier = MyNotifier(salesValue, context);
    salesValue.addListener(() {
      kyrt = UniqueKey();
      setState(() {});
      Future.delayed(Duration(seconds: 2)).then((value) {
        print("ghjg");
        setState(() {});
      });
    });
    Future.delayed(Duration(seconds: 3)).then((value) {
      setState(() {});
    });
    print(Constants.sales_spots2a);*/

    /*  getSalesReport3a(Constants.sales_formattedStartDate,
        Constants.sales_formattedEndDate, 3, days_difference);*/
    setState(() {});
    // getSalesReport(context, formattedStartDate, formattedEndDate);

    super.initState();
  }

  init2() {
    DateTime now = DateTime.now();
    DateTime startDate = DateTime(now.year, now.month, 1);
    DateTime endDate = DateTime.now();

    DateTime firstDayNextMonth;

// Check if this month is December, then the next month is January of next year
    if (now.month == 12) {
      firstDayNextMonth = DateTime(now.year + 1, 1, 1);
    } else {
      firstDayNextMonth = DateTime(now.year, now.month + 1, 1);
    }

    DateTime lastDayThisMonth = firstDayNextMonth.subtract(Duration(days: 1));
    noOfDaysThisMonth = lastDayThisMonth.day;

    _animateButton(1);
    Constants.sales_formattedStartDate =
        DateFormat('yyyy-MM-dd').format(startDate!);
    Constants.sales_formattedEndDate =
        DateFormat('yyyy-MM-dd').format(endDate!);
    setState(() {});

    String dateRange =
        '${Constants.sales_formattedStartDate} - ${Constants.sales_formattedEndDate}';
    print("currently loading ${dateRange}");
    DateTime startDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedStartDate);
    DateTime endDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedEndDate);

    days_difference = endDateTime.difference(startDateTime).inDays;

    if (kDebugMode) {
      print("days_difference ${days_difference}");
      print("formattedEndDate9 ${Constants.sales_formattedEndDate}");
    }
  }

  FlTitlesData getTitlesData(List<String> bottomTitles) {
    return FlTitlesData(
      show: true,
      topTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: false,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: Text(
                _selectedButton == 1
                    ? Constants.sales_salesbybranch1a[index - 1].branch_name
                    : Constants.sales_salesbybranch2a[index - 1].branch_name,
                maxLines: 1,
                style: TextStyle(color: Colors.black, fontSize: 12),
              ),
            );
          },
        ),
      ),
      leftTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          reservedSize: 100,
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: RotatedBox(
                quarterTurns: -1,
                child: Text(
                  bottomTitles[index - 1],
                  maxLines: 2,
                  textAlign: TextAlign.right,
                  style: TextStyle(color: Colors.black, fontSize: 12),
                ),
              ),
            );
          },
        ),
      ),
      rightTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: false,
          getTitlesWidget: (double value, TitleMeta meta) {
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 6.0,
              child: RotatedBox(
                quarterTurns: -1,
                child: Text(
                  value.toInt().toString(),
                  style: TextStyle(color: Colors.black),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  FlTitlesData getTitlesData2(List<String> bottomTitles) {
    return FlTitlesData(
      show: true,
      topTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      rightTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: Text(
                bottomTitles[index - 1],
                style: TextStyle(color: Colors.white),
              ),
            );
          },
        ),
      ),
      leftTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 6.0,
              child: Text(
                value.toInt().toString(),
                style: TextStyle(color: Colors.white),
              ),
            );
          },
        ),
      ),
    );
  }

  List<TreemapLevel> _buildFirstLevel() {
    return [
      TreemapLevel(
        groupMapper: (int index) =>
            Constants.salesProductsGrouped1a[index].product,
        color: Colors.blue,
        padding: EdgeInsets.all(2),
        labelBuilder: (BuildContext context, TreemapTile tile) {
          return GestureDetector(
            onTap: () {
              Constants.sales_product_type_key = UniqueKey();
              setState(() {
                currentLevel = 1;
              });
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                '${tile.group} ${tile.weight}',
                style: TextStyle(color: Colors.white),
              ),
            ),
          );
        },
      ),
    ];
  }

  /* List<TreemapLevel> _buildSecondLevel() {
    return [
      TreemapLevel(
        groupMapper: (int index) =>
            Constants.salesProductsGrouped1a[index].productType,
        color: Colors.green,
        padding: EdgeInsets.all(2),
        labelBuilder: (BuildContext context, TreemapTile tile) {
          return GestureDetector(
            onTap: () {
              Constants.sales_product_type_key = UniqueKey();
              setState(() {
                currentLevel = 0; // Set to show the first level
              });
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                '${tile.group}',
                style: TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
          );
        },
      ),
    ];
  }*/
}

class Indicator extends StatelessWidget {
  const Indicator({
    super.key,
    required this.color,
    required this.text,
    required this.isSquare,
    this.size = 16,
    this.textColor,
  });
  final Color color;
  final String text;
  final bool isSquare;
  final double size;
  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: Row(
        children: <Widget>[
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(360),
              shape: isSquare ? BoxShape.rectangle : BoxShape.circle,
              color: color,
            ),
          ),
          const SizedBox(
            width: 4,
          ),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w300,
                color: textColor,
              ),
            ),
          )
        ],
      ),
    );
  }
}

class CustomDotPainter extends FlDotPainter {
  final double yValue;
  final double xValue;
  final double maxX; // Maximum X-value of the chart
  final double maxY; // Maximum Y-value of the chart
  final double chartWidth; // Width of the chart
  final double chartHeight; // Height of the chart

  CustomDotPainter({
    required this.yValue,
    required this.xValue,
    required this.maxX,
    required this.maxY,
    required this.chartWidth,
    required this.chartHeight,
  });

  @override
  void paint(Canvas canvas, Size size, FlSpot spot, double xPercent,
      double yPercent, LineChartBarData bar, int index) {
    // Calculate the position based on chart dimensions and spot's value
    double xPosition = (xValue / maxX) * chartWidth;
    double yPosition =
        chartHeight - (yValue / Constants.sales_maxY) * chartHeight;

    // Paint the dot
    final paint = Paint()..color = Constants.ctaColorLight;
    canvas.drawCircle(Offset(xPosition, yPosition), size.width / 2, paint);

    // Draw the text
    TextSpan span = TextSpan(
        style: TextStyle(color: Colors.black), text: yValue.round().toString());
    TextPainter tp = TextPainter(
        text: span,
        textAlign: TextAlign.center,
        textDirection: ui.TextDirection.ltr);
    tp.layout();

    // Adjust the position to paint the text
    double textX = xPosition - tp.width / 2;
    double textY = yPosition - tp.height - 10;

    // Paint the text
    tp.paint(canvas, Offset(textX, textY));
  }

  @override
  void draw(Canvas canvas, FlSpot spot, Offset offsetInCanvas) {
    paint(canvas, getSize(spot), spot, 0, 0,
        LineChartBarData(color: Colors.blue), 0); // Example call
  }

  @override
  Size getSize(FlSpot spot) {
    // Return the size of your dot
    return const Size(12, 12); // Example size, adjust as needed
  }

  @override
  List<Object?> get props => [yValue];
}

String formatWithCommas(double value) {
  final format = NumberFormat("#,##0", "en_US"); // Updated pattern
  return format.format(value);
}

String formatLargeNumber(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 1000000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatLargeNumber2(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 100 000, return it as a string with commas
  if (value < 100000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatLargeNumber3(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  if (value > 999) {
    return '${((newValue)).toStringAsFixed(1)}${suffixes[index]}';
  } else
    return value.toStringAsFixed(0);
}

String getMonthAbbreviation(int monthNumber) {
  List<String> months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];

  // Check if the month number is valid
  if (monthNumber < 1 || monthNumber > 12) {
    return "-";
  }

  // Return the corresponding month abbreviation
  return months[monthNumber - 1];
}

class LinePage extends StatefulWidget {
  const LinePage({Key? key}) : super(key: key);

  @override
  State<LinePage> createState() => _LinePageState();
}

class _LinePageState extends State<LinePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.only(
              right: 20.0,
            ),
            child: GestureDetector(
              onTap: () => setState(() {}),
              child: const Icon(
                Icons.refresh,
                size: 26.0,
              ),
            ),
          ),
        ],
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        title: const Text('Line'),
      ),
      backgroundColor: const Color(0xFF1B0E41),
      body: Center(
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 400.0,
            maxWidth: 600.0,
          ),
          padding: const EdgeInsets.all(24.0),
          child: Chart(
            layers: layers(),
            padding: const EdgeInsets.symmetric(horizontal: 30.0).copyWith(
              bottom: 12.0,
            ),
          ),
        ),
      ),
    );
  }

  List<ChartLayer> layers() {
    DateTime now = DateTime.now();
    final from = DateTime(now.year, now.month, 1);
    final to = DateTime.now();

    final frequency =
        (to.millisecondsSinceEpoch - from.millisecondsSinceEpoch) / 12;
    List<ChartLineDataItem> items = [];
    int index = 0;
    Constants.dailySalesCount_new.forEach((key, value) {
      print("dgjj $value");
      items.add(
        ChartLineDataItem(
          x: key.millisecondsSinceEpoch.toDouble(),
          value: value,
        ),
      );
      index++;
    });
    return [
      ChartHighlightLayer(
        shape: () => ChartHighlightLineShape<ChartLineDataItem>(
          backgroundColor: const Color(0xFF331B6D),
          currentPos: (item) => item.currentValuePos,
          radius: const BorderRadius.all(Radius.circular(8.0)),
          width: 60.0,
        ),
      ),
      ChartAxisLayer(
        settings: ChartAxisSettings(
          x: ChartAxisSettingsAxis(
            frequency: frequency,
            max: to.millisecondsSinceEpoch.toDouble(),
            min: from.millisecondsSinceEpoch.toDouble(),
            textStyle: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 10.0,
            ),
          ),
          y: ChartAxisSettingsAxis(
            frequency: Constants.sales_maxY.toDouble() / 5,
            max: 120,
            min: 0.0,
            textStyle: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 10.0,
            ),
          ),
        ),
        labelX: (value) => DateFormat('d')
            .format(DateTime.fromMillisecondsSinceEpoch(value.toInt())),

        /*labelX: (value) => DateFormat('MMM')
            .format(DateTime.fromMillisecondsSinceEpoch(value.toInt())),*/
        labelY: (value) => (value.toInt()).toString(),
      ),
      ChartLineLayer(
        items: items,
        settings: const ChartLineSettings(
          color: Color(0xFF8043F9),
          thickness: 4.0,
        ),
      ),
      ChartTooltipLayer(
        shape: () => ChartTooltipLineShape<ChartLineDataItem>(
          backgroundColor: Colors.white,
          circleBackgroundColor: Colors.white,
          circleBorderColor: const Color(0xFF331B6D),
          circleSize: 4.0,
          circleBorderThickness: 2.0,
          currentPos: (item) => item.currentValuePos,
          onTextValue: (item) => '${item.value.toInt().toString()}',
          marginBottom: 6.0,
          padding: const EdgeInsets.symmetric(
            horizontal: 12.0,
            vertical: 8.0,
          ),
          radius: 6.0,
          textStyle: const TextStyle(
            color: Color(0xFF8043F9),
            letterSpacing: 0.2,
            fontSize: 14.0,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    ];
  }
}

class SalesGraph1 extends StatefulWidget {
  const SalesGraph1({super.key});

  @override
  State<SalesGraph1> createState() => _SalesGraph1State();
}

class _SalesGraph1State extends State<SalesGraph1> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    getSalesGraphData(Constants.jsonMonthlySalesData2);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 250,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: sales_index == 0
                      ? LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    // Calculate the date from the day integer
                                    int daysAgo = value.toInt();
                                    DateTime thirtyDaysAgo = DateTime.now()
                                        .subtract(const Duration(days: 30));
                                    DateTime date = thirtyDaysAgo
                                        .add(Duration(days: daysAgo));

                                    // Format the date for display
                                    /*String formattedDate = DateFormat('MM/dd')
                                        .format(date); // Format as "MM/dd"*/

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        date.day
                                            .toString(), // Displaying the formatted date
                                        style: TextStyle(fontSize: 8),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Days of the month',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )
                      : sales_index == 1
                          ? LineChart(
                              key: sales_chartKey2b,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2b,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                minX: 1,
                                maxX: 12,
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            getMonthAbbreviation(value.toInt()),
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            )
                          : LineChart(
                              key: sales_chartKey2c,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2c,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            getMonthAbbreviation(value.toInt()),
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            ))),
        ));
  }

  Future<void> getSalesGraphData(jsonResponse) async {
    try {
      if (jsonResponse is! List) return;
      List<Map<String, dynamic>> sales =
          List<Map<String, dynamic>>.from(jsonResponse);

      DateTime now = DateTime.now();
      DateTime thirtyDaysAgo = now.subtract(const Duration(days: 30));

      Map<String, int> dailySalesCount = {}; // "YYYY-MM-DD": count

      for (var sale in sales) {
        DateTime saleDate = DateTime.parse(sale['sale_datetime']);
        if (saleDate.weekday == DateTime.saturday) {
          // print("date is a saturday ${sale['sale_datetime']}");
          saleDate = saleDate.add(Duration(days: 2)); // Move to Monday
        } else if (saleDate.weekday == DateTime.sunday) {
          if (kDebugMode) {
            //  print("date is a sunday ${sale['sale_datetime']}");
          }
          saleDate = saleDate.add(Duration(days: 1)); // Move to Monday
        }
        if (saleDate.isAfter(thirtyDaysAgo)) {
          String dateKey =
              "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}-${saleDate.day.toString().padLeft(2, '0')}";

          dailySalesCount.update(dateKey, (v) => v + 1, ifAbsent: () => 1);
        }
      }

      // Convert to spots
      List<FlSpot> salesSpots = [];
      dailySalesCount.forEach((key, count) {
        DateTime date = DateTime.parse(key);

        int daysAgo = thirtyDaysAgo.difference(date).inDays.abs();
        salesSpots.add(FlSpot(daysAgo.toDouble(), count.toDouble()));
        if (count > sales_maxY2) {
          sales_maxY2 = count;
        }
      });

      // Sort the spots in reverse order (so it starts 30 days ago)
      salesSpots.sort((a, b) => b.x.compareTo(a.x));

      // Ensure we have the last 30 days
      if (salesSpots.length > 30) {
        salesSpots = salesSpots.take(30).toList();
      }

      setState(() {
        sales_spots2a = salesSpots;
        // Update maxY accordingly
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph2 extends StatefulWidget {
  const SalesGraph2({super.key});

  @override
  State<SalesGraph2> createState() => _SalesGraph2State();
}

class _SalesGraph2State extends State<SalesGraph2> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    getSalesGraphData(Constants.jsonMonthlySalesData2);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 250,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: sales_index == 0
                      ? LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    int totalMonths = value.toInt();
                                    int year = totalMonths ~/ 12;
                                    int month = totalMonths % 12;
                                    month = month == 0 ? 12 : month;
                                    year = month == 12 ? year - 1 : year;
                                    String monthAbbreviation =
                                        getMonthAbbreviation(month);

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        "$monthAbbreviation", // Displaying both month and year
                                        style: TextStyle(fontSize: 10),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )
                      : sales_index == 1
                          ? LineChart(
                              key: sales_chartKey2a,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2a,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        int totalMonths = value.toInt();
                                        int year = totalMonths ~/ 12;
                                        int month = totalMonths % 12;
                                        month = month == 0 ? 12 : month;
                                        year = month == 12 ? year - 1 : year;
                                        String monthAbbreviation =
                                            getMonthAbbreviation(month);

                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            "$monthAbbreviation", // Displaying both month and year
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            )
                          : LineChart(
                              key: sales_chartKey2a,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2a,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        int totalMonths = value.toInt();
                                        int year = totalMonths ~/ 12;
                                        int month = totalMonths % 12;
                                        month = month == 0 ? 12 : month;
                                        year = month == 12 ? year - 1 : year;
                                        String monthAbbreviation =
                                            getMonthAbbreviation(month);

                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            "$monthAbbreviation", // Displaying both month and year
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            ))),
        ));
  }

  Future<void> getSalesGraphData(jsonResponse) async {
    try {
      if (jsonResponse is! List) return;
      List<Map<String, dynamic>> sales =
          List<Map<String, dynamic>>.from(jsonResponse);

      DateTime now = DateTime.now();
      DateTime twelveMonthsAgo =
          DateTime(now.year, now.month).subtract(const Duration(days: 365));

      Map<String, int> monthlySalesCount = {};

      for (var sale in sales) {
        DateTime saleDate = DateTime.parse(sale['sale_datetime']);
        if (saleDate.isAfter(twelveMonthsAgo)) {
          String yearMonth =
              "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}";
          monthlySalesCount.update(yearMonth, (v) => v + 1, ifAbsent: () => 1);
        }
      }

      // Convert to spots and sort
      List<FlSpot> salesSpots = monthlySalesCount.entries.map((e) {
        var parts = e.key.split('-');
        var year = int.parse(parts[0]);
        var month = int.parse(parts[1]);
        //print("evalue ${e.value}");
        if (e.value > sales_maxY2) {
          sales_maxY2 = e.value + 50;
        }
        return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
      }).toList();

      salesSpots.sort((a, b) => a.x.compareTo(b.x));
      if (salesSpots.length > 12) {
        salesSpots = salesSpots.sublist(salesSpots.length - 12);
      }
      setState(() {
        sales_spots2a = salesSpots;
        print(sales_spots2a);
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph2b extends StatefulWidget {
  const SalesGraph2b({super.key});

  @override
  State<SalesGraph2b> createState() => _SalesGraph2bState();
}

class _SalesGraph2bState extends State<SalesGraph2b> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    getSalesGraphData(Constants.jsonMonthlySalesData2);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 250,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: sales_index == 0
                      ? LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    int totalMonths = value.toInt();
                                    int year = totalMonths ~/ 12;
                                    int month = totalMonths % 12;
                                    month = month == 0 ? 12 : month;
                                    year = month == 12 ? year - 1 : year;
                                    String monthAbbreviation =
                                        getMonthAbbreviation(month);

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        "$monthAbbreviation", // Displaying both month and year
                                        style: TextStyle(fontSize: 10),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )
                      : sales_index == 1
                          ? LineChart(
                              key: sales_chartKey2a,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2a,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        int totalMonths = value.toInt();
                                        int year = totalMonths ~/ 12;
                                        int month = totalMonths % 12;
                                        month = month == 0 ? 12 : month;
                                        year = month == 12 ? year - 1 : year;
                                        String monthAbbreviation =
                                            getMonthAbbreviation(month);

                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            "$monthAbbreviation", // Displaying both month and year
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            )
                          : LineChart(
                              key: sales_chartKey2a,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2a,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        int totalMonths = value.toInt();
                                        int year = totalMonths ~/ 12;
                                        int month = totalMonths % 12;
                                        month = month == 0 ? 12 : month;
                                        year = month == 12 ? year - 1 : year;
                                        String monthAbbreviation =
                                            getMonthAbbreviation(month);

                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            "$monthAbbreviation", // Displaying both month and year
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            ))),
        ));
  }

  Future<void> getSalesGraphData(jsonResponse) async {
    try {
      if (jsonResponse is! List) return;
      List<Map<String, dynamic>> sales =
          List<Map<String, dynamic>>.from(jsonResponse);

      DateTime now = DateTime.now();
      DateTime twelveMonthsAgo =
          DateTime(now.year, now.month).subtract(const Duration(days: 365));

      Map<String, int> monthlySalesCount = {};

      for (var sale in sales) {
        if (sale["status"] == "Inforced") {
          DateTime saleDate = DateTime.parse(sale['sale_datetime']);
          if (saleDate.isAfter(twelveMonthsAgo)) {
            String yearMonth =
                "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}";
            monthlySalesCount.update(yearMonth, (v) => v + 1,
                ifAbsent: () => 1);
          }
        }
      }

      // Convert to spots and sort
      List<FlSpot> salesSpots = monthlySalesCount.entries.map((e) {
        var parts = e.key.split('-');
        var year = int.parse(parts[0]);
        var month = int.parse(parts[1]);
        //print("evalue ${e.value}");
        if (e.value > sales_maxY2) {
          sales_maxY2 = e.value + 50;
        }
        return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
      }).toList();

      salesSpots.sort((a, b) => a.x.compareTo(b.x));
      if (salesSpots.length > 12) {
        salesSpots = salesSpots.sublist(salesSpots.length - 12);
      }
      setState(() {
        sales_spots2a = salesSpots;
        print(sales_spots2a);
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph2c extends StatefulWidget {
  const SalesGraph2c({super.key});

  @override
  State<SalesGraph2c> createState() => _SalesGraph2cState();
}

class _SalesGraph2cState extends State<SalesGraph2c> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    getSalesGraphData(Constants.jsonMonthlySalesData2);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 250,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: sales_index == 0
                      ? LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    int totalMonths = value.toInt();
                                    int year = totalMonths ~/ 12;
                                    int month = totalMonths % 12;
                                    month = month == 0 ? 12 : month;
                                    year = month == 12 ? year - 1 : year;
                                    String monthAbbreviation =
                                        getMonthAbbreviation(month);

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        "$monthAbbreviation", // Displaying both month and year
                                        style: TextStyle(fontSize: 10),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )
                      : sales_index == 1
                          ? LineChart(
                              key: sales_chartKey2a,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2a,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        int totalMonths = value.toInt();
                                        int year = totalMonths ~/ 12;
                                        int month = totalMonths % 12;
                                        month = month == 0 ? 12 : month;
                                        year = month == 12 ? year - 1 : year;
                                        String monthAbbreviation =
                                            getMonthAbbreviation(month);

                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            "$monthAbbreviation", // Displaying both month and year
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            )
                          : LineChart(
                              key: sales_chartKey2a,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2a,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        int totalMonths = value.toInt();
                                        int year = totalMonths ~/ 12;
                                        int month = totalMonths % 12;
                                        month = month == 0 ? 12 : month;
                                        year = month == 12 ? year - 1 : year;
                                        String monthAbbreviation =
                                            getMonthAbbreviation(month);

                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            "$monthAbbreviation", // Displaying both month and year
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            ))),
        ));
  }

  Future<void> getSalesGraphData(jsonResponse) async {
    try {
      if (jsonResponse is! List) return;
      List<Map<String, dynamic>> sales =
          List<Map<String, dynamic>>.from(jsonResponse);

      DateTime now = DateTime.now();
      DateTime twelveMonthsAgo =
          DateTime(now.year, now.month).subtract(const Duration(days: 365));

      Map<String, int> monthlySalesCount = {};

      for (var sale in sales) {
        if (sale["status"] != "Inforced") {
          DateTime saleDate = DateTime.parse(sale['sale_datetime']);
          if (saleDate.isAfter(twelveMonthsAgo)) {
            String yearMonth =
                "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}";
            monthlySalesCount.update(yearMonth, (v) => v + 1,
                ifAbsent: () => 1);
          }
        }
      }

      // Convert to spots and sort
      List<FlSpot> salesSpots = monthlySalesCount.entries.map((e) {
        var parts = e.key.split('-');
        var year = int.parse(parts[0]);
        var month = int.parse(parts[1]);
        //print("evalue ${e.value}");
        if (e.value > sales_maxY2) {
          sales_maxY2 = e.value + 50;
        }
        return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
      }).toList();

      salesSpots.sort((a, b) => a.x.compareTo(b.x));
      if (salesSpots.length > 12) {
        salesSpots = salesSpots.sublist(salesSpots.length - 12);
      }
      setState(() {
        sales_spots2a = salesSpots;
        print(sales_spots2a);
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph3a extends StatefulWidget {
  const SalesGraph3a({super.key});

  @override
  State<SalesGraph3a> createState() => _SalesGraph3aState();
}

class _SalesGraph3aState extends State<SalesGraph3a> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  int days_difference3a = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    DateTime startDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedStartDate);
    DateTime endDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedEndDate);

    days_difference3a = endDateTime.difference(startDateTime).inDays;
    getSalesGraphData();
    Constants.sales_chartKey3a = UniqueKey();
    myNotifier = MyNotifier(salesValue, context);
    salesValue.addListener(() {
      kyrt = UniqueKey();
      setState(() {});
      Future.delayed(Duration(seconds: 1)).then((value) {
        print("ghjg");
        setState(() {});
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return sales_spots2a.isEmpty
        ? Container(
            height: 250,
            child: Center(
                child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Constants.ctaColorLight,
                    strokeWidth: 1.8,
                  ),
                ),
              ),
            )),
          )
        : Container(
            height: 250,
            child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                        padding: const EdgeInsets.all(14.0),
                        child: LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    // Calculate the date from the day integer
                                    int daysAgo = value.toInt();
                                    DateTime thirtyDaysAgo = DateTime.now()
                                        .subtract(const Duration(days: 30));
                                    DateTime date = thirtyDaysAgo
                                        .add(Duration(days: daysAgo));

                                    // Format the date for display
                                    /*String formattedDate = DateFormat('MM/dd')
                                        .format(date); // Format as "MM/dd"*/

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        date.day
                                            .toString(), // Displaying the formatted date
                                        style: TextStyle(fontSize: 8),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )))));
  }

  Future<void> getSalesGraphData() async {
    try {
      String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

      Map<String, String>? payload = {
        "client_id": "${Constants.cec_client_id}",
        "start_date": Constants.sales_formattedStartDate,
        "end_date": Constants.sales_formattedEndDate
      };
      await http.post(
          Uri.parse(
            baseUrl,
          ),
          body: payload,
          headers: {
            "Cookie":
                "userid=expiry=2021-04-25&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=&empid=3&empfirstname=Mncedisi&emplastname=Khumalo&email=mncedisi@athandwe.co.za&username=mncedisi@athandwe.co.za&dob=8/28/1985 12:00:00 AM&fullname=Mncedisi Khumalo&userRole=5&userImage=mncedisi@athandwe.co.za.jpg&employedAt=branch&role=leader&branchid=6&branchname=Boulders&jobtitle=Administrative Assistant&dialing_strategy=Campaign Manager&clientname=Test 1 Funeral Parlour&foldername=maafrica&client_abbr=AS&pbx_account=pbx1051ef0a&soft_phone_ip=&agent_type=branch&mip_username=mnces@mip.co.za&agent_email=Mr Mncedisi Khumalo&ViciDial_phone_login=&ViciDial_phone_password=&ViciDial_agent_user=99&ViciDial_agent_password=&device_id=dC7JwXFwwdI:APA91bF0gTbuXlfT6wIcGMLY57Xo7VxUMrMH-MuFYL5PnjUVI0G5X1d3d90FNRb8-XmcjI40L1XqDH-KAc1KWnPpxNg8Z8SK4Ty0xonbz4L3sbKz3Rlr4hyBqePWx9ZfEp53vWwkZ3tx&servername=http://localhost:55661"
          }).then((value) {
        http.Response response = value;
        var jsonResponse = jsonDecode(response.body)["sales"];
        if (jsonResponse is! List) return;
        List<Map<String, dynamic>> sales =
            List<Map<String, dynamic>>.from(jsonResponse);

        DateTime now = DateTime.now();
        DateTime thirtyDaysAgo = now.subtract(const Duration(days: 30));

        Map<String, int> dailySalesCount = {}; // "YYYY-MM-DD": count

        for (var sale in sales) {
          DateTime saleDate = DateTime.parse(sale['sale_datetime']);
          if (saleDate.weekday == DateTime.saturday) {
            // print("date is a saturday ${sale['sale_datetime']}");
            saleDate = saleDate.add(Duration(days: 2)); // Move to Monday
          } else if (saleDate.weekday == DateTime.sunday) {
            if (kDebugMode) {
              //  print("date is a sunday ${sale['sale_datetime']}");
            }
            saleDate = saleDate.add(Duration(days: 1)); // Move to Monday
          }

          String dateKey =
              "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}-${saleDate.day.toString().padLeft(2, '0')}";

          dailySalesCount.update(dateKey, (v) => v + 1, ifAbsent: () => 1);
        }

        // Convert to spots
        List<FlSpot> salesSpots = [];
        dailySalesCount.forEach((key, count) {
          DateTime date = DateTime.parse(key);

          int daysAgo = thirtyDaysAgo.difference(date).inDays.abs();
          salesSpots.add(FlSpot(daysAgo.toDouble(), count.toDouble()));
          if (count > sales_maxY2) {
            sales_maxY2 = count;
          }
        });

        // Sort the spots in reverse order (so it starts 30 days ago)
        salesSpots.sort((a, b) => b.x.compareTo(a.x));

        // Ensure we have the last 30 days
        if (salesSpots.length > 30) {
          salesSpots = salesSpots.take(30).toList();
        }

        setState(() {
          sales_spots2a = salesSpots;
          // Update maxY accordingly
        });
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph3b extends StatefulWidget {
  const SalesGraph3b({super.key});

  @override
  State<SalesGraph3b> createState() => _SalesGraph3bState();
}

class _SalesGraph3bState extends State<SalesGraph3b> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  int days_difference3a = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    DateTime startDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedStartDate);
    DateTime endDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedEndDate);

    days_difference3a = endDateTime.difference(startDateTime).inDays;
    getSalesGraphData();
    Constants.sales_chartKey3b = UniqueKey();
    myNotifier = MyNotifier(salesValue, context);
    salesValue.addListener(() {
      kyrt = UniqueKey();
      setState(() {});
      Future.delayed(Duration(seconds: 1)).then((value) {
        if (kDebugMode) {
          print("ghjg3v");
        }
        setState(() {});
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return sales_spots2a.isEmpty
        ? Container(
            height: 250,
            child: Center(
                child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Constants.ctaColorLight,
                    strokeWidth: 1.8,
                  ),
                ),
              ),
            )),
          )
        : Container(
            height: 250,
            child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                        padding: const EdgeInsets.all(14.0),
                        child: LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    // Calculate the date from the day integer
                                    int daysAgo = value.toInt();
                                    DateTime thirtyDaysAgo = DateTime.now()
                                        .subtract(const Duration(days: 30));
                                    DateTime date = thirtyDaysAgo
                                        .add(Duration(days: daysAgo));

                                    // Format the date for display
                                    /*String formattedDate = DateFormat('MM/dd')
                                        .format(date); // Format as "MM/dd"*/

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        date.day
                                            .toString(), // Displaying the formatted date
                                        style: TextStyle(fontSize: 8),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )))));
  }

  Future<void> getSalesGraphData() async {
    try {
      String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

      Map<String, String>? payload = {
        "client_id": "${Constants.cec_client_id}",
        "start_date": Constants.sales_formattedStartDate,
        "end_date": Constants.sales_formattedEndDate
      };
      await http.post(
          Uri.parse(
            baseUrl,
          ),
          body: payload,
          headers: {
            "Cookie":
                "userid=expiry=2021-04-25&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=&empid=3&empfirstname=Mncedisi&emplastname=Khumalo&email=mncedisi@athandwe.co.za&username=mncedisi@athandwe.co.za&dob=8/28/1985 12:00:00 AM&fullname=Mncedisi Khumalo&userRole=5&userImage=mncedisi@athandwe.co.za.jpg&employedAt=branch&role=leader&branchid=6&branchname=Boulders&jobtitle=Administrative Assistant&dialing_strategy=Campaign Manager&clientname=Test 1 Funeral Parlour&foldername=maafrica&client_abbr=AS&pbx_account=pbx1051ef0a&soft_phone_ip=&agent_type=branch&mip_username=mnces@mip.co.za&agent_email=Mr Mncedisi Khumalo&ViciDial_phone_login=&ViciDial_phone_password=&ViciDial_agent_user=99&ViciDial_agent_password=&device_id=dC7JwXFwwdI:APA91bF0gTbuXlfT6wIcGMLY57Xo7VxUMrMH-MuFYL5PnjUVI0G5X1d3d90FNRb8-XmcjI40L1XqDH-KAc1KWnPpxNg8Z8SK4Ty0xonbz4L3sbKz3Rlr4hyBqePWx9ZfEp53vWwkZ3tx&servername=http://localhost:55661"
          }).then((value) {
        http.Response response = value;
        var jsonResponse = jsonDecode(response.body)["sales"];
        if (jsonResponse is! List) return;
        List<Map<String, dynamic>> sales =
            List<Map<String, dynamic>>.from(jsonResponse);

        DateTime now = DateTime.now();
        DateTime thirtyDaysAgo = now.subtract(const Duration(days: 30));

        Map<String, int> dailySalesCount = {}; // "YYYY-MM-DD": count

        for (var sale in sales) {
          if (sale["status"] == "Inforced") {
            DateTime saleDate = DateTime.parse(sale['sale_datetime']);
            if (saleDate.weekday == DateTime.saturday) {
              // print("date is a saturday ${sale['sale_datetime']}");
              saleDate = saleDate.add(Duration(days: 2)); // Move to Monday
            } else if (saleDate.weekday == DateTime.sunday) {
              if (kDebugMode) {
                //  print("date is a sunday ${sale['sale_datetime']}");
              }
              saleDate = saleDate.add(Duration(days: 1)); // Move to Monday
            }
            if (saleDate.isAfter(thirtyDaysAgo)) {
              String dateKey =
                  "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}-${saleDate.day.toString().padLeft(2, '0')}";

              dailySalesCount.update(dateKey, (v) => v + 1, ifAbsent: () => 1);
            }
          }
        }

        // Convert to spots
        List<FlSpot> salesSpots = [];
        dailySalesCount.forEach((key, count) {
          DateTime date = DateTime.parse(key);

          int daysAgo = thirtyDaysAgo.difference(date).inDays.abs();
          salesSpots.add(FlSpot(daysAgo.toDouble(), count.toDouble()));
          if (count > sales_maxY2) {
            sales_maxY2 = count;
          }
        });

        // Sort the spots in reverse order (so it starts 30 days ago)
        salesSpots.sort((a, b) => b.x.compareTo(a.x));

        // Ensure we have the last 30 days
        if (salesSpots.length > 30) {
          salesSpots = salesSpots.take(30).toList();
        }

        setState(() {
          sales_spots2a = salesSpots;
          // Update maxY accordingly
        });
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph3c extends StatefulWidget {
  const SalesGraph3c({super.key});

  @override
  State<SalesGraph3c> createState() => _SalesGraph3cState();
}

class _SalesGraph3cState extends State<SalesGraph3c> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  int days_difference3a = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    DateTime startDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedStartDate);
    DateTime endDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.sales_formattedEndDate);

    days_difference3a = endDateTime.difference(startDateTime).inDays;
    getSalesGraphData();
    Constants.sales_chartKey3c = UniqueKey();
    myNotifier = MyNotifier(salesValue, context);
    salesValue.addListener(() {
      kyrt = UniqueKey();
      setState(() {});
      Future.delayed(Duration(seconds: 1)).then((value) {
        print("ghjg");
        setState(() {});
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return sales_spots2a.isEmpty
        ? Container(
            height: 250,
            child: Center(
                child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Constants.ctaColorLight,
                    strokeWidth: 1.8,
                  ),
                ),
              ),
            )),
          )
        : Container(
            height: 250,
            child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                        padding: const EdgeInsets.all(14.0),
                        child: LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    // Calculate the date from the day integer
                                    int daysAgo = value.toInt();
                                    DateTime thirtyDaysAgo = DateTime.now()
                                        .subtract(const Duration());
                                    DateTime date = thirtyDaysAgo
                                        .add(Duration(days: daysAgo));

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        date.day
                                            .toString(), // Displaying the formatted date
                                        style: TextStyle(fontSize: 8),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )))));
  }

  Future<void> getSalesGraphData() async {
    try {
      String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

      Map<String, String>? payload = {
        "client_id": "${Constants.cec_client_id}",
        "start_date": Constants.sales_formattedStartDate,
        "end_date": Constants.sales_formattedEndDate
      };
      await http.post(
          Uri.parse(
            baseUrl,
          ),
          body: payload,
          headers: {
            "Cookie":
                "userid=expiry=2021-04-25&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=&empid=3&empfirstname=Mncedisi&emplastname=Khumalo&email=mncedisi@athandwe.co.za&username=mncedisi@athandwe.co.za&dob=8/28/1985 12:00:00 AM&fullname=Mncedisi Khumalo&userRole=5&userImage=mncedisi@athandwe.co.za.jpg&employedAt=branch&role=leader&branchid=6&branchname=Boulders&jobtitle=Administrative Assistant&dialing_strategy=Campaign Manager&clientname=Test 1 Funeral Parlour&foldername=maafrica&client_abbr=AS&pbx_account=pbx1051ef0a&soft_phone_ip=&agent_type=branch&mip_username=mnces@mip.co.za&agent_email=Mr Mncedisi Khumalo&ViciDial_phone_login=&ViciDial_phone_password=&ViciDial_agent_user=99&ViciDial_agent_password=&device_id=dC7JwXFwwdI:APA91bF0gTbuXlfT6wIcGMLY57Xo7VxUMrMH-MuFYL5PnjUVI0G5X1d3d90FNRb8-XmcjI40L1XqDH-KAc1KWnPpxNg8Z8SK4Ty0xonbz4L3sbKz3Rlr4hyBqePWx9ZfEp53vWwkZ3tx&servername=http://localhost:55661"
          }).then((value) {
        http.Response response = value;
        var jsonResponse = jsonDecode(response.body)["sales"];
        if (jsonResponse is! List) return;
        List<Map<String, dynamic>> sales =
            List<Map<String, dynamic>>.from(jsonResponse);

        DateTime now = DateTime.now();
        DateTime thirtyDaysAgo = now.subtract(const Duration(days: 30));

        Map<String, int> dailySalesCount = {}; // "YYYY-MM-DD": count

        for (var sale in sales) {
          if (sale["status"] != "Inforced") {
            DateTime saleDate = DateTime.parse(sale['sale_datetime']);
            if (saleDate.weekday == DateTime.saturday) {
              // print("date is a saturday ${sale['sale_datetime']}");
              saleDate = saleDate.add(Duration(days: 2)); // Move to Monday
            } else if (saleDate.weekday == DateTime.sunday) {
              if (kDebugMode) {
                //  print("date is a sunday ${sale['sale_datetime']}");
              }
              saleDate = saleDate.add(Duration(days: 1)); // Move to Monday
            }
            if (saleDate.isAfter(thirtyDaysAgo)) {
              String dateKey =
                  "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}-${saleDate.day.toString().padLeft(2, '0')}";

              dailySalesCount.update(dateKey, (v) => v + 1, ifAbsent: () => 1);
            }
          }
        }

        // Convert to spots
        List<FlSpot> salesSpots = [];
        dailySalesCount.forEach((key, count) {
          DateTime date = DateTime.parse(key);

          int daysAgo = thirtyDaysAgo.difference(date).inDays.abs();
          salesSpots.add(FlSpot(daysAgo.toDouble(), count.toDouble()));
          if (count > sales_maxY2) {
            sales_maxY2 = count;
          }
        });

        // Sort the spots in reverse order (so it starts 30 days ago)
        salesSpots.sort((a, b) => b.x.compareTo(a.x));

        // Ensure we have the last 30 days
        if (salesSpots.length > 30) {
          salesSpots = salesSpots.take(30).toList();
        }

        setState(() {
          sales_spots2a = salesSpots;
          // Update maxY accordingly
        });
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph4a extends StatefulWidget {
  const SalesGraph4a({super.key});

  @override
  State<SalesGraph4a> createState() => _SalesGraph4aState();
}

class _SalesGraph4aState extends State<SalesGraph4a> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    getSalesGraphData();
    Constants.sales_chartKey4a = UniqueKey();
    myNotifier = MyNotifier(salesValue, context);
    salesValue.addListener(() {
      kyrt = UniqueKey();
      setState(() {});
      Future.delayed(Duration(seconds: 1)).then((value) {
        print("ghjg");
        setState(() {});
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return sales_spots2a.isEmpty
        ? Container(
            height: 250,
            child: Center(
                child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Constants.ctaColorLight,
                    strokeWidth: 1.8,
                  ),
                ),
              ),
            )),
          )
        : Container(
            height: 250,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                      padding: const EdgeInsets.all(14.0),
                      child: sales_index == 0
                          ? LineChart(
                              key: sales_chartKey2a,
                              LineChartData(
                                lineTouchData: LineTouchData(
                                    enabled: true,
                                    touchCallback: (FlTouchEvent event,
                                        LineTouchResponse? touchResponse) {
                                      // TODO : Utilize touch event here to perform any operation
                                    },
                                    touchTooltipData: LineTouchTooltipData(
                                      tooltipBgColor: Colors.blueGrey,
                                      tooltipRoundedRadius: 20.0,
                                      showOnTopOfTheChartBoxArea: false,
                                      fitInsideHorizontally: true,
                                      tooltipMargin: 0,
                                      getTooltipItems: (touchedSpots) {
                                        return touchedSpots.map(
                                          (LineBarSpot touchedSpot) {
                                            const textStyle = TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white70,
                                            );
                                            return LineTooltipItem(
                                              touchedSpot.y.round().toString(),
                                              textStyle,
                                            );
                                          },
                                        ).toList();
                                      },
                                    ),
                                    getTouchedSpotIndicator:
                                        (LineChartBarData barData,
                                            List<int> indicators) {
                                      return indicators.map(
                                        (int index) {
                                          final line = FlLine(
                                              color: Colors.grey,
                                              strokeWidth: 1,
                                              dashArray: [2, 4]);
                                          return TouchedSpotIndicatorData(
                                            line,
                                            FlDotData(show: false),
                                          );
                                        },
                                      ).toList();
                                    },
                                    getTouchLineEnd: (_, __) =>
                                        double.infinity),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2a,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        int totalMonths = value.toInt();
                                        int year = totalMonths ~/ 12;
                                        int month = totalMonths % 12;
                                        month = month == 0 ? 12 : month;
                                        year = month == 12 ? year - 1 : year;
                                        String monthAbbreviation =
                                            getMonthAbbreviation(month);

                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            "$monthAbbreviation", // Displaying both month and year
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            )
                          : sales_index == 1
                              ? LineChart(
                                  key: sales_chartKey2b,
                                  LineChartData(
                                    lineTouchData: LineTouchData(
                                        enabled: true,
                                        touchCallback: (FlTouchEvent event,
                                            LineTouchResponse? touchResponse) {
                                          // TODO : Utilize touch event here to perform any operation
                                        },
                                        touchTooltipData: LineTouchTooltipData(
                                          tooltipBgColor: Colors.blueGrey,
                                          tooltipRoundedRadius: 20.0,
                                          showOnTopOfTheChartBoxArea: false,
                                          fitInsideHorizontally: true,
                                          tooltipMargin: 0,
                                          getTooltipItems: (touchedSpots) {
                                            return touchedSpots.map(
                                              (LineBarSpot touchedSpot) {
                                                const textStyle = TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.w700,
                                                  color: Colors.white70,
                                                );
                                                return LineTooltipItem(
                                                  touchedSpot.y
                                                      .round()
                                                      .toString(),
                                                  textStyle,
                                                );
                                              },
                                            ).toList();
                                          },
                                        ),
                                        getTouchedSpotIndicator:
                                            (LineChartBarData barData,
                                                List<int> indicators) {
                                          return indicators.map(
                                            (int index) {
                                              final line = FlLine(
                                                  color: Colors.grey,
                                                  strokeWidth: 1,
                                                  dashArray: [2, 4]);
                                              return TouchedSpotIndicatorData(
                                                line,
                                                FlDotData(show: false),
                                              );
                                            },
                                          ).toList();
                                        },
                                        getTouchLineEnd: (_, __) =>
                                            double.infinity),
                                    lineBarsData: [
                                      LineChartBarData(
                                        spots: sales_spots2b,
                                        isCurved: true,
                                        barWidth: 3,
                                        color: Colors.grey.shade400,
                                        dotData: FlDotData(
                                          show: true,
                                          getDotPainter:
                                              (spot, percent, barData, index) {
                                            // Show custom dot and text for specific x-values

                                            return FlDotCirclePainter(
                                                radius: 2,
                                                color: Colors.red,
                                                strokeColor: Colors.green);
                                            /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                          },
                                        ),
                                      ),
                                    ],
                                    gridData: FlGridData(
                                      show: true,
                                      drawVerticalLine: false,
                                      getDrawingHorizontalLine: (value) {
                                        return FlLine(
                                          color: Colors.grey.withOpacity(0.10),
                                          strokeWidth: 1,
                                        );
                                      },
                                      getDrawingVerticalLine: (value) {
                                        return FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                        );
                                      },
                                    ),
                                    titlesData: FlTitlesData(
                                      bottomTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          interval: 1,
                                          getTitlesWidget: (value, meta) {
                                            int totalMonths = value.toInt();
                                            int year = totalMonths ~/ 12;
                                            int month = totalMonths % 12;
                                            month = month == 0 ? 12 : month;
                                            year =
                                                month == 12 ? year - 1 : year;
                                            String monthAbbreviation =
                                                getMonthAbbreviation(month);

                                            return Padding(
                                              padding:
                                                  const EdgeInsets.all(2.0),
                                              child: Text(
                                                "$monthAbbreviation", // Displaying both month and year
                                                style: TextStyle(fontSize: 10),
                                              ),
                                            );
                                          },
                                        ),
                                        axisNameWidget: Padding(
                                          padding:
                                              const EdgeInsets.only(top: 0.0),
                                          child: Text(
                                            'Months of the Year',
                                            style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.black),
                                          ),
                                        ),
                                      ),
                                      topTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: false,
                                          getTitlesWidget: (value, meta) {
                                            return Text(
                                                value.toInt().toString());
                                          },
                                        ),
                                      ),
                                      rightTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: false,
                                          getTitlesWidget: (value, meta) {
                                            return Text(
                                                value.toInt().toString());
                                          },
                                        ),
                                      ),
                                      leftTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          reservedSize: 20,
                                          getTitlesWidget: (value, meta) {
                                            return Text(
                                              formatLargeNumber3(
                                                  value.toInt().toString()),
                                              style: TextStyle(fontSize: 8),
                                            );
                                          },
                                        ),
                                        /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                      ),
                                    ),
                                    minY: 0,
                                    maxY: sales_maxY2.toDouble(),
                                    borderData: FlBorderData(
                                      show: true,
                                      border: Border(
                                        left: BorderSide.none,
                                        bottom: BorderSide(
                                          color: Colors.grey.withOpacity(0.35),
                                          width: 1,
                                        ),
                                        right: BorderSide.none,
                                        top: BorderSide.none,
                                      ),
                                    ),
                                  ),
                                )
                              : LineChart(
                                  key: sales_chartKey2c,
                                  LineChartData(
                                    lineTouchData: LineTouchData(
                                        enabled: true,
                                        touchCallback: (FlTouchEvent event,
                                            LineTouchResponse? touchResponse) {
                                          // TODO : Utilize touch event here to perform any operation
                                        },
                                        touchTooltipData: LineTouchTooltipData(
                                          tooltipBgColor: Colors.blueGrey,
                                          tooltipRoundedRadius: 20.0,
                                          showOnTopOfTheChartBoxArea: false,
                                          fitInsideHorizontally: true,
                                          tooltipMargin: 0,
                                          getTooltipItems: (touchedSpots) {
                                            return touchedSpots.map(
                                              (LineBarSpot touchedSpot) {
                                                const textStyle = TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.w700,
                                                  color: Colors.white70,
                                                );
                                                return LineTooltipItem(
                                                  touchedSpot.y
                                                      .round()
                                                      .toString(),
                                                  textStyle,
                                                );
                                              },
                                            ).toList();
                                          },
                                        ),
                                        getTouchedSpotIndicator:
                                            (LineChartBarData barData,
                                                List<int> indicators) {
                                          return indicators.map(
                                            (int index) {
                                              final line = FlLine(
                                                  color: Colors.grey,
                                                  strokeWidth: 1,
                                                  dashArray: [2, 4]);
                                              return TouchedSpotIndicatorData(
                                                line,
                                                FlDotData(show: false),
                                              );
                                            },
                                          ).toList();
                                        },
                                        getTouchLineEnd: (_, __) =>
                                            double.infinity),
                                    lineBarsData: [
                                      LineChartBarData(
                                        spots: sales_spots2c,
                                        isCurved: true,
                                        barWidth: 3,
                                        color: Colors.grey.shade400,
                                        dotData: FlDotData(
                                          show: true,
                                          getDotPainter:
                                              (spot, percent, barData, index) {
                                            // Show custom dot and text for specific x-values

                                            return FlDotCirclePainter(
                                                radius: 2,
                                                color: Colors.red,
                                                strokeColor: Colors.green);
                                          },
                                        ),
                                      ),
                                    ],
                                    gridData: FlGridData(
                                      show: true,
                                      drawVerticalLine: false,
                                      getDrawingHorizontalLine: (value) {
                                        return FlLine(
                                          color: Colors.grey.withOpacity(0.10),
                                          strokeWidth: 1,
                                        );
                                      },
                                      getDrawingVerticalLine: (value) {
                                        return FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                        );
                                      },
                                    ),
                                    titlesData: FlTitlesData(
                                      bottomTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          interval: 1,
                                          getTitlesWidget: (value, meta) {
                                            int totalMonths = value.toInt();
                                            int year = totalMonths ~/ 12;
                                            int month = totalMonths % 12;
                                            month = month == 0 ? 12 : month;
                                            year =
                                                month == 12 ? year - 1 : year;
                                            String monthAbbreviation =
                                                getMonthAbbreviation(month);

                                            return Padding(
                                              padding:
                                                  const EdgeInsets.all(2.0),
                                              child: Text(
                                                "$monthAbbreviation", // Displaying both month and year
                                                style: TextStyle(fontSize: 10),
                                              ),
                                            );
                                          },
                                        ),
                                        axisNameWidget: Padding(
                                          padding:
                                              const EdgeInsets.only(top: 0.0),
                                          child: Text(
                                            'Months of the Year',
                                            style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.black),
                                          ),
                                        ),
                                      ),
                                      topTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: false,
                                          getTitlesWidget: (value, meta) {
                                            return Text(
                                                value.toInt().toString());
                                          },
                                        ),
                                      ),
                                      rightTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: false,
                                          getTitlesWidget: (value, meta) {
                                            return Text(
                                                value.toInt().toString());
                                          },
                                        ),
                                      ),
                                      leftTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          reservedSize: 20,
                                          getTitlesWidget: (value, meta) {
                                            return Text(
                                              formatLargeNumber3(
                                                  value.toInt().toString()),
                                              style: TextStyle(fontSize: 8),
                                            );
                                          },
                                        ),
                                        /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                      ),
                                    ),
                                    minY: 0,
                                    maxY: sales_maxY2.toDouble(),
                                    borderData: FlBorderData(
                                      show: true,
                                      border: Border(
                                        left: BorderSide.none,
                                        bottom: BorderSide(
                                          color: Colors.grey.withOpacity(0.35),
                                          width: 1,
                                        ),
                                        right: BorderSide.none,
                                        top: BorderSide.none,
                                      ),
                                    ),
                                  ),
                                ))),
            ));
  }

  Future<void> getSalesGraphData() async {
    try {
      String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

      Map<String, String>? payload = {
        "client_id": "${Constants.cec_client_id}",
        "start_date": Constants.sales_formattedStartDate,
        "end_date": Constants.sales_formattedEndDate
      };
      await http
          .post(
        Uri.parse(
          baseUrl,
        ),
        body: payload,
      )
          .then((value) {
        http.Response response = value;
        var jsonResponse = jsonDecode(response.body)["sales"];
        List<Map<String, dynamic>> sales =
            List<Map<String, dynamic>>.from(jsonResponse);

        DateTime now = DateTime.now();
        DateTime twelveMonthsAgo =
            DateTime(now.year, now.month).subtract(const Duration(days: 365));

        Map<String, int> monthlySalesCount2a = {};
        Map<String, int> monthlySalesCount2b = {};
        Map<String, int> monthlySalesCount2c = {};

        for (var sale in sales) {
          DateTime saleDate = DateTime.parse(sale['sale_datetime']);
          String yearMonth =
              "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}";
          monthlySalesCount2a.update(yearMonth, (v) => v + 1,
              ifAbsent: () => 1);
          if (sale["status"] == "Inforced")
            monthlySalesCount2b.update(yearMonth, (v) => v + 1,
                ifAbsent: () => 1);
          if (sale["status"] != "Inforced")
            monthlySalesCount2c.update(yearMonth, (v) => v + 1,
                ifAbsent: () => 1);
        }
        print(monthlySalesCount2a);
        print(monthlySalesCount2b);
        print(monthlySalesCount2c);

        // Convert to spots and sort
        List<FlSpot> salesSpots = monthlySalesCount2a.entries.map((e) {
          print("fgffgf1 $e");
          var parts = e.key.split('-');
          var year = int.parse(parts[0]);
          var month = int.parse(parts[1]);
          //print("evalue ${e.value}");
          if (e.value > sales_maxY2) {
            sales_maxY2 = e.value + 50;
          }
          return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
        }).toList();
        List<FlSpot> salesSpots2b = monthlySalesCount2b.entries.map((e) {
          print("fgffgf1 $e");
          var parts = e.key.split('-');
          var year = int.parse(parts[0]);
          var month = int.parse(parts[1]);
          //print("evalue ${e.value}");
          if (e.value > sales_maxY2) {
            sales_maxY2 = e.value + 50;
          }
          return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
        }).toList();
        List<FlSpot> salesSpots2c = monthlySalesCount2c.entries.map((e) {
          print("fgffgf1 $e");
          var parts = e.key.split('-');
          var year = int.parse(parts[0]);
          var month = int.parse(parts[1]);
          //print("evalue ${e.value}");
          if (e.value > sales_maxY2) {
            sales_maxY2 = e.value + 50;
          }
          return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
        }).toList();

        salesSpots.sort((a, b) => a.x.compareTo(b.x));
        salesSpots2b.sort((a, b) => a.x.compareTo(b.x));
        salesSpots2c.sort((a, b) => a.x.compareTo(b.x));
        if (salesSpots.length > 12) {
          salesSpots = salesSpots.sublist(salesSpots.length - 12);
          salesSpots2b = salesSpots2b.sublist(salesSpots.length - 12);
          salesSpots2c = salesSpots2c.sublist(salesSpots.length - 12);
        }
        setState(() {
          sales_spots2a = salesSpots;
          sales_spots2b = salesSpots2b;
          sales_spots2c = salesSpots2c;
          print(sales_spots2a);
          print(sales_spots2b);
          print(sales_spots2c);
        });
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph4b extends StatefulWidget {
  const SalesGraph4b({super.key});

  @override
  State<SalesGraph4b> createState() => _SalesGraph4bState();
}

class _SalesGraph4bState extends State<SalesGraph4b> {
  List<FlSpot> sales_spots4b = [];

  Key sales_chartKey2b = UniqueKey();

  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots4b = [];

    sales_chartKey2b = UniqueKey();
    sales_maxY2 = 0;
    getSalesGraphData();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return sales_spots4b.isEmpty
        ? Container(
            height: 250,
            child: Center(
                child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Constants.ctaColorLight,
                    strokeWidth: 1.8,
                  ),
                ),
              ),
            )),
          )
        : Container(
            height: 250,
            child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                        padding: const EdgeInsets.all(14.0),
                        child: LineChart(
                          key: sales_chartKey2b,
                          LineChartData(
                            lineTouchData: LineTouchData(
                                enabled: true,
                                touchCallback: (FlTouchEvent event,
                                    LineTouchResponse? touchResponse) {
                                  // TODO : Utilize touch event here to perform any operation
                                },
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipBgColor: Colors.blueGrey,
                                  tooltipRoundedRadius: 20.0,
                                  showOnTopOfTheChartBoxArea: false,
                                  fitInsideHorizontally: true,
                                  tooltipMargin: 0,
                                  getTooltipItems: (touchedSpots) {
                                    return touchedSpots.map(
                                      (LineBarSpot touchedSpot) {
                                        const textStyle = TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white70,
                                        );
                                        return LineTooltipItem(
                                          touchedSpot.y.round().toString(),
                                          textStyle,
                                        );
                                      },
                                    ).toList();
                                  },
                                ),
                                getTouchedSpotIndicator:
                                    (LineChartBarData barData,
                                        List<int> indicators) {
                                  return indicators.map(
                                    (int index) {
                                      final line = FlLine(
                                          color: Colors.grey,
                                          strokeWidth: 1,
                                          dashArray: [2, 4]);
                                      return TouchedSpotIndicatorData(
                                        line,
                                        FlDotData(show: false),
                                      );
                                    },
                                  ).toList();
                                },
                                getTouchLineEnd: (_, __) => double.infinity),
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots4b,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    int totalMonths = value.toInt();
                                    int year = totalMonths ~/ 12;
                                    int month = totalMonths % 12;
                                    month = month == 0 ? 12 : month;
                                    year = month == 12 ? year - 1 : year;
                                    String monthAbbreviation =
                                        getMonthAbbreviation(month);

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        "$monthAbbreviation", // Displaying both month and year
                                        style: TextStyle(fontSize: 10),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            maxY: sales_maxY2.toDouble(),
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )))));
  }

  Future<void> getSalesGraphData() async {
    try {
      String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

      Map<String, String>? payload = {
        "client_id": "${Constants.cec_client_id}",
        "start_date": Constants.sales_formattedStartDate,
        "end_date": Constants.sales_formattedEndDate
      };
      await http.post(
          Uri.parse(
            baseUrl,
          ),
          body: payload,
          headers: {
            "Cookie":
                "userid=expiry=2021-04-25&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=&empid=3&empfirstname=Mncedisi&emplastname=Khumalo&email=mncedisi@athandwe.co.za&username=mncedisi@athandwe.co.za&dob=8/28/1985 12:00:00 AM&fullname=Mncedisi Khumalo&userRole=5&userImage=mncedisi@athandwe.co.za.jpg&employedAt=branch&role=leader&branchid=6&branchname=Boulders&jobtitle=Administrative Assistant&dialing_strategy=Campaign Manager&clientname=Test 1 Funeral Parlour&foldername=maafrica&client_abbr=AS&pbx_account=pbx1051ef0a&soft_phone_ip=&agent_type=branch&mip_username=mnces@mip.co.za&agent_email=Mr Mncedisi Khumalo&ViciDial_phone_login=&ViciDial_phone_password=&ViciDial_agent_user=99&ViciDial_agent_password=&device_id=dC7JwXFwwdI:APA91bF0gTbuXlfT6wIcGMLY57Xo7VxUMrMH-MuFYL5PnjUVI0G5X1d3d90FNRb8-XmcjI40L1XqDH-KAc1KWnPpxNg8Z8SK4Ty0xonbz4L3sbKz3Rlr4hyBqePWx9ZfEp53vWwkZ3tx&servername=http://localhost:55661"
          }).then((value) {
        http.Response response = value;
        var jsonResponse = jsonDecode(response.body)["sales"];
        List<Map<String, dynamic>> sales =
            List<Map<String, dynamic>>.from(jsonResponse);

        DateTime now = DateTime.now();
        DateTime twelveMonthsAgo =
            DateTime(now.year, now.month).subtract(const Duration(days: 365));

        Map<String, int> monthlySalesCount = {};

        for (var sale in sales) {
          DateTime saleDate = DateTime.parse(sale['sale_datetime']);
          if (saleDate.isAfter(twelveMonthsAgo)) {
            String yearMonth =
                "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}";
            monthlySalesCount.update(yearMonth, (v) => v + 1,
                ifAbsent: () => 1);
          }
        }

        // Convert to spots and sort
        List<FlSpot> salesSpots = monthlySalesCount.entries.map((e) {
          print("fgffgf2 $e");
          var parts = e.key.split('-');
          var year = int.parse(parts[0]);
          var month = int.parse(parts[1]);
          //print("evalue ${e.value}");
          if (e.value > sales_maxY2) {
            sales_maxY2 = e.value + 50;
          }
          return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
        }).toList();

        salesSpots.sort((a, b) => a.x.compareTo(b.x));
        if (salesSpots.length > 12) {
          salesSpots = salesSpots.sublist(salesSpots.length - 12);
        }
        setState(() {
          sales_spots4b = salesSpots;
          print(sales_spots4b);
        });
      });
    } catch (exception) {
      // Handle exception
    }
  }
}

class SalesGraph4c extends StatefulWidget {
  const SalesGraph4c({super.key});

  @override
  State<SalesGraph4c> createState() => _SalesGraph4cState();
}

class _SalesGraph4cState extends State<SalesGraph4c> {
  List<FlSpot> sales_spots2c = [];

  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots2c = [];
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;
    getSalesGraphData();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return sales_spots2c.isEmpty
        ? Container(
            height: 250,
            child: Center(
                child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Constants.ctaColorLight,
                    strokeWidth: 1.8,
                  ),
                ),
              ),
            )),
          )
        : Container(
            height: 250,
            child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                        padding: const EdgeInsets.all(14.0),
                        child: LineChart(
                            key: sales_chartKey2c,
                            LineChartData(
                              lineBarsData: [
                                LineChartBarData(
                                  spots: sales_spots2c,
                                  isCurved: true,
                                  barWidth: 3,
                                  color: Colors.grey.shade400,
                                  dotData: FlDotData(
                                    show: true,
                                    getDotPainter:
                                        (spot, percent, barData, index) {
                                      // Show custom dot and text for specific x-values

                                      return FlDotCirclePainter(
                                          radius: 2,
                                          color: Colors.red,
                                          strokeColor: Colors.green);
                                      /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                    },
                                  ),
                                ),
                              ],
                              gridData: FlGridData(
                                show: true,
                                drawVerticalLine: false,
                                getDrawingHorizontalLine: (value) {
                                  return FlLine(
                                    color: Colors.grey.withOpacity(0.10),
                                    strokeWidth: 1,
                                  );
                                },
                                getDrawingVerticalLine: (value) {
                                  return FlLine(
                                    color: Colors.grey,
                                    strokeWidth: 1,
                                  );
                                },
                              ),
                              titlesData: FlTitlesData(
                                bottomTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    interval: 1,
                                    getTitlesWidget: (value, meta) {
                                      int totalMonths = value.toInt();
                                      int year = totalMonths ~/ 12;
                                      int month = totalMonths % 12;
                                      month = month == 0 ? 12 : month;
                                      year = month == 12 ? year - 1 : year;
                                      String monthAbbreviation =
                                          getMonthAbbreviation(month);

                                      return Padding(
                                        padding: const EdgeInsets.all(2.0),
                                        child: Text(
                                          "$monthAbbreviation", // Displaying both month and year
                                          style: TextStyle(fontSize: 10),
                                        ),
                                      );
                                    },
                                  ),
                                  axisNameWidget: Padding(
                                    padding: const EdgeInsets.only(top: 0.0),
                                    child: Text(
                                      'Months of the Year',
                                      style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                                topTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: false,
                                    getTitlesWidget: (value, meta) {
                                      return Text(value.toInt().toString());
                                    },
                                  ),
                                ),
                                rightTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: false,
                                    getTitlesWidget: (value, meta) {
                                      return Text(value.toInt().toString());
                                    },
                                  ),
                                ),
                                leftTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    reservedSize: 20,
                                    getTitlesWidget: (value, meta) {
                                      return Text(
                                        formatLargeNumber3(
                                            value.toInt().toString()),
                                        style: TextStyle(fontSize: 8),
                                      );
                                    },
                                  ),
                                  /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                ),
                              ),
                              minY: 0,
                              maxY: sales_maxY2.toDouble(),
                              borderData: FlBorderData(
                                show: true,
                                border: Border(
                                  left: BorderSide.none,
                                  bottom: BorderSide(
                                    color: Colors.grey.withOpacity(0.35),
                                    width: 1,
                                  ),
                                  right: BorderSide.none,
                                  top: BorderSide.none,
                                ),
                              ),
                            ))))));
  }

  Future<void> getSalesGraphData() async {
    try {
      String baseUrl = "https://miinsightsapps.net/files/get_sales_data/";

      Map<String, String>? payload = {
        "client_id": "${Constants.cec_client_id}",
        "start_date": Constants.sales_formattedStartDate,
        "end_date": Constants.sales_formattedEndDate
      };
      await http.post(
          Uri.parse(
            baseUrl,
          ),
          body: payload,
          headers: {
            "Cookie":
                "userid=expiry=2021-04-25&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=&empid=3&empfirstname=Mncedisi&emplastname=Khumalo&email=mncedisi@athandwe.co.za&username=mncedisi@athandwe.co.za&dob=8/28/1985 12:00:00 AM&fullname=Mncedisi Khumalo&userRole=5&userImage=mncedisi@athandwe.co.za.jpg&employedAt=branch&role=leader&branchid=6&branchname=Boulders&jobtitle=Administrative Assistant&dialing_strategy=Campaign Manager&clientname=Test 1 Funeral Parlour&foldername=maafrica&client_abbr=AS&pbx_account=pbx1051ef0a&soft_phone_ip=&agent_type=branch&mip_username=mnces@mip.co.za&agent_email=Mr Mncedisi Khumalo&ViciDial_phone_login=&ViciDial_phone_password=&ViciDial_agent_user=99&ViciDial_agent_password=&device_id=dC7JwXFwwdI:APA91bF0gTbuXlfT6wIcGMLY57Xo7VxUMrMH-MuFYL5PnjUVI0G5X1d3d90FNRb8-XmcjI40L1XqDH-KAc1KWnPpxNg8Z8SK4Ty0xonbz4L3sbKz3Rlr4hyBqePWx9ZfEp53vWwkZ3tx&servername=http://localhost:55661"
          }).then((value) {
        http.Response response = value;
        var jsonResponse = jsonDecode(response.body)["sales"];
        List<Map<String, dynamic>> sales =
            List<Map<String, dynamic>>.from(jsonResponse);

        DateTime now = DateTime.now();
        DateTime twelveMonthsAgo =
            DateTime(now.year, now.month).subtract(const Duration(days: 365));

        Map<String, int> monthlySalesCount = {};

        for (var sale in sales) {
          if (sale["status"] != "Inforced") {
            DateTime saleDate = DateTime.parse(sale['sale_datetime']);
            if (saleDate.isAfter(twelveMonthsAgo)) {
              String yearMonth =
                  "${saleDate.year}-${saleDate.month.toString().padLeft(2, '0')}";
              monthlySalesCount.update(yearMonth, (v) => v + 1,
                  ifAbsent: () => 1);
            }
          }
        }

        // Convert to spots and sort
        List<FlSpot> salesSpots = monthlySalesCount.entries.map((e) {
          print("fgffgf $e");
          var parts = e.key.split('-');
          var year = int.parse(parts[0]);
          var month = int.parse(parts[1]);
          //print("evalue ${e.value}");
          if (e.value > sales_maxY2) {
            sales_maxY2 = e.value + 50;
          }
          return FlSpot((year * 12 + month).toDouble(), e.value.toDouble());
        }).toList();

        salesSpots.sort((a, b) => a.x.compareTo(b.x));
        if (salesSpots.length > 12) {
          salesSpots = salesSpots.sublist(salesSpots.length - 12);
        }
        setState(() {
          sales_spots2c = salesSpots;
          print(sales_spots2c);
        });
      });
    } catch (exception) {
      // Handle exception
    }
  }
}
