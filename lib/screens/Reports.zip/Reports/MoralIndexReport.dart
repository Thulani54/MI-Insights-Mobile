import 'dart:convert';
import 'dart:ui' as ui;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:mi_insights/constants/Constants.dart';

import '../../customwidgets/custom_date_range_picker.dart';
import '../../models/MoraleIndexCategory.dart';
import '../../services/MyNoyifier.dart';
import '../../services/moral_index_service.dart';
import '../../services/window_manager.dart';

int noOfDaysThisMonth = 30;
bool isLoading = false;
final maintenanceValue = ValueNotifier<int>(0);
double totalAmount = 0;
MyNotifier? myNotifier;
DateTime datefrom = DateTime.now().subtract(Duration(days: 60));
DateTime dateto = DateTime.now();
int days_difference = 0;

int report_index = 0;
int moral_index_index = 0;
String data2 = "";

int touchedIndex = -1;

class MoraleIndexReport extends StatefulWidget {
  const MoraleIndexReport({Key? key}) : super(key: key);

  @override
  State<MoraleIndexReport> createState() => _MoraleIndexReportState();
}

List<Map<String, dynamic>> leads = [];
List<List<Map<String, dynamic>>> policies = [];
double _sliderPosition = 0.0;
int _selectedButton = 1;

class _MoraleIndexReportState extends State<MoraleIndexReport> {
  Color _button1Color = Colors.grey.withOpacity(0.0);
  Color _button2Color = Colors.grey.withOpacity(0.0);
  Color _button3Color = Colors.grey.withOpacity(0.0);

  void _animateButton(int buttonNumber) {
    DateTime? startDate = DateTime.now();
    DateTime? endDate = DateTime.now();
    leads = [];

    setState(() {});

    print("jhhh " + buttonNumber.toString());
    _selectedButton = buttonNumber;
    if (buttonNumber == 1)
      _sliderPosition = 0.0;
    else if (buttonNumber == 2)
      _sliderPosition = (MediaQuery.of(context).size.width / 3) - 18;
    else if (buttonNumber == 3)
      _sliderPosition = 2 * (MediaQuery.of(context).size.width / 3) - 32;
    setState(() {});
    if (buttonNumber != 3) {
      setState(() {
        // Update colors
        _button1Color = buttonNumber == 1
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);
        _button2Color = buttonNumber == 2
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);
        _button3Color = buttonNumber == 3
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);

        // Update slider position based on the button tapped
      });
      DateTime now = DateTime.now();

      setState(() {});
    } else {
      showCustomDateRangePicker(
        context,
        dismissible: true,
        minimumDate: DateTime.now().subtract(const Duration(days: 360)),
        maximumDate: DateTime.now().add(Duration(days: 360)),
        /*    endDate: endDate,
        startDate: startDate,*/
        backgroundColor: Colors.white,
        primaryColor: Constants.ctaColorLight,
        onApplyClick: (start, end) {
          setState(() {
            endDate = end;
            startDate = start;
          });

          Constants.moral_index_formattedStartDate =
              DateFormat('yyyy-MM-dd').format(startDate!);
          Constants.moral_index_formattedEndDate =
              DateFormat('yyyy-MM-dd').format(endDate!);
          setState(() {});

          String dateRange =
              '${Constants.moral_index_formattedStartDate} - ${Constants.moral_index_formattedEndDate}';
          print("currently loading ${dateRange}");
          DateTime startDateTime = DateFormat('yyyy-MM-dd')
              .parse(Constants.moral_index_formattedStartDate);
          DateTime endDateTime = DateFormat('yyyy-MM-dd')
              .parse(Constants.moral_index_formattedEndDate);

          days_difference = endDateTime.difference(startDateTime).inDays;
          if (kDebugMode) {
            print("days_difference ${days_difference}");
            print(
                "formattedEndDate9fgfg ${Constants.moral_index_formattedEndDate}");
          }
          getMoralIndexReport(Constants.moral_index_formattedStartDate,
              Constants.moral_index_formattedEndDate, 3, context);
          isLoading = true;
          setState(() {});
        },
        onCancelClick: () {
          setState(() {
            // endDate = null;
            //  startDate = null;
          });
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
            elevation: 6,
            leading: InkWell(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.black,
                )),
            backgroundColor: Colors.white,
            centerTitle: true,
            title: const Text(
              "Morale Index",
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            )),
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              SizedBox(
                height: 12,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(36)),
                  child: Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(36)),
                        child: Center(
                          child: Row(
                            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  _animateButton(1);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  height: 35,
                                  child: Center(
                                    child: Text(
                                      'MTD',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  _animateButton(2);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  child: Center(
                                    child: Text(
                                      'YTD',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  _animateButton(3);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  child: Center(
                                    child: Text(
                                      'Select Dates',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      AnimatedPositioned(
                        duration: Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        left: _sliderPosition,
                        child: InkWell(
                          onTap: () {
                            _animateButton(3);
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width / 3,
                            height: 35,
                            decoration: BoxDecoration(
                              color: Constants
                                  .ctaColorLight, // Color of the slider
                              borderRadius: BorderRadius.circular(36),
                            ),
                            child: _selectedButton == 1
                                ? Center(
                                    child: Text(
                                      'MTD',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  )
                                : _selectedButton == 2
                                    ? Center(
                                        child: Text(
                                          'YTD',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      )
                                    : Center(
                                        child: Text(
                                          'Select Dates',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              isLoading
                  ? Center(
                      child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: Constants.ctaColorLight,
                            strokeWidth: 1.8,
                          ),
                        ),
                      ),
                    ))
                  : Container(),
              Padding(
                padding: const EdgeInsets.only(left: 20.0, right: 20, top: 12),
                child: Container(
                  height: 1,
                  color: Colors.grey.withOpacity(0.35),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    if (isLoading)
                      SizedBox(
                        height: 12,
                      ),
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            childAspectRatio:
                                MediaQuery.of(context).size.width /
                                    (MediaQuery.of(context).size.height / 2.3)),
                        itemCount: _selectedButton == 1
                            ? Constants.moral_index_sectionsList1a.length
                            : _selectedButton == 2
                                ? Constants.moral_index_sectionsList2a.length
                                : _selectedButton == 3 && days_difference <= 31
                                    ? Constants
                                        .moral_index_sectionsList3a.length
                                    : Constants
                                        .moral_index_sectionsList3b.length,
                        padding: EdgeInsets.all(2.0),
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                              onTap: () {},
                              child: Container(
                                height: 290,
                                width: MediaQuery.of(context).size.width / 2.9,
                                child: Stack(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        // moral_index_index = index;
                                        setState(() {});
                                        if (kDebugMode) {
                                          print("moral_index_index " +
                                              index.toString());
                                        }
                                        if (index == 1) {
                                          /*     Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) => SalesReport()));*/
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            bottom: 4.0, right: 8),
                                        child: Card(
                                          elevation: 6,
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            side: BorderSide(
                                                color: Colors.white70,
                                                width: 0),
                                            borderRadius:
                                                BorderRadius.circular(16),
                                          ),
                                          child: ClipPath(
                                            clipper: ShapeBorderClipper(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16))),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: Constants
                                                              .ctaColorLight,
                                                          width: 6))),
                                              child: Column(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors.grey
                                                              .withOpacity(
                                                                  0.05),
                                                          border: Border.all(
                                                              color: Colors.grey
                                                                  .withOpacity(
                                                                      0.0)),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8)),
                                                      child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        14),
                                                          ),
                                                          width: MediaQuery.of(
                                                                  context)
                                                              .size
                                                              .width,
                                                          height: 270,
                                                          /*     decoration: BoxDecoration(
                                                          color:Colors.white,
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                          border: Border.all(
                                                              width: 1,
                                                              color: Colors
                                                                  .grey.withOpacity(0.2))),*/
                                                          margin:
                                                              EdgeInsets.only(
                                                                  right: 0,
                                                                  left: 0,
                                                                  bottom: 4),
                                                          child: Column(
                                                            children: [
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Expanded(
                                                                child: Center(
                                                                    child:
                                                                        Padding(
                                                                  padding:
                                                                      const EdgeInsets
                                                                          .all(
                                                                          8.0),
                                                                  child: Text(
                                                                    formatLargeNumber3((_selectedButton ==
                                                                                1
                                                                            ? Constants.moral_index_sectionsList1a[index].amount
                                                                            : _selectedButton == 2
                                                                                ? Constants.moral_index_sectionsList2a[index].amount
                                                                                : _selectedButton == 3 && days_difference <= 31
                                                                                    ? Constants.moral_index_sectionsList3a[index].amount
                                                                                    : Constants.moral_index_sectionsList3b[index].amount)
                                                                        .toString()),
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            18.5,
                                                                        fontWeight:
                                                                            FontWeight.w500),
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 2,
                                                                  ),
                                                                )),
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        8.0),
                                                                child: Text(
                                                                  _selectedButton ==
                                                                          1
                                                                      ? Constants
                                                                          .moral_index_sectionsList1a[
                                                                              index]
                                                                          .id
                                                                      : _selectedButton ==
                                                                              2
                                                                          ? Constants
                                                                              .moral_index_sectionsList2a[index]
                                                                              .id
                                                                          : _selectedButton == 3 && days_difference <= 31
                                                                              ? Constants.moral_index_sectionsList3a[index].id
                                                                              : Constants.moral_index_sectionsList3b[index].id,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          12.5),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 1,
                                                                ),
                                                              )),
                                                            ],
                                                          )),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ));
                        },
                      ),
                    ),
                    _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0),
                            child: Text(
                                "Moral Index Overview (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding: const EdgeInsets.only(left: 16.0),
                                child: Text(
                                    "Moral Index Overview (YTD - ${DateTime.now().year})"),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(left: 16.0),
                                child: Text(
                                    "Moral Index Overview (${Constants.moral_index_formattedStartDate} to ${Constants.moral_index_formattedEndDate})"),
                              ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: Colors.grey.withOpacity(0.05)),
                          height: 250,
                          child: isLoading == false
                              ? _selectedButton == 1
                                  ? Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Card(
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(16)),
                                        child: AspectRatio(
                                          aspectRatio: 1.66,
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(top: 16),
                                            child: LayoutBuilder(
                                              builder: (context, constraints) {
                                                final double barsSpace = 1.0 *
                                                    constraints.maxWidth /
                                                    200;

                                                return Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: BarChart(
                                                    BarChartData(
                                                      alignment:
                                                          BarChartAlignment
                                                              .center,
                                                      barTouchData:
                                                          BarTouchData(
                                                              enabled: false),
                                                      gridData: FlGridData(
                                                        show: true,
                                                        drawVerticalLine: false,
                                                        getDrawingHorizontalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.10),
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                        getDrawingVerticalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey,
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                      ),
                                                      titlesData: FlTitlesData(
                                                        bottomTitles:
                                                            AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            interval: 1,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        0.0),
                                                                child: Text(
                                                                  value
                                                                      .toInt()
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          6.5),
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                          axisNameWidget:
                                                              Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 0.0),
                                                            child: Column(
                                                              children: [
                                                                Text(
                                                                  'Days of the month',
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          11,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      color: Colors
                                                                          .black),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        topTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        rightTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        leftTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            reservedSize: 20,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(
                                                                formatLargeNumber2(
                                                                    value
                                                                        .toInt()
                                                                        .toString()),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        7.5),
                                                              );
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                      borderData: FlBorderData(
                                                          show: false),
                                                      groupsSpace: barsSpace,
                                                      barGroups: barChartData1,
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  : _selectedButton == 2
                                      ? Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Card(
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(16)),
                                            child: AspectRatio(
                                              aspectRatio: 1.66,
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 16),
                                                child: LayoutBuilder(
                                                  builder:
                                                      (context, constraints) {
                                                    final double barsSpace =
                                                        1.2 *
                                                            constraints
                                                                .maxWidth /
                                                            200;

                                                    return Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              8.0),
                                                      child: BarChart(
                                                        BarChartData(
                                                          alignment:
                                                              BarChartAlignment
                                                                  .center,
                                                          barTouchData:
                                                              BarTouchData(
                                                                  enabled:
                                                                      false),
                                                          gridData: FlGridData(
                                                            show: true,
                                                            drawVerticalLine:
                                                                false,
                                                            getDrawingHorizontalLine:
                                                                (value) {
                                                              return FlLine(
                                                                color: Colors
                                                                    .grey
                                                                    .withOpacity(
                                                                        0.10),
                                                                strokeWidth: 1,
                                                              );
                                                            },
                                                            getDrawingVerticalLine:
                                                                (value) {
                                                              return FlLine(
                                                                color:
                                                                    Colors.grey,
                                                                strokeWidth: 1,
                                                              );
                                                            },
                                                          ),
                                                          titlesData:
                                                              FlTitlesData(
                                                            bottomTitles:
                                                                AxisTitles(
                                                              sideTitles:
                                                                  SideTitles(
                                                                showTitles:
                                                                    true,
                                                                interval: 1,
                                                                getTitlesWidget:
                                                                    (value,
                                                                        meta) {
                                                                  return Padding(
                                                                    padding:
                                                                        const EdgeInsets
                                                                            .all(
                                                                            0.0),
                                                                    child: Text(
                                                                      getMonthAbbreviation(
                                                                              value.toInt())
                                                                          .toString(),
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              9.5),
                                                                    ),
                                                                  );
                                                                },
                                                              ),
                                                              axisNameWidget:
                                                                  Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            0.0),
                                                                child: Text(
                                                                  'Months of the Year',
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          11,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      color: Colors
                                                                          .black),
                                                                ),
                                                              ),
                                                            ),
                                                            topTitles:
                                                                AxisTitles(
                                                              sideTitles:
                                                                  SideTitles(
                                                                showTitles:
                                                                    false,
                                                                getTitlesWidget:
                                                                    (value,
                                                                        meta) {
                                                                  return Text(value
                                                                      .toInt()
                                                                      .toString());
                                                                },
                                                              ),
                                                            ),
                                                            rightTitles:
                                                                AxisTitles(
                                                              sideTitles:
                                                                  SideTitles(
                                                                showTitles:
                                                                    false,
                                                                getTitlesWidget:
                                                                    (value,
                                                                        meta) {
                                                                  return Text(value
                                                                      .toInt()
                                                                      .toString());
                                                                },
                                                              ),
                                                            ),
                                                            leftTitles:
                                                                AxisTitles(
                                                              sideTitles:
                                                                  SideTitles(
                                                                showTitles:
                                                                    true,
                                                                reservedSize:
                                                                    20,
                                                                getTitlesWidget:
                                                                    (value,
                                                                        meta) {
                                                                  return Text(
                                                                    formatLargeNumber2(value
                                                                        .toInt()
                                                                        .toString()),
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            7.5),
                                                                  );
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                          borderData:
                                                              FlBorderData(
                                                                  show: false),
                                                          groupsSpace:
                                                              barsSpace,
                                                          barGroups:
                                                              barChartData2,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                ),
                                              ),
                                            ),
                                          ),
                                        )
                                      : _selectedButton == 3 &&
                                              days_difference <= 31
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Card(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16)),
                                                child: AspectRatio(
                                                  aspectRatio: 1.66,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 16),
                                                    child: LayoutBuilder(
                                                      builder: (context,
                                                          constraints) {
                                                        final double barsSpace =
                                                            1.0 *
                                                                constraints
                                                                    .maxWidth /
                                                                200;

                                                        return Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                          child: BarChart(
                                                            BarChartData(
                                                              alignment:
                                                                  BarChartAlignment
                                                                      .center,
                                                              barTouchData:
                                                                  BarTouchData(
                                                                      enabled:
                                                                          false),
                                                              gridData:
                                                                  FlGridData(
                                                                show: true,
                                                                drawVerticalLine:
                                                                    false,
                                                                getDrawingHorizontalLine:
                                                                    (value) {
                                                                  return FlLine(
                                                                    color: Colors
                                                                        .grey
                                                                        .withOpacity(
                                                                            0.10),
                                                                    strokeWidth:
                                                                        1,
                                                                  );
                                                                },
                                                                getDrawingVerticalLine:
                                                                    (value) {
                                                                  return FlLine(
                                                                    color: Colors
                                                                        .grey,
                                                                    strokeWidth:
                                                                        1,
                                                                  );
                                                                },
                                                              ),
                                                              titlesData:
                                                                  FlTitlesData(
                                                                bottomTitles:
                                                                    AxisTitles(
                                                                  sideTitles:
                                                                      SideTitles(
                                                                    showTitles:
                                                                        true,
                                                                    interval: 1,
                                                                    getTitlesWidget:
                                                                        (value,
                                                                            meta) {
                                                                      return Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            0.0),
                                                                        child:
                                                                            Text(
                                                                          value
                                                                              .toInt()
                                                                              .toString(),
                                                                          style:
                                                                              TextStyle(fontSize: 6.5),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ),
                                                                  axisNameWidget:
                                                                      Padding(
                                                                    padding: const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            0.0),
                                                                    child: Text(
                                                                      'Days of the month',
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              11,
                                                                          fontWeight: FontWeight
                                                                              .w500,
                                                                          color:
                                                                              Colors.black),
                                                                    ),
                                                                  ),
                                                                ),
                                                                topTitles:
                                                                    AxisTitles(
                                                                  sideTitles:
                                                                      SideTitles(
                                                                    showTitles:
                                                                        false,
                                                                    getTitlesWidget:
                                                                        (value,
                                                                            meta) {
                                                                      return Text(value
                                                                          .toInt()
                                                                          .toString());
                                                                    },
                                                                  ),
                                                                ),
                                                                rightTitles:
                                                                    AxisTitles(
                                                                  sideTitles:
                                                                      SideTitles(
                                                                    showTitles:
                                                                        false,
                                                                    getTitlesWidget:
                                                                        (value,
                                                                            meta) {
                                                                      return Text(value
                                                                          .toInt()
                                                                          .toString());
                                                                    },
                                                                  ),
                                                                ),
                                                                leftTitles:
                                                                    AxisTitles(
                                                                  sideTitles:
                                                                      SideTitles(
                                                                    showTitles:
                                                                        true,
                                                                    reservedSize:
                                                                        20,
                                                                    getTitlesWidget:
                                                                        (value,
                                                                            meta) {
                                                                      return Text(
                                                                        formatLargeNumber2(value
                                                                            .toInt()
                                                                            .toString()),
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                7.5),
                                                                      );
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                              borderData:
                                                                  FlBorderData(
                                                                      show:
                                                                          false),
                                                              groupsSpace:
                                                                  barsSpace,
                                                              barGroups:
                                                                  barChartData3,
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            )
                                          : _selectedButton == 3 &&
                                                  days_difference > 31
                                              ? Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Card(
                                                    shape:
                                                        RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        16)),
                                                    child: AspectRatio(
                                                      aspectRatio: 1.66,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 16),
                                                        child: LayoutBuilder(
                                                          builder: (context,
                                                              constraints) {
                                                            final double
                                                                barsSpace =
                                                                1.0 *
                                                                    constraints
                                                                        .maxWidth /
                                                                    200;

                                                            return Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(8.0),
                                                              child: BarChart(
                                                                BarChartData(
                                                                  alignment:
                                                                      BarChartAlignment
                                                                          .center,
                                                                  barTouchData:
                                                                      BarTouchData(
                                                                          enabled:
                                                                              false),
                                                                  gridData:
                                                                      FlGridData(
                                                                    show: true,
                                                                    drawVerticalLine:
                                                                        false,
                                                                    getDrawingHorizontalLine:
                                                                        (value) {
                                                                      return FlLine(
                                                                        color: Colors
                                                                            .grey
                                                                            .withOpacity(0.10),
                                                                        strokeWidth:
                                                                            1,
                                                                      );
                                                                    },
                                                                    getDrawingVerticalLine:
                                                                        (value) {
                                                                      return FlLine(
                                                                        color: Colors
                                                                            .grey,
                                                                        strokeWidth:
                                                                            1,
                                                                      );
                                                                    },
                                                                  ),
                                                                  titlesData:
                                                                      FlTitlesData(
                                                                    bottomTitles:
                                                                        AxisTitles(
                                                                      sideTitles:
                                                                          SideTitles(
                                                                        showTitles:
                                                                            true,
                                                                        interval:
                                                                            1,
                                                                        getTitlesWidget:
                                                                            (value,
                                                                                meta) {
                                                                          return Padding(
                                                                            padding:
                                                                                const EdgeInsets.all(0.0),
                                                                            child:
                                                                                Text(
                                                                              getMonthAbbreviation(value.toInt()).toString(),
                                                                              style: TextStyle(fontSize: 9.5),
                                                                            ),
                                                                          );
                                                                        },
                                                                      ),
                                                                      axisNameWidget:
                                                                          Padding(
                                                                        padding: const EdgeInsets
                                                                            .only(
                                                                            top:
                                                                                0.0),
                                                                        child:
                                                                            Text(
                                                                          'Months of the Year',
                                                                          style: TextStyle(
                                                                              fontSize: 11,
                                                                              fontWeight: FontWeight.w500,
                                                                              color: Colors.black),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    topTitles:
                                                                        AxisTitles(
                                                                      sideTitles:
                                                                          SideTitles(
                                                                        showTitles:
                                                                            false,
                                                                        getTitlesWidget:
                                                                            (value,
                                                                                meta) {
                                                                          return Text(value
                                                                              .toInt()
                                                                              .toString());
                                                                        },
                                                                      ),
                                                                    ),
                                                                    rightTitles:
                                                                        AxisTitles(
                                                                      sideTitles:
                                                                          SideTitles(
                                                                        showTitles:
                                                                            false,
                                                                        getTitlesWidget:
                                                                            (value,
                                                                                meta) {
                                                                          return Text(value
                                                                              .toInt()
                                                                              .toString());
                                                                        },
                                                                      ),
                                                                    ),
                                                                    leftTitles:
                                                                        AxisTitles(
                                                                      sideTitles:
                                                                          SideTitles(
                                                                        showTitles:
                                                                            true,
                                                                        reservedSize:
                                                                            20,
                                                                        getTitlesWidget:
                                                                            (value,
                                                                                meta) {
                                                                          return Text(
                                                                            formatLargeNumber2(value.toInt().toString()),
                                                                            style:
                                                                                TextStyle(fontSize: 7.5),
                                                                          );
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  borderData:
                                                                      FlBorderData(
                                                                          show:
                                                                              false),
                                                                  groupsSpace:
                                                                      barsSpace,
                                                                  barGroups:
                                                                      barChartData2,
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              : Container()
                              : Center(
                                  child: Center(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        color: Constants.ctaColorLight,
                                        strokeWidth: 1.8,
                                      ),
                                    ),
                                  ),
                                ))),
                    ),
                    Row(
                      children: [
                        Spacer(),
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(360),
                            color: Colors.blue,
                          ),
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        Text("Happy"),
                        SizedBox(
                          width: 12,
                        ),
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(360),
                            color: Colors.green,
                          ),
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        Text("Unsure"),
                        SizedBox(
                          width: 12,
                        ),
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(360),
                            color: Colors.purple,
                          ),
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        Text("Sad"),
                        SizedBox(
                          width: 8,
                        ),
                        Spacer(),
                      ],
                    ),
                    Container(
                      height: 300,
                      child: Row(children: <Widget>[
                        const SizedBox(
                          height: 18,
                        ),
                        Expanded(
                          flex: 3,
                          child: PieChart(
                            PieChartData(
                              pieTouchData: PieTouchData(
                                touchCallback:
                                    (FlTouchEvent event, pieTouchResponse) {
                                  setState(() {
                                    if (!event.isInterestedForInteractions ||
                                        pieTouchResponse == null ||
                                        pieTouchResponse.touchedSection ==
                                            null) {
                                      touchedIndex = -1;
                                      return;
                                    }
                                    touchedIndex = pieTouchResponse
                                        .touchedSection!.touchedSectionIndex;
                                  });
                                },
                              ),
                              borderData: FlBorderData(
                                show: true,
                                border: Border(
                                  left: BorderSide.none,
                                  bottom: BorderSide(
                                    color: Colors.grey.withOpacity(0.35),
                                    width: 1,
                                  ),
                                  right: BorderSide.none,
                                  top: BorderSide.none,
                                ),
                              ),
                              sectionsSpace: 0,
                              centerSpaceRadius: 60,
                              sections: _selectedButton == 1
                                  ? Constants.moral_index_pieData_1
                                  : _selectedButton == 2
                                      ? Constants.moral_index_pieData_2
                                      : _selectedButton == 3 &&
                                              days_difference <= 31
                                          ? Constants.moral_index_pieData_3
                                          : Constants.moral_index_pieData_4,
                            ),
                          ),
                        ),
                      ]),
                    ),
                    Row(
                      children: [
                        Spacer(),
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(360),
                            color: Colors.blue,
                          ),
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        Text("Happy"),
                        SizedBox(
                          width: 12,
                        ),
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(360),
                            color: Colors.green,
                          ),
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        Text("Unsure"),
                        SizedBox(
                          width: 12,
                        ),
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(360),
                            color: Colors.purple,
                          ),
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        Text("Sad"),
                        SizedBox(
                          width: 8,
                        ),
                        Spacer(),
                      ],
                    ),

                    /*Expanded(
                            child: ListView.builder(
                                itemCount: salesbybranch.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  if (index < 5) {
                                    return Indicator(
                                      color: samplecolors[index],
                                      text: salesbybranch[index]
                                          .branch_name
                                          .toString(),
                                      isSquare: true,
                                    );
                                  } else
                                    Container();
                                }),
                          ),*/ /*
                          const SizedBox(
                            width: 28,
                          ),
                        ],
                      ),
                    ),*/
                    /* if (_selectedButton == 1)
                      Container(
                          height: 280,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Padding(
                                  padding: const EdgeInsets.all(14.0),
                                  child: moral_index_index == 0
                                      ? Column(
                                          children: [
                                            Expanded(
                                              child: Container(
                                                height: 120,
                                                child: LineChart(
                                                  key: Constants
                                                      .moral_index_chartKey1a,
                                                  LineChartData(
                                                    lineBarsData: [
                                                      LineChartBarData(
                                                        spots: Constants
                                                            .moral_index_spots1a,
                                                        isCurved: true,
                                                        barWidth: 3,
                                                        color: Colors
                                                            .grey.shade400,
                                                        dotData: FlDotData(
                                                          show: true,
                                                          getDotPainter: (spot,
                                                              percent,
                                                              barData,
                                                              index) {
                                                            // Show custom dot and text for specific x-values

                                                            return FlDotCirclePainter(
                                                                radius: 2,
                                                                color:
                                                                    Colors.red,
                                                                strokeColor:
                                                                    Colors
                                                                        .green);
                                                            */ /*    if (_selectedButton == 1) {
                                                    return CustomDotPainter(
                                                        yValue: spot.y,
                                                        Constants.maxY: Constants.maxY.toDouble(),
                                                        chartHeight: 120,
                                                        xValue: spot.x,
                                                        maxX: 30,
                                                        chartWidth:
                                                            MediaQuery.of(context).size.width +
                                                                45);
                                                  } else {
                                                    return CustomDotPainter(
                                                        yValue: spot.y,
                                                        Constants.maxY: Constants.maxY.toDouble(),
                                                        chartHeight: 120,
                                                        xValue: spot.x,
                                                        maxX: 12,
                                                        chartWidth:
                                                            MediaQuery.of(context).size.width +
                                                                45);
                                                  }*/ /*
                                                          },
                                                        ),
                                                      ),
                                                    ],
                                                    gridData: FlGridData(
                                                      show: true,
                                                      drawVerticalLine: false,
                                                      getDrawingHorizontalLine:
                                                          (value) {
                                                        return FlLine(
                                                          color: Colors.grey
                                                              .withOpacity(
                                                                  0.10),
                                                          strokeWidth: 1,
                                                        );
                                                      },
                                                      getDrawingVerticalLine:
                                                          (value) {
                                                        return FlLine(
                                                          color: Colors.grey,
                                                          strokeWidth: 1,
                                                        );
                                                      },
                                                    ),
                                                    titlesData: FlTitlesData(
                                                      bottomTitles: AxisTitles(
                                                        sideTitles: SideTitles(
                                                          showTitles: true,
                                                          interval: 1,
                                                          getTitlesWidget:
                                                              (value, meta) {
                                                            return Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(2.0),
                                                              child: Text(
                                                                value
                                                                    .toInt()
                                                                    .toString(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        7),
                                                              ),
                                                            );
                                                          },
                                                        ),
                                                        axisNameWidget: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  top: 0.0),
                                                          child: Text(
                                                            'Days of the Month',
                                                            style: TextStyle(
                                                                fontSize: 11,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                color: Colors
                                                                    .black),
                                                          ),
                                                        ),
                                                      ),
                                                      topTitles: AxisTitles(
                                                        sideTitles: SideTitles(
                                                          showTitles: false,
                                                          getTitlesWidget:
                                                              (value, meta) {
                                                            return Text(value
                                                                .toInt()
                                                                .toString());
                                                          },
                                                        ),
                                                      ),
                                                      rightTitles: AxisTitles(
                                                        sideTitles: SideTitles(
                                                          showTitles: false,
                                                          getTitlesWidget:
                                                              (value, meta) {
                                                            return Text(value
                                                                .toInt()
                                                                .toString());
                                                          },
                                                        ),
                                                      ),
                                                      leftTitles: AxisTitles(
                                                        sideTitles: SideTitles(
                                                          showTitles: true,
                                                          reservedSize: 20,
                                                          getTitlesWidget:
                                                              (value, meta) {
                                                            return Text(
                                                              formatLargeNumber2(
                                                                  value
                                                                      .toInt()
                                                                      .toString()),
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      7.5),
                                                            );
                                                          },
                                                        ),
                                                        */ /*axisNameWidget: Padding(
                                                          padding:
                                                              const EdgeInsets.only(top: 0.0),
                                                          child: Text(
                                                            'Sales',
                                                            style: TextStyle(
                                                                fontSize: 11,
                                                                fontWeight: FontWeight.w500,
                                                                color: Colors.black),
                                                          ),
                                                        ),*/ /*
                                                      ),
                                                    ),
                                                    minY: 0,
                                                    maxX: noOfDaysThisMonth
                                                        .toDouble(),
                                                    maxY: _selectedButton == 1
                                                        ? Constants
                                                            .moral_index_maxY
                                                            .toDouble()
                                                        : Constants
                                                            .moral_index_maxY2
                                                            .toDouble(),
                                                    borderData: FlBorderData(
                                                      show: true,
                                                      border: Border(
                                                        left: BorderSide.none,
                                                        bottom: BorderSide(
                                                          color: Colors.grey
                                                              .withOpacity(
                                                                  0.35),
                                                          width: 1,
                                                        ),
                                                        right: BorderSide.none,
                                                        top: BorderSide.none,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 6,
                                            ),
                                            Text(
                                              "Weekend Sales are Added to / Accounted For On The Next Monday",
                                              style: TextStyle(fontSize: 9),
                                            )
                                          ],
                                        )
                                      : moral_index_index == 1
                                          ? Column(
                                              children: [
                                                Expanded(
                                                  child: LineChart(
                                                    key: Constants
                                                        .moral_index_chartKey1b,
                                                    LineChartData(
                                                      lineBarsData: [
                                                        LineChartBarData(
                                                          spots: Constants
                                                              .moral_index_spots1b,
                                                          isCurved: true,
                                                          barWidth: 3,
                                                          color: Colors
                                                              .grey.shade400,
                                                          dotData: FlDotData(
                                                            show: true,
                                                            getDotPainter:
                                                                (spot,
                                                                    percent,
                                                                    barData,
                                                                    index) {
                                                              // Show custom dot and text for specific x-values

                                                              return FlDotCirclePainter(
                                                                  radius: 2,
                                                                  color: Colors
                                                                      .red,
                                                                  strokeColor:
                                                                      Colors
                                                                          .green);
                                                              */ /*    if (_selectedButton == 1) {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 30,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                } else {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 12,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                }*/ /*
                                                            },
                                                          ),
                                                        ),
                                                      ],
                                                      minX: 1,
                                                      maxX: noOfDaysThisMonth
                                                          .toDouble(),
                                                      gridData: FlGridData(
                                                        show: true,
                                                        drawVerticalLine: false,
                                                        getDrawingHorizontalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.10),
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                        getDrawingVerticalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey,
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                      ),
                                                      titlesData: FlTitlesData(
                                                        bottomTitles:
                                                            AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            interval: 1,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        2.0),
                                                                child: Text(
                                                                  value
                                                                      .toInt()
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          7),
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                          axisNameWidget:
                                                              Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 0.0),
                                                            child: Text(
                                                              'Days of the Month',
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  color: Colors
                                                                      .black),
                                                            ),
                                                          ),
                                                        ),
                                                        topTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        rightTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        leftTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            reservedSize: 20,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(
                                                                formatLargeNumber2(
                                                                    value
                                                                        .toInt()
                                                                        .toString()),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        7.5),
                                                              );
                                                            },
                                                          ),
                                                          */ /*axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets.only(top: 0.0),
                                                        child: Text(
                                                          'Sales',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight: FontWeight.w500,
                                                              color: Colors.black),
                                                        ),
                                                      ),*/ /*
                                                        ),
                                                      ),
                                                      minY: 0,
                                                      maxY: _selectedButton == 1
                                                          ? Constants
                                                              .moral_index_maxY
                                                              .toDouble()
                                                          : Constants
                                                              .moral_index_maxY2
                                                              .toDouble(),
                                                      borderData: FlBorderData(
                                                        show: true,
                                                        border: Border(
                                                          left: BorderSide.none,
                                                          bottom: BorderSide(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.35),
                                                            width: 1,
                                                          ),
                                                          right:
                                                              BorderSide.none,
                                                          top: BorderSide.none,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Text(
                                                  "Weekend Sales are Added to / Accounted For On The Next Monday",
                                                  style: TextStyle(fontSize: 9),
                                                )
                                              ],
                                            )
                                          : Column(
                                              children: [
                                                Expanded(
                                                  child: LineChart(
                                                    key: Constants
                                                        .moral_index_chartKey1c,
                                                    LineChartData(
                                                      lineBarsData: [
                                                        LineChartBarData(
                                                          spots: Constants
                                                              .moral_index_spots1c,
                                                          isCurved: true,
                                                          barWidth: 3,
                                                          color: Colors
                                                              .grey.shade400,
                                                          dotData: FlDotData(
                                                            show: true,
                                                            getDotPainter:
                                                                (spot,
                                                                    percent,
                                                                    barData,
                                                                    index) {
                                                              // Show custom dot and text for specific x-values

                                                              return FlDotCirclePainter(
                                                                  radius: 2,
                                                                  color: Colors
                                                                      .red,
                                                                  strokeColor:
                                                                      Colors
                                                                          .green);
                                                              */ /*    if (_selectedButton == 1) {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 30,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                } else {
                                                  return CustomDotPainter(
                                                      yValue: spot.y,
                                                      Constants.maxY: Constants.maxY.toDouble(),
                                                      chartHeight: 120,
                                                      xValue: spot.x,
                                                      maxX: 12,
                                                      chartWidth:
                                                          MediaQuery.of(context).size.width +
                                                              45);
                                                }*/ /*
                                                            },
                                                          ),
                                                        ),
                                                      ],
                                                      minX: 1,
                                                      maxX: noOfDaysThisMonth
                                                          .toDouble(),
                                                      gridData: FlGridData(
                                                        show: true,
                                                        drawVerticalLine: false,
                                                        getDrawingHorizontalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.10),
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                        getDrawingVerticalLine:
                                                            (value) {
                                                          return FlLine(
                                                            color: Colors.grey,
                                                            strokeWidth: 1,
                                                          );
                                                        },
                                                      ),
                                                      titlesData: FlTitlesData(
                                                        bottomTitles:
                                                            AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            interval: 1,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        2.0),
                                                                child: Text(
                                                                  value
                                                                      .toInt()
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          7),
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                          axisNameWidget:
                                                              Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 0.0),
                                                            child: Text(
                                                              'Days of the Month',
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  color: Colors
                                                                      .black),
                                                            ),
                                                          ),
                                                        ),
                                                        topTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        rightTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: false,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(value
                                                                  .toInt()
                                                                  .toString());
                                                            },
                                                          ),
                                                        ),
                                                        leftTitles: AxisTitles(
                                                          sideTitles:
                                                              SideTitles(
                                                            showTitles: true,
                                                            reservedSize: 20,
                                                            getTitlesWidget:
                                                                (value, meta) {
                                                              return Text(
                                                                formatLargeNumber2(
                                                                    value
                                                                        .toInt()
                                                                        .toString()),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        7.5),
                                                              );
                                                            },
                                                          ),
                                                          */ /*axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets.only(top: 0.0),
                                                        child: Text(
                                                          'Sales',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight: FontWeight.w500,
                                                              color: Colors.black),
                                                        ),
                                                      ),*/ /*
                                                        ),
                                                      ),
                                                      minY: 0,
                                                      maxY: _selectedButton == 1
                                                          ? Constants
                                                              .moral_index_maxY
                                                              .toDouble()
                                                          : Constants
                                                              .moral_index_maxY2
                                                              .toDouble(),
                                                      borderData: FlBorderData(
                                                        show: true,
                                                        border: Border(
                                                          left: BorderSide.none,
                                                          bottom: BorderSide(
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.35),
                                                            width: 1,
                                                          ),
                                                          right:
                                                              BorderSide.none,
                                                          top: BorderSide.none,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Text(
                                                  "Weekend Sales are Added to / Accounted For On The Next Monday",
                                                  style: TextStyle(fontSize: 9),
                                                ),
                                              ],
                                            ),
                                )),
                          ))
                    else if (_selectedButton == 2)
                      Container(
                          height: 250,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Padding(
                                    padding: const EdgeInsets.all(14.0),
                                    child: moral_index_index == 0
                                        ? LineChart(
                                            key: Constants
                                                .moral_index_chartKey2a,
                                            LineChartData(
                                              lineBarsData: [
                                                LineChartBarData(
                                                  spots: Constants
                                                      .moral_index_spots2a,
                                                  isCurved: true,
                                                  barWidth: 3,
                                                  color: Colors.grey.shade400,
                                                  dotData: FlDotData(
                                                    show: true,
                                                    getDotPainter: (spot,
                                                        percent,
                                                        barData,
                                                        index) {
                                                      // Show custom dot and text for specific x-values

                                                      return FlDotCirclePainter(
                                                          radius: 2,
                                                          color: Colors.red,
                                                          strokeColor:
                                                              Colors.green);
                                                      */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                    },
                                                  ),
                                                ),
                                              ],
                                              minX: 1,
                                              maxX: 12,
                                              gridData: FlGridData(
                                                show: true,
                                                drawVerticalLine: false,
                                                getDrawingHorizontalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey
                                                        .withOpacity(0.10),
                                                    strokeWidth: 1,
                                                  );
                                                },
                                                getDrawingVerticalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey,
                                                    strokeWidth: 1,
                                                  );
                                                },
                                              ),
                                              titlesData: FlTitlesData(
                                                bottomTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    interval: 1,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(2.0),
                                                        child: Text(
                                                          getMonthAbbreviation(
                                                              value.toInt()),
                                                          style: TextStyle(
                                                              fontSize: 10),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                  axisNameWidget: const Padding(
                                                    padding: EdgeInsets.only(
                                                        top: 0.0),
                                                    child: Text(
                                                      'Months of the Year',
                                                      style: TextStyle(
                                                          fontSize: 11,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                ),
                                                topTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                rightTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                leftTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    reservedSize: 20,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(
                                                        formatLargeNumber2(value
                                                            .toInt()
                                                            .toString()),
                                                        style: TextStyle(
                                                            fontSize: 8),
                                                      );
                                                    },
                                                  ),
                                                  */ /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                ),
                                              ),
                                              minY: 0,
                                              maxY: Constants.moral_index_maxY2
                                                  .toDouble(),
                                              borderData: FlBorderData(
                                                show: true,
                                                border: Border(
                                                  left: BorderSide.none,
                                                  bottom: BorderSide(
                                                    color: Colors.grey
                                                        .withOpacity(0.35),
                                                    width: 1,
                                                  ),
                                                  right: BorderSide.none,
                                                  top: BorderSide.none,
                                                ),
                                              ),
                                            ),
                                          )
                                        : moral_index_index == 1
                                            ? LineChart(
                                                key: Constants
                                                    .moral_index_chartKey2b,
                                                LineChartData(
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .moral_index_spots2b,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  minX: 1,
                                                  maxX: 12,
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              getMonthAbbreviation(
                                                                  value
                                                                      .toInt()),
                                                              style: TextStyle(
                                                                  fontSize: 10),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Months of the Year',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber2(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 8),
                                                          );
                                                        },
                                                      ),
                                                      */ /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants
                                                      .moral_index_maxY2
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : LineChart(
                                                key: Constants
                                                    .moral_index_chartKey2c,
                                                LineChartData(
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .moral_index_spots2c,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  minX: 1,
                                                  maxX: 12,
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              getMonthAbbreviation(
                                                                  value
                                                                      .toInt()),
                                                              style: TextStyle(
                                                                  fontSize: 10),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Months of the Year',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber2(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 8),
                                                          );
                                                        },
                                                      ),
                                                      */ /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants
                                                      .moral_index_maxY2
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              ))),
                          ))
                    else if (_selectedButton == 3 && days_difference <= 31)
                      Container(
                          height: 250,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Padding(
                                    padding: const EdgeInsets.all(14.0),
                                    child: moral_index_index == 0
                                        ? LineChart(
                                            key: Constants
                                                .moral_index_chartKey3a,
                                            LineChartData(
                                              lineBarsData: [
                                                LineChartBarData(
                                                  spots: Constants
                                                      .moral_index_spots3a,
                                                  isCurved: true,
                                                  barWidth: 3,
                                                  color: Colors.grey.shade400,
                                                  dotData: FlDotData(
                                                    show: true,
                                                    getDotPainter: (spot,
                                                        percent,
                                                        barData,
                                                        index) {
                                                      // Show custom dot and text for specific x-values

                                                      return FlDotCirclePainter(
                                                          radius: 2,
                                                          color: Colors.red,
                                                          strokeColor:
                                                              Colors.green);
                                                      */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                    },
                                                  ),
                                                ),
                                              ],
                                              maxX:
                                                  noOfDaysThisMonth.toDouble(),
                                              gridData: FlGridData(
                                                show: true,
                                                drawVerticalLine: false,
                                                getDrawingHorizontalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey
                                                        .withOpacity(0.10),
                                                    strokeWidth: 1,
                                                  );
                                                },
                                                getDrawingVerticalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey,
                                                    strokeWidth: 1,
                                                  );
                                                },
                                              ),
                                              titlesData: FlTitlesData(
                                                bottomTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    interval: 1,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(2.0),
                                                        child: Text(
                                                          value
                                                              .toInt()
                                                              .toString(),
                                                          style: TextStyle(
                                                              fontSize: 7),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                  axisNameWidget: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 0.0),
                                                    child: Text(
                                                      'Days of the Month',
                                                      style: TextStyle(
                                                          fontSize: 11,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                ),
                                                topTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                rightTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                leftTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    reservedSize: 20,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(
                                                        formatLargeNumber2(value
                                                            .toInt()
                                                            .toString()),
                                                        style: TextStyle(
                                                            fontSize: 7.5),
                                                      );
                                                    },
                                                  ),
                                                  */ /*axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                ),
                                              ),
                                              minY: 0,
                                              minX: 0,
                                              maxY: Constants.moral_index_maxY3
                                                  .toDouble(),
                                              borderData: FlBorderData(
                                                show: true,
                                                border: Border(
                                                  left: BorderSide.none,
                                                  bottom: BorderSide(
                                                    color: Colors.grey
                                                        .withOpacity(0.35),
                                                    width: 1,
                                                  ),
                                                  right: BorderSide.none,
                                                  top: BorderSide.none,
                                                ),
                                              ),
                                            ),
                                          )
                                        : moral_index_index == 1
                                            ? LineChart(
                                                key: Constants
                                                    .moral_index_chartKey3b,
                                                LineChartData(
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .moral_index_spots3b,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  maxX: 12,
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              value
                                                                  .toInt()
                                                                  .toString(),
                                                              style: TextStyle(
                                                                  fontSize: 7),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Days of the Month',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber2(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 7.5),
                                                          );
                                                        },
                                                      ),
                                                      */ /*axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants
                                                      .moral_index_maxY3
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : LineChart(
                                                LineChartData(
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .moral_index_spots3c,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  maxX: noOfDaysThisMonth
                                                      .toDouble(),
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              value
                                                                  .toInt()
                                                                  .toString(),
                                                              style: TextStyle(
                                                                  fontSize: 7),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Days of the Month',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber2(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 7.5),
                                                          );
                                                        },
                                                      ),
                                                      */ /*axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants
                                                      .moral_index_maxY3
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              ))),
                          )),
                    if (_selectedButton == 3 && days_difference > 32)
                      Container(
                          height: 250,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Padding(
                                    padding: const EdgeInsets.all(14.0),
                                    child: moral_index_index == 0
                                        ? LineChart(
                                            LineChartData(
                                              lineBarsData: [
                                                LineChartBarData(
                                                  spots: Constants
                                                      .moral_index_spots4a,
                                                  isCurved: true,
                                                  barWidth: 3,
                                                  color: Colors.grey.shade400,
                                                  dotData: FlDotData(
                                                    show: true,
                                                    getDotPainter: (spot,
                                                        percent,
                                                        barData,
                                                        index) {
                                                      // Show custom dot and text for specific x-values

                                                      return FlDotCirclePainter(
                                                          radius: 2,
                                                          color: Colors.red,
                                                          strokeColor:
                                                              Colors.green);
                                                      */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                    },
                                                  ),
                                                ),
                                              ],
                                              maxX: 12,
                                              gridData: FlGridData(
                                                show: true,
                                                drawVerticalLine: false,
                                                getDrawingHorizontalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey
                                                        .withOpacity(0.10),
                                                    strokeWidth: 1,
                                                  );
                                                },
                                                getDrawingVerticalLine:
                                                    (value) {
                                                  return FlLine(
                                                    color: Colors.grey,
                                                    strokeWidth: 1,
                                                  );
                                                },
                                              ),
                                              titlesData: FlTitlesData(
                                                bottomTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    interval: 1,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(2.0),
                                                        child: Text(
                                                          getMonthAbbreviation(
                                                              value.toInt()),
                                                          style: TextStyle(
                                                              fontSize: 10),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                  axisNameWidget: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 0.0),
                                                    child: Text(
                                                      'Months of the Year',
                                                      style: TextStyle(
                                                          fontSize: 11,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                ),
                                                topTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                rightTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: false,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(value
                                                          .toInt()
                                                          .toString());
                                                    },
                                                  ),
                                                ),
                                                leftTitles: AxisTitles(
                                                  sideTitles: SideTitles(
                                                    showTitles: true,
                                                    reservedSize: 20,
                                                    getTitlesWidget:
                                                        (value, meta) {
                                                      return Text(
                                                        formatLargeNumber2(value
                                                            .toInt()
                                                            .toString()),
                                                        style: TextStyle(
                                                            fontSize: 8),
                                                      );
                                                    },
                                                  ),
                                                  */ /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                ),
                                              ),
                                              minY: 0,
                                              maxY: Constants.moral_index_maxY4
                                                  .toDouble(),
                                              borderData: FlBorderData(
                                                show: true,
                                                border: Border(
                                                  left: BorderSide.none,
                                                  bottom: BorderSide(
                                                    color: Colors.grey
                                                        .withOpacity(0.35),
                                                    width: 1,
                                                  ),
                                                  right: BorderSide.none,
                                                  top: BorderSide.none,
                                                ),
                                              ),
                                            ),
                                          )
                                        : moral_index_index == 1
                                            ? LineChart(
                                                LineChartData(
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .moral_index_spots4b,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              getMonthAbbreviation(
                                                                  value
                                                                      .toInt()),
                                                              style: TextStyle(
                                                                  fontSize: 10),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Months of the Year',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber2(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 8),
                                                          );
                                                        },
                                                      ),
                                                      */ /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/ /*
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants
                                                      .moral_index_maxY4
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : LineChart(
                                                LineChartData(
                                                  lineBarsData: [
                                                    LineChartBarData(
                                                      spots: Constants
                                                          .moral_index_spots4c,
                                                      isCurved: true,
                                                      barWidth: 3,
                                                      color:
                                                          Colors.grey.shade400,
                                                      dotData: FlDotData(
                                                        show: true,
                                                        getDotPainter: (spot,
                                                            percent,
                                                            barData,
                                                            index) {
                                                          // Show custom dot and text for specific x-values

                                                          return FlDotCirclePainter(
                                                              radius: 2,
                                                              color: Colors.red,
                                                              strokeColor:
                                                                  Colors.green);
                                                          */ /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/ /*
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                  gridData: FlGridData(
                                                    show: true,
                                                    drawVerticalLine: false,
                                                    getDrawingHorizontalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey
                                                            .withOpacity(0.10),
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                    getDrawingVerticalLine:
                                                        (value) {
                                                      return FlLine(
                                                        color: Colors.grey,
                                                        strokeWidth: 1,
                                                      );
                                                    },
                                                  ),
                                                  titlesData: FlTitlesData(
                                                    bottomTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        interval: 1,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(2.0),
                                                            child: Text(
                                                              getMonthAbbreviation(
                                                                  value
                                                                      .toInt()),
                                                              style: TextStyle(
                                                                  fontSize: 10),
                                                            ),
                                                          );
                                                        },
                                                      ),
                                                      axisNameWidget: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 0.0),
                                                        child: Text(
                                                          'Months of the Year',
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                    topTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    rightTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: false,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(value
                                                              .toInt()
                                                              .toString());
                                                        },
                                                      ),
                                                    ),
                                                    leftTitles: AxisTitles(
                                                      sideTitles: SideTitles(
                                                        showTitles: true,
                                                        reservedSize: 20,
                                                        getTitlesWidget:
                                                            (value, meta) {
                                                          return Text(
                                                            formatLargeNumber2(
                                                                value
                                                                    .toInt()
                                                                    .toString()),
                                                            style: TextStyle(
                                                                fontSize: 8),
                                                          );
                                                        },
                                                      ),
                                                      */
                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                    /*
                                                    ),
                                                  ),
                                                  minY: 0,
                                                  maxY: Constants
                                                      .moral_index_maxY4
                                                      .toDouble(),
                                                  borderData: FlBorderData(
                                                    show: true,
                                                    border: Border(
                                                      left: BorderSide.none,
                                                      bottom: BorderSide(
                                                        color: Colors.grey
                                                            .withOpacity(0.35),
                                                        width: 1,
                                                      ),
                                                      right: BorderSide.none,
                                                      top: BorderSide.none,
                                                    ),
                                                  ),
                                                ),
                                              ))),
                          )),*/

                    _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 12),
                            child: Text(
                                "Moral Index By Type (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Moral Index By Type (YTD - ${DateTime.now().year})"),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Moral Index By Type (${Constants.moral_index_formattedStartDate} to ${Constants.moral_index_formattedEndDate})"),
                              ),
                    Container(
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: _selectedButton == 1
                            ? Constants.moral_index_groupedChartData1.length
                            : _selectedButton == 2
                                ? Constants.moral_index_droupedChartData2.length
                                : _selectedButton == 3 && days_difference <= 3
                                    ? Constants
                                        .moral_index_droupedChartData3.length
                                    : Constants
                                        .moral_index_droupedChartData4.length,
                        itemBuilder: (context, index) {
                          MoraleIndexCategory category =
                              MoraleIndexCategory(name: '', items: []);
                          if (_selectedButton == 1) {
                            category =
                                Constants.moral_index_groupedChartData1[index];
                          } else if (_selectedButton == 2) {
                            category =
                                Constants.moral_index_droupedChartData2[index];
                          } else if (_selectedButton == 3 &&
                              days_difference <= 31) {
                            category =
                                Constants.moral_index_droupedChartData3[index];
                          } else {
                            category =
                                Constants.moral_index_droupedChartData4[index];
                          }

                          final totalCategoryCount = category.getTotalCount();

                          return Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(17),
                                  border: Border.all(
                                      color: Colors.grey.withOpacity(0.1))),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(16.5),
                                child: ListTileTheme(
                                  dense: true,
                                  minVerticalPadding: 0,
                                  child: ExpansionTile(
                                    childrenPadding:
                                        EdgeInsets.only(top: 0, bottom: 0),
                                    tilePadding: EdgeInsets.only(
                                        top: 0, bottom: 0, left: 8, right: 8),
                                    initiallyExpanded: true,
                                    backgroundColor:
                                        Colors.grey.withOpacity(0.35),
                                    collapsedBackgroundColor:
                                        Colors.grey.withOpacity(0.35),
                                    trailing: Container(
                                      width: 80,
                                      child: Stack(
                                        children: [
                                          Container(
                                            height: 16,
                                            child: LinearProgressIndicator(
                                              value: 1,
                                              backgroundColor:
                                                  Colors.grey.withOpacity(0.3),
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                      Colors.blue),
                                            ),
                                          ),
                                          Container(
                                            height: 16,
                                            child: Row(
                                              children: [
                                                Spacer(),
                                                Text(
                                                  formatLargeNumber3(
                                                      totalCategoryCount
                                                          .toString()),
                                                  style: TextStyle(
                                                      fontSize: 11,
                                                      color: Colors.white),
                                                ),
                                                Spacer(),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    collapsedShape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(16)),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(16)),
                                    title: Text(
                                      category.name
                                          .replaceAll("Self", "Main Member"),
                                      style: TextStyle(fontSize: 14),
                                    ),
                                    children: category.items.map((item) {
                                      double percentage =
                                          item.count / totalCategoryCount;
                                      return Container(
                                        color: Colors.white,
                                        child: ListTile(
                                          dense: true,
                                          visualDensity: VisualDensity(
                                              horizontal: 0, vertical: -4),
                                          minLeadingWidth: 0,
                                          horizontalTitleGap: 0,
                                          contentPadding: EdgeInsets.only(
                                              left: 8, right: 8),
                                          minVerticalPadding: 0,
                                          selectedColor: Colors.white,
                                          selectedTileColor: Colors.white,
                                          tileColor: Colors.white,
                                          splashColor: Colors.white,
                                          title: Text(
                                            item.title,
                                            style: TextStyle(fontSize: 14),
                                          ),
                                          trailing: SizedBox(
                                            width: 80,
                                            height: 16,
                                            child: Stack(
                                              children: [
                                                Container(
                                                  height: 16,
                                                  child:
                                                      LinearProgressIndicator(
                                                    value: percentage,
                                                    backgroundColor: Colors.grey
                                                        .withOpacity(0.3),
                                                    valueColor:
                                                        AlwaysStoppedAnimation<
                                                            Color>(Colors.blue),
                                                  ),
                                                ),
                                                Container(
                                                  height: 16,
                                                  child: Row(
                                                    children: [
                                                      Spacer(),
                                                      Text(
                                                        formatLargeNumber3(item
                                                            .count
                                                            .toString()),
                                                        style: TextStyle(
                                                            fontSize: 11,
                                                            color: percentage <
                                                                    0.50
                                                                ? Colors.black
                                                                : Colors.white),
                                                      ),
                                                      Spacer(),
                                                    ],
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  getMood(String date) async {
    var headers = {
      'Cookie':
          'userid=expiry=2023-12-28&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=379&empid=9819&empfirstname=Everest&emplastname=Everest&email=Master@everestmpu.com&username=Master@everestmpu.com&dob=7/7/1990 12:00:00 AM&fullname=Everest Everest&userRole=184&userImage=Master@everestmpu.com.jpg&employedAt=head office 1&role=leader&branchid=379&jobtitle=Policy Administrator / Agent&dialing_strategy=&clientname=Everest Financial Services&foldername=&client_abbr=EV&pbx_account=&device_id=&servername=http://localhost:55661'
    };
    var request = http.Request(
        'GET',
        Uri.parse(
            'https://miinsightsapps.net/Communication_Engine/GetStatusStats?StartDate=2023-12-11&EndDate=2023-12-11&EventId=0'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());
    } else {
      print(response.reasonPhrase);
    }
  }

  getMood1(String date) async {
    try {
      var headers = {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        'Cookie':
            "userid=expiry=2023-12-28&client_modules=1001#1002#1003#1004#1005#1006#1007#1008#1009#1010#1011#1012#1013#1014#1015#1017#1018#1020#1021#1022#1024#1025#1026#1027#1028#1029#1030#1031#1032#1033#1034#1035&clientid=379&empid=9819&empfirstname=Everest&emplastname=Everest&email=Master@everestmpu.com&username=Master@everestmpu.com&dob=7/7/1990 12:00:00 AM&fullname=Everest Everest&userRole=184&userImage=Master@everestmpu.com.jpg&employedAt=head office 1&role=leader&branchid=379&jobtitle=Policy Administrator / Agent&dialing_strategy=&clientname=Everest Financial Services&foldername=&client_abbr=EV&pbx_account=&device_id=&servername=http://localhost:55661"
      };
      var request = http.get(
          Uri.parse(
              'https://miinsightsapps.net/hr/countUsersMoods?clientId=379&dateToday=2023-12-11'),
          headers: headers);
      request.then((response) {
        print(request);

        if (response.statusCode == 200) {
          String responseBody = response.body.toString();

          Map<dynamic, dynamic> responseMap = jsonDecode(responseBody);

          int marker_id = 1;

          responseMap["user_moods"].forEach((value1) {
            //Map m1 = value as Map;
            List<dynamic> m1 = value1 as List<dynamic>;
            print(m1);
          });

          setState(() {});
        } else {
          print("fgh " + response.reasonPhrase.toString());
        }
      });
    } on Exception catch (e) {
      print("fggg " + e.toString());
    }
  }

  @override
  void initState() {
    secureScreen();
    myNotifier = MyNotifier(maintenanceValue, context);
    maintenanceValue.addListener(() {
      setState(() {});
    });
    //getMood1("");
    DateTime now = DateTime.now();
    DateTime startDate = DateTime(now.year, now.month, 1);
    DateTime endDate = DateTime.now();

    DateTime firstDayNextMonth;

// Check if this month is December, then the next month is January of next year
    if (now.month == 12) {
      firstDayNextMonth = DateTime(now.year + 1, 1, 1);
    } else {
      firstDayNextMonth = DateTime(now.year, now.month + 1, 1);
    }

    DateTime lastDayThisMonth = firstDayNextMonth.subtract(Duration(days: 1));
    noOfDaysThisMonth = lastDayThisMonth.day;

    _animateButton(1);
    Constants.moral_index_formattedStartDate =
        DateFormat('yyyy-MM-dd').format(startDate!);
    Constants.moral_index_formattedEndDate =
        DateFormat('yyyy-MM-dd').format(endDate!);
    setState(() {});

    String dateRange =
        '${Constants.moral_index_formattedStartDate} - ${Constants.moral_index_formattedEndDate}';
    print("currently loading ${dateRange}");
    DateTime startDateTime = DateFormat('yyyy-MM-dd')
        .parse(Constants.moral_index_formattedStartDate);
    DateTime endDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.moral_index_formattedEndDate);

    days_difference = endDateTime.difference(startDateTime).inDays;
    if (kDebugMode) {
      print("days_difference ${days_difference}");
      print("formattedEndDate9 ${Constants.moral_index_formattedEndDate}");
    }

    setState(() {});
    // getSalesReport(context, formattedStartDate, formattedEndDate);

    super.initState();
  }

  FlTitlesData getTitlesData(List<String> bottomTitles) {
    return FlTitlesData(
      show: true,
      topTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: false,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: Text(
                _selectedButton == 1
                    ? Constants
                        .moral_index_salesbybranch1a[index - 1].branch_name
                    : Constants
                        .moral_index_salesbybranch2a[index - 1].branch_name,
                maxLines: 1,
                style: TextStyle(color: Colors.black, fontSize: 12),
              ),
            );
          },
        ),
      ),
      leftTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          reservedSize: 100,
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: RotatedBox(
                quarterTurns: -1,
                child: Text(
                  bottomTitles[index - 1],
                  maxLines: 2,
                  textAlign: TextAlign.right,
                  style: TextStyle(color: Colors.black, fontSize: 12),
                ),
              ),
            );
          },
        ),
      ),
      rightTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: false,
          getTitlesWidget: (double value, TitleMeta meta) {
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 6.0,
              child: RotatedBox(
                quarterTurns: -1,
                child: Text(
                  value.toInt().toString(),
                  style: TextStyle(color: Colors.black),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  FlTitlesData getTitlesData2(List<String> bottomTitles) {
    return FlTitlesData(
      show: true,
      topTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      rightTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: Text(
                bottomTitles[index - 1],
                style: TextStyle(color: Colors.white),
              ),
            );
          },
        ),
      ),
      leftTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 6.0,
              child: Text(
                value.toInt().toString(),
                style: TextStyle(color: Colors.white),
              ),
            );
          },
        ),
      ),
    );
  }
}

class Indicator extends StatelessWidget {
  const Indicator({
    super.key,
    required this.color,
    required this.text,
    required this.isSquare,
    this.size = 16,
    this.textColor,
  });
  final Color color;
  final String text;
  final bool isSquare;
  final double size;
  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: Row(
        children: <Widget>[
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(360),
              shape: isSquare ? BoxShape.rectangle : BoxShape.circle,
              color: color,
            ),
          ),
          const SizedBox(
            width: 4,
          ),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w300,
                color: textColor,
              ),
            ),
          )
        ],
      ),
    );
  }
}

class CustomDotPainter extends FlDotPainter {
  final double yValue;
  final double xValue;
  final double maxX; // Maximum X-value of the chart
  final double maxY; // Maximum Y-value of the chart
  final double chartWidth; // Width of the chart
  final double chartHeight; // Height of the chart

  CustomDotPainter({
    required this.yValue,
    required this.xValue,
    required this.maxX,
    required this.maxY,
    required this.chartWidth,
    required this.chartHeight,
  });

  @override
  void paint(Canvas canvas, Size size, FlSpot spot, double xPercent,
      double yPercent, LineChartBarData bar, int index) {
    // Calculate the position based on chart dimensions and spot's value
    double xPosition = (xValue / maxX) * chartWidth;
    double yPosition =
        chartHeight - (yValue / Constants.moral_index_maxY) * chartHeight;

    // Paint the dot
    final paint = Paint()..color = Constants.ctaColorLight;
    canvas.drawCircle(Offset(xPosition, yPosition), size.width / 2, paint);

    // Draw the text
    TextSpan span = TextSpan(
        style: TextStyle(color: Colors.black), text: yValue.round().toString());
    TextPainter tp = TextPainter(
        text: span,
        textAlign: TextAlign.center,
        textDirection: ui.TextDirection.ltr);
    tp.layout();

    // Adjust the position to paint the text
    double textX = xPosition - tp.width / 2;
    double textY = yPosition - tp.height - 10;

    // Paint the text
    tp.paint(canvas, Offset(textX, textY));
  }

  @override
  void draw(Canvas canvas, FlSpot spot, Offset offsetInCanvas) {
    paint(canvas, getSize(spot), spot, 0, 0,
        LineChartBarData(color: Colors.blue), 0); // Example call
  }

  @override
  Size getSize(FlSpot spot) {
    // Return the size of your dot
    return const Size(12, 12); // Example size, adjust as needed
  }

  @override
  List<Object?> get props => [yValue];
}

String formatWithCommasB(double value) {
  final format = NumberFormat("#,##0", "en_US"); // Updated pattern
  return format.format(value);
}

String formatLargeNumberB(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 1000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatLargeNumber2B(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 1000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatWithCommas(double value) {
  final format = NumberFormat("#,##0", "en_US"); // Updated pattern
  return format.format(value);
}

String formatLargeNumber(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 1000000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatLargeNumber2(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 100000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String getMonthAbbreviation(int monthNumber) {
  List<String> months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];

  // Check if the month number is valid
  if (monthNumber < 1 || monthNumber > 12) {
    return "-";
  }

  // Return the corresponding month abbreviation
  return months[monthNumber - 1];
}

class CategoryItem {
  String title;
  int count;

  CategoryItem({required this.title, required this.count});
}

class Category {
  String name;
  List<CategoryItem> items;

  Category({required this.name, required this.items});
}

String formatWithCommas3(double value, [bool forceDecimal = false]) {
  bool isNegative = value < 0;
  double absValue = value.abs();

  final format = absValue < 1000000 && !forceDecimal
      ? NumberFormat("#,##0", "en_US")
      : NumberFormat("#,##0.00", "en_US");

  // Format the number and add back the negative sign if necessary
  return isNegative ? "-${format.format(absValue)}" : format.format(absValue);
}

String formatLargeNumber3(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  bool isNegative = value < 0; // Check if the number is negative
  value = value.abs(); // Work with the absolute value

  // If the value is less than a million, return it with commas
  if (value < 1000000) {
    return isNegative
        ? "-${formatWithCommas3(value)}"
        : formatWithCommas3(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  // Force decimal places for large numbers with suffixes
  return isNegative
      ? "-${formatWithCommas3(newValue, true)}${suffixes[index]}"
      : "${formatWithCommas3(newValue, true)}${suffixes[index]}";
}

class MoraleTypeGrid extends StatelessWidget {
  final List<Map<String, dynamic>> collectionTypes = [
    {'type': 'Cash', 'color': Colors.blue},
    {'type': 'EFT', 'color': Colors.purple},
    {'type': 'Easypay', 'color': Colors.green},
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0, right: 16),
      child: Container(
        child: GridView.builder(
          shrinkWrap: true,
          padding: const EdgeInsets.all(0),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 6, // Number of columns
            crossAxisSpacing: 0, // Horizontal space between cards
            mainAxisSpacing: 0, // Vertical space between cards
            childAspectRatio: 1, // Aspect ratio of the cards
          ),
          itemCount: 3,
          itemBuilder: (context, index) {
            return;
          },
        ),
      ),
    );
  }
}
