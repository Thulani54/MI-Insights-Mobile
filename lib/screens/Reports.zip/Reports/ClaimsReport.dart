import 'dart:ui' as ui;

import 'package:circular_chart_flutter/circular_chart_flutter.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:mi_insights/constants/Constants.dart';

import '../../customwidgets/custom_date_range_picker.dart';
import '../../services/MyNoyifier.dart';
import '../../services/claims_service.dart';
import '../../services/window_manager.dart';

int noOfDaysThisMonth = 30;
bool isLoading = false;
final claimsValue = ValueNotifier<int>(0);
double totalAmount = 0;
MyNotifier? myNotifier;
DateTime datefrom = DateTime.now().subtract(Duration(days: 60));
DateTime dateto = DateTime.now();
int days_difference = 0;

int report_index = 0;
int claims_index = 0;
String data2 = "";

int touchedIndex = -1;

class ClaimsReport extends StatefulWidget {
  const ClaimsReport({Key? key}) : super(key: key);

  @override
  State<ClaimsReport> createState() => _ClaimsReportState();
}

List<Map<String, dynamic>> leads = [];
List<List<Map<String, dynamic>>> policies = [];
double _sliderPosition = 0.0;
int _selectedButton = 1;

class _ClaimsReportState extends State<ClaimsReport> {
  Color _button1Color = Colors.grey.withOpacity(0.0);
  Color _button2Color = Colors.grey.withOpacity(0.0);
  Color _button3Color = Colors.grey.withOpacity(0.0);

  void _animateButton(int buttonNumber) {
    DateTime? startDate = DateTime.now();
    DateTime? endDate = DateTime.now();
    leads = [];

    setState(() {});

    print("jhhh " + buttonNumber.toString());
    _selectedButton = buttonNumber;
    if (buttonNumber == 1)
      _sliderPosition = 0.0;
    else if (buttonNumber == 2)
      _sliderPosition = (MediaQuery.of(context).size.width / 3) - 18;
    else if (buttonNumber == 3)
      _sliderPosition = 2 * (MediaQuery.of(context).size.width / 3) - 32;
    setState(() {});
    if (buttonNumber != 3) {
      setState(() {
        // Update colors
        _button1Color = buttonNumber == 1
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);
        _button2Color = buttonNumber == 2
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);
        _button3Color = buttonNumber == 3
            ? Constants.ctaColorLight
            : Colors.grey.withOpacity(0.0);

        // Update slider position based on the button tapped
      });
      DateTime now = DateTime.now();

      setState(() {});
    } else {
      showCustomDateRangePicker(
        context,
        dismissible: true,
        minimumDate: DateTime.now().subtract(const Duration(days: 360)),
        maximumDate: DateTime.now().add(Duration(days: 360)),
        /*    endDate: endDate,
        startDate: startDate,*/
        backgroundColor: Colors.white,
        primaryColor: Constants.ctaColorLight,
        onApplyClick: (start, end) {
          setState(() {
            endDate = end;
            startDate = start;
          });

          Constants.claims_formattedStartDate =
              DateFormat('yyyy-MM-dd').format(startDate!);
          Constants.claims_formattedEndDate =
              DateFormat('yyyy-MM-dd').format(endDate!);
          setState(() {});

          String dateRange =
              '${Constants.claims_formattedStartDate} - ${Constants.claims_formattedEndDate}';
          print("currently loading ${dateRange}");
          DateTime startDateTime = DateFormat('yyyy-MM-dd')
              .parse(Constants.claims_formattedStartDate);
          DateTime endDateTime =
              DateFormat('yyyy-MM-dd').parse(Constants.claims_formattedEndDate);

          days_difference = endDateTime.difference(startDateTime).inDays;
          if (kDebugMode) {
            print("days_difference ${days_difference}");
            print("formattedEndDate9fgfg ${Constants.claims_formattedEndDate}");
          }
          getClaimsReport(Constants.claims_formattedStartDate,
              Constants.claims_formattedEndDate, 3, context);
          isLoading = true;
          setState(() {});
        },
        onCancelClick: () {
          setState(() {
            // endDate = null;
            //  startDate = null;
          });
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
            elevation: 6,
            leading: InkWell(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.black,
                )),
            backgroundColor: Colors.white,
            centerTitle: true,
            title: const Text(
              "Claims Report (Dummy Data)",
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            )),
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              SizedBox(
                height: 12,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(36)),
                  child: Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(36)),
                        child: Center(
                          child: Row(
                            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  _animateButton(1);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  height: 35,
                                  child: Center(
                                    child: Text(
                                      '1 Mth View',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  _animateButton(2);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  child: Center(
                                    child: Text(
                                      '12 Mths View',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  //    _animateButton(3);
                                  Fluttertoast.showToast(
                                      msg: "Currently Unavailable",
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.CENTER,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: Colors.red,
                                      textColor: Colors.white,
                                      fontSize: 16.0);
                                },
                                child: Container(
                                  width:
                                      (MediaQuery.of(context).size.width / 3) -
                                          12,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(360)),
                                  child: Center(
                                    child: Text(
                                      'Select Dates',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      AnimatedPositioned(
                        duration: Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        left: _sliderPosition,
                        child: InkWell(
                          onTap: () {
                            _animateButton(3);
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width / 3,
                            height: 35,
                            decoration: BoxDecoration(
                              color: Constants
                                  .ctaColorLight, // Color of the slider
                              borderRadius: BorderRadius.circular(36),
                            ),
                            child: _selectedButton == 1
                                ? Center(
                                    child: Text(
                                      '1 Mth View',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  )
                                : _selectedButton == 2
                                    ? Center(
                                        child: Text(
                                          '12 Mths View',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      )
                                    : Center(
                                        child: Text(
                                          'Select Dates',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              isLoading
                  ? Center(
                      child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: Constants.ctaColorLight,
                            strokeWidth: 1.8,
                          ),
                        ),
                      ),
                    ))
                  : Container(),
              Padding(
                padding: const EdgeInsets.only(left: 20.0, right: 20, top: 12),
                child: Container(
                  height: 1,
                  color: Colors.grey.withOpacity(0.35),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    if (isLoading)
                      SizedBox(
                        height: 12,
                      ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 16.0, right: 16, top: 16),
                      child: Row(
                        children: [
                          Spacer(),
                          Text(
                            "PAID CLAIMS ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Container(
                              width: 100,
                              decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(8)),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 4.0, bottom: 4),
                                child: Center(
                                  child: Text(
                                    "R" +
                                        formatLargeNumber(_selectedButton == 1
                                            ? Constants
                                                .claims_paid_claims_amount1a
                                                .toStringAsFixed(2)
                                            : _selectedButton == 2
                                                ? Constants
                                                    .claims_paid_claims_amount2a
                                                    .toStringAsFixed(2)
                                                : (_selectedButton == 3 &&
                                                        days_difference <= 31)
                                                    ? Constants
                                                        .claims_paid_claims_amount3a
                                                        .toStringAsFixed(2)
                                                    : Constants
                                                        .claims_paid_claims_amount3b
                                                        .toStringAsFixed(2)),
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ))
                        ],
                      ),
                    ),
                    /*     _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0),
                            child: Text(
                                "Paid Claims (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding: const EdgeInsets.only(left: 16.0),
                                child: Text(
                                    "Paid Claims (YTD - ${DateTime.now().year})"),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(left: 16.0),
                                child: Text(
                                    "Paid Claims (${Constants.sales_formattedStartDate} to ${Constants.sales_formattedEndDate})"),
                              ),*/
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            childAspectRatio:
                                MediaQuery.of(context).size.width /
                                    (MediaQuery.of(context).size.height / 1.9)),
                        itemCount: _selectedButton == 1
                            ? Constants.claims_sectionsList1a.length
                            : _selectedButton == 2
                                ? Constants.claims_sectionsList2a.length
                                : _selectedButton == 3 && days_difference <= 31
                                    ? Constants.claims_sectionsList3a.length
                                    : Constants.claims_sectionsList3b.length,
                        padding: EdgeInsets.all(2.0),
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                              onTap: () {},
                              child: Container(
                                height: 290,
                                width: MediaQuery.of(context).size.width / 2.9,
                                child: Stack(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        // sales_index = index;
                                        setState(() {});
                                        if (kDebugMode) {
                                          print("sales_index " +
                                              index.toString());
                                        }
                                        if (index == 1) {
                                          /*     Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) => SalesReport()));*/
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            bottom: 4.0, right: 8),
                                        child: Card(
                                          elevation: 6,
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            side: BorderSide(
                                                color: Colors.white70,
                                                width: 0),
                                            borderRadius:
                                                BorderRadius.circular(16),
                                          ),
                                          child: ClipPath(
                                            clipper: ShapeBorderClipper(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16))),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: index < 3
                                                              ? Colors.green
                                                              : Colors.orangeAccent[
                                                                  400]!,
                                                          width: 6))),
                                              child: Column(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors.grey
                                                              .withOpacity(
                                                                  0.05),
                                                          border: Border.all(
                                                              color: Colors.grey
                                                                  .withOpacity(
                                                                      0.0)),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8)),
                                                      child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        14),
                                                          ),
                                                          width: MediaQuery.of(
                                                                  context)
                                                              .size
                                                              .width,
                                                          height: 270,
                                                          /*     decoration: BoxDecoration(
                                                          color:Colors.white,
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                          border: Border.all(
                                                              width: 1,
                                                              color: Colors
                                                                  .grey.withOpacity(0.2))),*/
                                                          margin:
                                                              EdgeInsets.only(
                                                                  right: 0,
                                                                  left: 0,
                                                                  bottom: 4),
                                                          child: Column(
                                                            children: [
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        8.0),
                                                                child: Text(
                                                                  "R" +
                                                                      formatLargeNumber((_selectedButton == 1
                                                                              ? Constants.claims_sectionsList1a_1[index].amount.toString()
                                                                              : _selectedButton == 2
                                                                                  ? Constants.claims_sectionsList2a_1[index].amount
                                                                                  : _selectedButton == 3 && days_difference <= 31
                                                                                      ? Constants.claims_sectionsList3a_1[index].amount
                                                                                      : Constants.claims_sectionsList3b_1[index].amount)
                                                                          .toString()),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          18.5,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 2,
                                                                ),
                                                              )),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        left:
                                                                            8.0,
                                                                        right:
                                                                            8,
                                                                        top: 0),
                                                                child: Text(
                                                                  (_selectedButton ==
                                                                              1
                                                                          ? Constants
                                                                              .claims_sectionsList1a[index]
                                                                              .amount
                                                                              .toString()
                                                                          : _selectedButton == 2
                                                                              ? Constants.claims_sectionsList2a[index].amount
                                                                              : _selectedButton == 3 && days_difference <= 31
                                                                                  ? Constants.claims_sectionsList3a[index].amount
                                                                                  : Constants.claims_sectionsList3b[index].amount)
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 2,
                                                                ),
                                                              )),
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        0.0),
                                                                child: Text(
                                                                  _selectedButton ==
                                                                          1
                                                                      ? Constants
                                                                          .claims_sectionsList1a[
                                                                              index]
                                                                          .id
                                                                      : _selectedButton ==
                                                                              2
                                                                          ? Constants
                                                                              .claims_sectionsList2a[
                                                                                  index]
                                                                              .id
                                                                          : Constants
                                                                              .claims_sectionsList3a[index]
                                                                              .id,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          12.5),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 1,
                                                                ),
                                                              )),
                                                            ],
                                                          )),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ));
                        },
                      ),
                    ),
                    _selectedButton == 1
                        ? Padding(
                            padding: const EdgeInsets.only(left: 16.0, top: 12),
                            child: Text(
                                "Claims Ratio (MTD - ${getMonthAbbreviation(DateTime.now().month)})"),
                          )
                        : _selectedButton == 2
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Claims Ratio (YTD - ${DateTime.now().year})"),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16.0, top: 12),
                                child: Text(
                                    "Claims Ratio (${Constants.sales_formattedStartDate} to ${Constants.sales_formattedEndDate})"),
                              ),
                    _selectedButton == 1
                        ? Row(
                            children: [
                              Spacer(),
                              AnimatedCircularChart(
                                key: UniqueKey(),
                                size: Size(
                                    MediaQuery.of(context).size.width * 0.7,
                                    MediaQuery.of(context).size.width * 0.7),
                                initialChartData: <CircularStackEntry>[
                                  CircularStackEntry(
                                    <CircularSegmentEntry>[
                                      CircularSegmentEntry(
                                        Constants.claims_ratio1a,
                                        Colors.indigo,
                                        rankKey: 'completed',
                                      ),
                                      CircularSegmentEntry(
                                        100.0 - Constants.claims_ratio1a,
                                        Colors.blue.withOpacity(0.3),
                                        rankKey: 'remaining',
                                      ),
                                    ],
                                    rankKey: 'progress',
                                  ),
                                ],
                                chartType: CircularChartType.Radial,
                                edgeStyle: SegmentEdgeStyle.flat,
                                startAngle: 3,
                                holeRadius:
                                    MediaQuery.of(context).size.width * 0.18,
                                percentageValues: true,
                                holeLabel: '${Constants.claims_ratio1a}%',
                                labelStyle: new TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 17.0,
                                ),
                              ),
                              Spacer(),
                            ],
                          )
                        : _selectedButton == 2
                            ? Row(
                                children: [
                                  Spacer(),
                                  AnimatedCircularChart(
                                    key: UniqueKey(),
                                    size: Size(
                                        MediaQuery.of(context).size.width * 0.7,
                                        MediaQuery.of(context).size.width *
                                            0.7),
                                    initialChartData: <CircularStackEntry>[
                                      CircularStackEntry(
                                        <CircularSegmentEntry>[
                                          CircularSegmentEntry(
                                            Constants.claims_ratio2a,
                                            Colors.indigo,
                                            rankKey: 'completed',
                                          ),
                                          CircularSegmentEntry(
                                            100.0 - Constants.claims_ratio2a,
                                            Colors.blue.withOpacity(0.3),
                                            rankKey: 'remaining',
                                          ),
                                        ],
                                        rankKey: 'progress',
                                      ),
                                    ],
                                    chartType: CircularChartType.Radial,
                                    edgeStyle: SegmentEdgeStyle.flat,
                                    startAngle: 3,
                                    holeRadius:
                                        MediaQuery.of(context).size.width *
                                            0.18,
                                    percentageValues: true,
                                    holeLabel: '${Constants.claims_ratio2a}%',
                                    labelStyle: new TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 17.0,
                                    ),
                                  ),
                                  Spacer(),
                                ],
                              )
                            : _selectedButton == 3 && days_difference <= 31
                                ? Row(
                                    children: [
                                      Spacer(),
                                      AnimatedCircularChart(
                                        key: UniqueKey(),
                                        size: Size(
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                            MediaQuery.of(context).size.width *
                                                0.7),
                                        initialChartData: <CircularStackEntry>[
                                          CircularStackEntry(
                                            <CircularSegmentEntry>[
                                              CircularSegmentEntry(
                                                double.parse(Constants
                                                    .claims_ratio2a
                                                    .toStringAsFixed(2)),
                                                Colors.indigo,
                                                rankKey: 'completed',
                                              ),
                                              CircularSegmentEntry(
                                                100.0 -
                                                    double.parse(Constants
                                                        .claims_ratio2a
                                                        .toStringAsFixed(2)),
                                                Colors.blue.withOpacity(0.3),
                                                rankKey: 'remaining',
                                              ),
                                            ],
                                            rankKey: 'progress',
                                          ),
                                        ],
                                        chartType: CircularChartType.Radial,
                                        edgeStyle: SegmentEdgeStyle.flat,
                                        startAngle: 3,
                                        holeRadius:
                                            MediaQuery.of(context).size.width *
                                                0.18,
                                        percentageValues: true,
                                        holeLabel:
                                            '${double.parse(Constants.claims_ratio2a.toStringAsFixed(2))}%',
                                        labelStyle: new TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 17.0,
                                        ),
                                      ),
                                      Spacer(),
                                    ],
                                  )
                                : Row(
                                    children: [
                                      Spacer(),
                                      AnimatedCircularChart(
                                        key: UniqueKey(),
                                        size: Size(
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                            MediaQuery.of(context).size.width *
                                                0.7),
                                        initialChartData: <CircularStackEntry>[
                                          CircularStackEntry(
                                            <CircularSegmentEntry>[
                                              CircularSegmentEntry(
                                                Constants.claims_ratio1a,
                                                Colors.indigo,
                                                rankKey: 'completed',
                                              ),
                                              CircularSegmentEntry(
                                                100.0 -
                                                    Constants.claims_ratio1a,
                                                Colors.blue.withOpacity(0.3),
                                                rankKey: 'remaining',
                                              ),
                                            ],
                                            rankKey: 'progress',
                                          ),
                                        ],
                                        chartType: CircularChartType.Radial,
                                        edgeStyle: SegmentEdgeStyle.flat,
                                        startAngle: 3,
                                        holeRadius:
                                            MediaQuery.of(context).size.width *
                                                0.18,
                                        percentageValues: true,
                                        holeLabel:
                                            '${Constants.claims_ratio1a}%',
                                        labelStyle: new TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 17.0,
                                        ),
                                      ),
                                      Spacer(),
                                    ],
                                  ),
                    Padding(
                      padding: const EdgeInsets.only(left: 16.0, top: 12),
                      child: Text(
                          "Claims Ratio Rolling 12 Months View - ${DateTime.now().year})"),
                    ),
                    ClaimsReportGraph2(),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 16.0, right: 16, top: 16),
                      child: Row(
                        children: [
                          Spacer(),
                          Text(
                            "NOT YET PAID ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Container(
                              width: 100,
                              decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(8)),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 4.0, bottom: 4),
                                child: Center(
                                  child: Text(
                                    "R" +
                                        formatLargeNumber(_selectedButton == 1
                                            ? Constants
                                                .claims_outstanding_claims_amount1a
                                                .toStringAsFixed(2)
                                            : _selectedButton == 2
                                                ? Constants
                                                    .claims_paid_claims_amount1b
                                                    .toStringAsFixed(2)
                                                : (_selectedButton == 3 &&
                                                        days_difference <= 31)
                                                    ? Constants
                                                        .claims_paid_claims_amount1c
                                                        .toStringAsFixed(2)
                                                    : Constants
                                                        .claims_paid_claims_amount1d
                                                        .toStringAsFixed(2)),
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ))
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            childAspectRatio:
                                MediaQuery.of(context).size.width /
                                    (MediaQuery.of(context).size.height / 1.9)),
                        itemCount: _selectedButton == 1
                            ? Constants.claims_sectionsList1b_1.length
                            : _selectedButton == 2
                                ? Constants.claims_sectionsList2b.length
                                : _selectedButton == 3 && days_difference <= 31
                                    ? Constants.claims_sectionsList2c.length
                                    : Constants.claims_sectionsList2d.length,
                        padding: EdgeInsets.all(2.0),
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                              onTap: () {},
                              child: Container(
                                height: 290,
                                width: MediaQuery.of(context).size.width / 2.9,
                                child: Stack(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        // sales_index = index;
                                        setState(() {});
                                        if (kDebugMode) {
                                          print("sales_index " +
                                              index.toString());
                                        }
                                        if (index == 1) {
                                          /*     Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) => SalesReport()));*/
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            bottom: 4.0, right: 8),
                                        child: Card(
                                          elevation: 6,
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            side: BorderSide(
                                                color: Colors.white70,
                                                width: 0),
                                            borderRadius:
                                                BorderRadius.circular(16),
                                          ),
                                          child: ClipPath(
                                            clipper: ShapeBorderClipper(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16))),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: Colors.red,
                                                          width: 6))),
                                              child: Column(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors.grey
                                                              .withOpacity(
                                                                  0.05),
                                                          border: Border.all(
                                                              color: Colors.grey
                                                                  .withOpacity(
                                                                      0.0)),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8)),
                                                      child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        14),
                                                          ),
                                                          width: MediaQuery.of(
                                                                  context)
                                                              .size
                                                              .width,
                                                          height: 270,
                                                          /*     decoration: BoxDecoration(
                                                          color:Colors.white,
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                          border: Border.all(
                                                              width: 1,
                                                              color: Colors
                                                                  .grey.withOpacity(0.2))),*/
                                                          margin:
                                                              EdgeInsets.only(
                                                                  right: 0,
                                                                  left: 0,
                                                                  bottom: 4),
                                                          child: Column(
                                                            children: [
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        8.0),
                                                                child: Text(
                                                                  "R" +
                                                                      formatLargeNumber((_selectedButton == 1
                                                                              ? Constants.claims_sectionsList1b_1[index].amount.toString()
                                                                              : _selectedButton == 2
                                                                                  ? Constants.claims_sectionsList2b_1[index].amount
                                                                                  : Constants.claims_sectionsList3b_1[index].amount)
                                                                          .toString()),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          18.5,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 2,
                                                                ),
                                                              )),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        left:
                                                                            8.0,
                                                                        right:
                                                                            8,
                                                                        top: 0),
                                                                child: Text(
                                                                  (_selectedButton ==
                                                                              1
                                                                          ? Constants
                                                                              .claims_sectionsList1b[index]
                                                                              .amount
                                                                              .toString()
                                                                          : _selectedButton == 2
                                                                              ? Constants.claims_sectionsList2b[index].amount
                                                                              : Constants.claims_sectionsList3b[index].amount)
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 2,
                                                                ),
                                                              )),
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        0.0),
                                                                child: Text(
                                                                  _selectedButton ==
                                                                          1
                                                                      ? Constants
                                                                          .claims_sectionsList1b[
                                                                              index]
                                                                          .id
                                                                      : _selectedButton ==
                                                                              2
                                                                          ? Constants
                                                                              .claims_sectionsList2a[
                                                                                  index]
                                                                              .id
                                                                          : Constants
                                                                              .claims_sectionsList3a[index]
                                                                              .id,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          12.5),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 1,
                                                                ),
                                                              )),
                                                            ],
                                                          )),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ));
                        },
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 16.0, right: 16, top: 16),
                      child: Row(
                        children: [
                          Spacer(),
                          Text(
                            "REPUDIATED CLAIMS ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Container(
                              width: 100,
                              decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(8)),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 4.0, bottom: 4),
                                child: Center(
                                  child: Text(
                                    "R" +
                                        formatLargeNumber(_selectedButton == 1
                                            ? Constants
                                                .claims_repudiated_claims_amount1a
                                                .toStringAsFixed(2)
                                            : _selectedButton == 2
                                                ? Constants
                                                    .claims_repudiated_claims_amount1b
                                                    .toStringAsFixed(2)
                                                : (_selectedButton == 3 &&
                                                        days_difference <= 31)
                                                    ? Constants
                                                        .claims_repudiated_claims_amount1c
                                                        .toStringAsFixed(2)
                                                    : Constants
                                                        .claims_repudiated_claims_amount1d
                                                        .toStringAsFixed(2)),
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ))
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            childAspectRatio:
                                MediaQuery.of(context).size.width /
                                    (MediaQuery.of(context).size.height / 1.9)),
                        itemCount: _selectedButton == 1
                            ? Constants.claims_sectionsList1c.length
                            : _selectedButton == 2
                                ? Constants.claims_sectionsList2c.length
                                : _selectedButton == 3 && days_difference <= 31
                                    ? Constants.claims_sectionsList3c.length
                                    : Constants.claims_sectionsList3d.length,
                        padding: EdgeInsets.all(2.0),
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                              onTap: () {},
                              child: Container(
                                height: 290,
                                width: MediaQuery.of(context).size.width / 2.9,
                                child: Stack(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        // sales_index = index;
                                        setState(() {});
                                        if (kDebugMode) {
                                          print("sales_index " +
                                              index.toString());
                                        }
                                        if (index == 1) {
                                          /*     Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) => SalesReport()));*/
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            bottom: 4.0, right: 8),
                                        child: Card(
                                          elevation: 6,
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            side: BorderSide(
                                                color: Colors.white70,
                                                width: 0),
                                            borderRadius:
                                                BorderRadius.circular(16),
                                          ),
                                          child: ClipPath(
                                            clipper: ShapeBorderClipper(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16))),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: Colors.black,
                                                          width: 6))),
                                              child: Column(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors.grey
                                                              .withOpacity(
                                                                  0.05),
                                                          border: Border.all(
                                                              color: Colors.grey
                                                                  .withOpacity(
                                                                      0.0)),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8)),
                                                      child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        14),
                                                          ),
                                                          width: MediaQuery.of(
                                                                  context)
                                                              .size
                                                              .width,
                                                          height: 270,
                                                          /*     decoration: BoxDecoration(
                                                          color:Colors.white,
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                          border: Border.all(
                                                              width: 1,
                                                              color: Colors
                                                                  .grey.withOpacity(0.2))),*/
                                                          margin:
                                                              EdgeInsets.only(
                                                                  right: 0,
                                                                  left: 0,
                                                                  bottom: 4),
                                                          child: Column(
                                                            children: [
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        8.0),
                                                                child: Text(
                                                                  "R" +
                                                                      formatLargeNumber((_selectedButton == 1
                                                                              ? Constants.claims_sectionsList1c_1[index].amount.toString()
                                                                              : _selectedButton == 2
                                                                                  ? Constants.claims_sectionsList2c_1[index].amount
                                                                                  : Constants.claims_sectionsList3c_1[index].amount)
                                                                          .toString()),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          18.5,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 2,
                                                                ),
                                                              )),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        left:
                                                                            8.0,
                                                                        right:
                                                                            8,
                                                                        top: 0),
                                                                child: Text(
                                                                  (_selectedButton ==
                                                                              1
                                                                          ? Constants
                                                                              .claims_sectionsList1c[index]
                                                                              .amount
                                                                              .toString()
                                                                          : _selectedButton == 2
                                                                              ? Constants.claims_sectionsList2c[index].amount
                                                                              : Constants.claims_sectionsList3c[index].amount)
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 2,
                                                                ),
                                                              )),
                                                              SizedBox(
                                                                height: 8,
                                                              ),
                                                              Center(
                                                                  child:
                                                                      Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        0.0),
                                                                child: Text(
                                                                  _selectedButton ==
                                                                          1
                                                                      ? Constants
                                                                          .claims_sectionsList1b[
                                                                              index]
                                                                          .id
                                                                      : _selectedButton ==
                                                                              2
                                                                          ? Constants
                                                                              .claims_sectionsList2a[
                                                                                  index]
                                                                              .id
                                                                          : Constants
                                                                              .claims_sectionsList3a[index]
                                                                              .id,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          12.5),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 1,
                                                                ),
                                                              )),
                                                            ],
                                                          )),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ));
                        },
                      ),
                    ),
                  ],
                )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    secureScreen();
    myNotifier = MyNotifier(claimsValue, context);
    claimsValue.addListener(() {
      setState(() {});
    });
    //getMood1("");
    DateTime now = DateTime.now();
    DateTime startDate = DateTime(now.year, now.month, 1);
    DateTime endDate = DateTime.now();

    DateTime firstDayNextMonth;

// Check if this month is December, then the next month is January of next year
    if (now.month == 12) {
      firstDayNextMonth = DateTime(now.year + 1, 1, 1);
    } else {
      firstDayNextMonth = DateTime(now.year, now.month + 1, 1);
    }

    DateTime lastDayThisMonth = firstDayNextMonth.subtract(Duration(days: 1));
    noOfDaysThisMonth = lastDayThisMonth.day;

    _animateButton(1);
    Constants.claims_formattedStartDate =
        DateFormat('yyyy-MM-dd').format(startDate!);
    Constants.claims_formattedEndDate =
        DateFormat('yyyy-MM-dd').format(endDate!);
    setState(() {});

    String dateRange =
        '${Constants.claims_formattedStartDate} - ${Constants.claims_formattedEndDate}';
    print("currently loading ${dateRange}");
    DateTime startDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.claims_formattedStartDate);
    DateTime endDateTime =
        DateFormat('yyyy-MM-dd').parse(Constants.claims_formattedEndDate);

    days_difference = endDateTime.difference(startDateTime).inDays;
    if (kDebugMode) {
      print("days_difference ${days_difference}");
      print("formattedEndDate9 ${Constants.claims_formattedEndDate}");
    }

    setState(() {});
    // getSalesReport(context, formattedStartDate, formattedEndDate);

    super.initState();
  }

  FlTitlesData getTitlesData(List<String> bottomTitles) {
    return FlTitlesData(
      show: true,
      topTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: false,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: Text(
                _selectedButton == 1
                    ? Constants.claims_salesbybranch1a[index - 1].branch_name
                    : Constants.claims_salesbybranch2a[index - 1].branch_name,
                maxLines: 1,
                style: TextStyle(color: Colors.black, fontSize: 12),
              ),
            );
          },
        ),
      ),
      leftTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          reservedSize: 100,
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: RotatedBox(
                quarterTurns: -1,
                child: Text(
                  bottomTitles[index - 1],
                  maxLines: 2,
                  textAlign: TextAlign.right,
                  style: TextStyle(color: Colors.black, fontSize: 12),
                ),
              ),
            );
          },
        ),
      ),
      rightTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: false,
          getTitlesWidget: (double value, TitleMeta meta) {
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 6.0,
              child: RotatedBox(
                quarterTurns: -1,
                child: Text(
                  value.toInt().toString(),
                  style: TextStyle(color: Colors.black),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  FlTitlesData getTitlesData2(List<String> bottomTitles) {
    return FlTitlesData(
      show: true,
      topTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      rightTitles: const AxisTitles(
          sideTitles: SideTitles(
        showTitles: false,
      )),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            int index = value.toInt();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 8.0,
              child: Text(
                bottomTitles[index - 1],
                style: TextStyle(color: Colors.white),
              ),
            );
          },
        ),
      ),
      leftTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          getTitlesWidget: (double value, TitleMeta meta) {
            return SideTitleWidget(
              axisSide: meta.axisSide,
              space: 6.0,
              child: Text(
                value.toInt().toString(),
                style: TextStyle(color: Colors.white),
              ),
            );
          },
        ),
      ),
    );
  }
}

class Indicator extends StatelessWidget {
  const Indicator({
    super.key,
    required this.color,
    required this.text,
    required this.isSquare,
    this.size = 16,
    this.textColor,
  });
  final Color color;
  final String text;
  final bool isSquare;
  final double size;
  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: Row(
        children: <Widget>[
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(360),
              shape: isSquare ? BoxShape.rectangle : BoxShape.circle,
              color: color,
            ),
          ),
          const SizedBox(
            width: 4,
          ),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w300,
                color: textColor,
              ),
            ),
          )
        ],
      ),
    );
  }
}

class CustomDotPainter extends FlDotPainter {
  final double yValue;
  final double xValue;
  final double maxX; // Maximum X-value of the chart
  final double maxY; // Maximum Y-value of the chart
  final double chartWidth; // Width of the chart
  final double chartHeight; // Height of the chart

  CustomDotPainter({
    required this.yValue,
    required this.xValue,
    required this.maxX,
    required this.maxY,
    required this.chartWidth,
    required this.chartHeight,
  });

  @override
  void paint(Canvas canvas, Size size, FlSpot spot, double xPercent,
      double yPercent, LineChartBarData bar, int index) {
    // Calculate the position based on chart dimensions and spot's value
    double xPosition = (xValue / maxX) * chartWidth;
    double yPosition =
        chartHeight - (yValue / Constants.claims_maxY) * chartHeight;

    // Paint the dot
    final paint = Paint()..color = Constants.ctaColorLight;
    canvas.drawCircle(Offset(xPosition, yPosition), size.width / 2, paint);

    // Draw the text
    TextSpan span = TextSpan(
        style: TextStyle(color: Colors.black), text: yValue.round().toString());
    TextPainter tp = TextPainter(
        text: span,
        textAlign: TextAlign.center,
        textDirection: ui.TextDirection.ltr);
    tp.layout();

    // Adjust the position to paint the text
    double textX = xPosition - tp.width / 2;
    double textY = yPosition - tp.height - 10;

    // Paint the text
    tp.paint(canvas, Offset(textX, textY));
  }

  @override
  void draw(Canvas canvas, FlSpot spot, Offset offsetInCanvas) {
    paint(canvas, getSize(spot), spot, 0, 0,
        LineChartBarData(color: Colors.blue), 0); // Example call
  }

  @override
  Size getSize(FlSpot spot) {
    // Return the size of your dot
    return const Size(12, 12); // Example size, adjust as needed
  }

  @override
  List<Object?> get props => [yValue];
}

String formatWithCommasB(double value) {
  final format = NumberFormat("#,##0", "en_US"); // Updated pattern
  return format.format(value);
}

String formatLargeNumberB(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 1000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatLargeNumber2B(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 1000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatWithCommas(double value) {
  final format = NumberFormat("#,##0", "en_US"); // Updated pattern
  return format.format(value);
}

String formatLargeNumber(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 1000000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String formatLargeNumber2(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  // If the value is less than 1000, return it as a string with commas
  if (value < 100000) {
    return formatWithCommas(value);
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  return '${formatWithCommas(newValue)}${suffixes[index]}';
}

String getMonthAbbreviation(int monthNumber) {
  List<String> months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];

  // Check if the month number is valid
  if (monthNumber < 1 || monthNumber > 12) {
    return "-";
  }

  // Return the corresponding month abbreviation
  return months[monthNumber - 1];
}

class CategoryItem {
  String title;
  int count;

  CategoryItem({required this.title, required this.count});
}

class Category {
  String name;
  List<CategoryItem> items;

  Category({required this.name, required this.items});
}

class ClaimsReportGraph2 extends StatefulWidget {
  const ClaimsReportGraph2({super.key});

  @override
  State<ClaimsReportGraph2> createState() => _ClaimsReport2State();
}

class _ClaimsReport2State extends State<ClaimsReportGraph2> {
  List<FlSpot> sales_spots2a = [];
  List<FlSpot> sales_spots2b = [];
  List<FlSpot> sales_spots2c = [];
  Key sales_chartKey2a = UniqueKey();
  Key sales_chartKey2b = UniqueKey();
  Key sales_chartKey2c = UniqueKey();
  int sales_maxY2 = 0;
  @override
  void initState() {
    sales_spots2a = [];
    sales_spots2b = [];
    sales_spots2c = [];
    sales_chartKey2a = UniqueKey();
    sales_chartKey2b = UniqueKey();
    sales_chartKey2c = UniqueKey();
    sales_maxY2 = 0;

    getMaintanenceGraphData();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 250,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: claims_index == 0
                      ? LineChart(
                          key: sales_chartKey2a,
                          LineChartData(
                            lineBarsData: [
                              LineChartBarData(
                                spots: sales_spots2a,
                                isCurved: true,
                                barWidth: 3,
                                color: Colors.grey.shade400,
                                dotData: FlDotData(
                                  show: true,
                                  getDotPainter:
                                      (spot, percent, barData, index) {
                                    // Show custom dot and text for specific x-values

                                    return FlDotCirclePainter(
                                        radius: 2,
                                        color: Colors.red,
                                        strokeColor: Colors.green);
                                    /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                  },
                                ),
                              ),
                            ],
                            gridData: FlGridData(
                              show: true,
                              drawVerticalLine: false,
                              getDrawingHorizontalLine: (value) {
                                return FlLine(
                                  color: Colors.grey.withOpacity(0.10),
                                  strokeWidth: 1,
                                );
                              },
                              getDrawingVerticalLine: (value) {
                                return FlLine(
                                  color: Colors.grey,
                                  strokeWidth: 1,
                                );
                              },
                            ),
                            titlesData: FlTitlesData(
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  interval: 1,
                                  getTitlesWidget: (value, meta) {
                                    int totalMonths = value.toInt();
                                    int year = totalMonths ~/ 12;
                                    int month = totalMonths % 12;
                                    month = month == 0 ? 12 : month;
                                    year = month == 12 ? year - 1 : year;
                                    String monthAbbreviation =
                                        getMonthAbbreviation(month);

                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(
                                        "$monthAbbreviation", // Displaying both month and year
                                        style: TextStyle(fontSize: 10),
                                      ),
                                    );
                                  },
                                ),
                                axisNameWidget: Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(
                                    'Months of the Year',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black),
                                  ),
                                ),
                              ),
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: false,
                                  getTitlesWidget: (value, meta) {
                                    return Text(value.toInt().toString());
                                  },
                                ),
                              ),
                              leftTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  reservedSize: 20,
                                  getTitlesWidget: (value, meta) {
                                    return Text(
                                      formatLargeNumber3(
                                          value.toInt().toString()),
                                      style: TextStyle(fontSize: 8),
                                    );
                                  },
                                ),
                                /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                              ),
                            ),
                            minY: 0,
                            // maxY: 100,
                            borderData: FlBorderData(
                              show: true,
                              border: Border(
                                left: BorderSide.none,
                                bottom: BorderSide(
                                  color: Colors.grey.withOpacity(0.35),
                                  width: 1,
                                ),
                                right: BorderSide.none,
                                top: BorderSide.none,
                              ),
                            ),
                          ),
                        )
                      : claims_index == 1
                          ? LineChart(
                              key: sales_chartKey2b,
                              LineChartData(
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2b,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                        /*    if (_selectedButton == 1) {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 30,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          } else {
                                            return CustomDotPainter(
                                                yValue: spot.y,
                                                Constants.maxY: Constants.maxY.toDouble(),
                                                chartHeight: 120,
                                                xValue: spot.x,
                                                maxX: 12,
                                                chartWidth:
                                                    MediaQuery.of(context).size.width +
                                                        45);
                                          }*/
                                      },
                                    ),
                                  ),
                                ],
                                minX: 1,
                                maxX: 12,
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            getMonthAbbreviation(value.toInt()),
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            )
                          : LineChart(
                              key: sales_chartKey2c,
                              LineChartData(
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: sales_spots2c,
                                    isCurved: true,
                                    barWidth: 3,
                                    color: Colors.grey.shade400,
                                    dotData: FlDotData(
                                      show: true,
                                      getDotPainter:
                                          (spot, percent, barData, index) {
                                        // Show custom dot and text for specific x-values

                                        return FlDotCirclePainter(
                                            radius: 2,
                                            color: Colors.red,
                                            strokeColor: Colors.green);
                                      },
                                    ),
                                  ),
                                ],
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: false,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey.withOpacity(0.10),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.grey,
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        return Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Text(
                                            getMonthAbbreviation(value.toInt()),
                                            style: TextStyle(fontSize: 10),
                                          ),
                                        );
                                      },
                                    ),
                                    axisNameWidget: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        'Months of the Year',
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  topTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: false,
                                      getTitlesWidget: (value, meta) {
                                        return Text(value.toInt().toString());
                                      },
                                    ),
                                  ),
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 20,
                                      getTitlesWidget: (value, meta) {
                                        return Text(
                                          formatLargeNumber3(
                                              value.toInt().toString()),
                                          style: TextStyle(fontSize: 8),
                                        );
                                      },
                                    ),
                                    /* axisNameWidget: Padding(
                                                  padding:
                                                      const EdgeInsets.only(top: 0.0),
                                                  child: Text(
                                                    'Sales',
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black),
                                                  ),
                                                ),*/
                                  ),
                                ),
                                minY: 0,
                                maxY: sales_maxY2.toDouble(),
                                borderData: FlBorderData(
                                  show: true,
                                  border: Border(
                                    left: BorderSide.none,
                                    bottom: BorderSide(
                                      color: Colors.grey.withOpacity(0.35),
                                      width: 1,
                                    ),
                                    right: BorderSide.none,
                                    top: BorderSide.none,
                                  ),
                                ),
                              ),
                            ))),
        ));
  }

  Future<void> getMaintanenceGraphData() async {
    try {
      List<FlSpot> salesSpots = [];
      Map m1 = Constants.jsonMonthlyClaimsData1["claims_ratio_dict"];
      print("gffgfddf ${m1}");

      m1.forEach((key, value) {
        print("ekey ${key}");
        print("evalue ${value}");
        DateTime dt1 = DateTime.parse(key);
        int year = dt1.year;
        int month = dt1.month;
        double new_value = double.parse(value.toString());

        if (value > sales_maxY2) {
          sales_maxY2 = value.round();
        }
        if (new_value != 0)
          salesSpots.add(FlSpot((year * 12 + month).toDouble(), new_value));
        print("spot added");
      });

      setState(() {
        sales_spots2a = salesSpots;
        print(sales_spots2a);
      });
    } catch (exception) {
      print("Error: $exception");
      print("Stack Trace: $exception");
    }
  }
}

String formatLargeNumber3(String valueStr) {
  const List<String> suffixes = [
    "",
    "k",
    "m",
    "b",
    "t"
  ]; // Add more suffixes as needed

  // Convert string to double and handle invalid inputs
  double value;
  try {
    value = double.parse(valueStr);
  } catch (e) {
    return 'Invalid Number';
  }

  int index = 0;
  double newValue = value;

  while (newValue >= 1000 && index < suffixes.length - 1) {
    newValue /= 1000;
    index++;
  }

  if (value > 999) {
    return '${((newValue)).toStringAsFixed(1)}${suffixes[index]}';
  } else
    return value.toStringAsFixed(0);
}
